#!/usr/bin/env python3
"""Run the whole loading sequence against an Elastic project, stopping at the first failure.

    python3 run_all.py out/ --env-file demo.env [--rehearse] [--skip-agent]

Steps: connectivity check, OTLP ingestion, verification, ES|QL tool test, agent deployment, optional rehearsal.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).parent


def step(title: str, script: str, *args: str) -> None:
    print(f"\n=== {title} ===", flush=True)
    code = subprocess.run([sys.executable, str(HERE / script), *args]).returncode
    if code:
        sys.exit(f"\nStopped at step '{title}'. Fix the problem above, then rerun. "
                 f"If data was partly sent, run cleanup.py first.")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("out")
    ap.add_argument("--env-file", required=True)
    ap.add_argument("--rehearse", action="store_true", help="also ask questions.json to the agent")
    ap.add_argument("--skip-agent", action="store_true", help="load and verify the data only")
    args = ap.parse_args()
    env = ["--env-file", args.env_file]
    try:
        import opentelemetry.proto.collector.logs.v1.logs_service_pb2  # noqa: F401
    except ImportError:
        print("Note: 'opentelemetry-proto' is not installed, OTLP/JSON will be used. If the endpoint refuses it "
              "(HTTP 406 or 415), run: pip install opentelemetry-proto")
    step("1/5 Connectivity", "ingest.py", "--check", *env)
    step("2/5 Ingestion", "ingest.py", args.out, *env)
    step("3/5 Verification", "verify.py", args.out, *env)
    if args.skip_agent:
        return
    if not (Path(args.out) / "agent.json").exists():
        step("Agent definition", "agent.py", "build", args.out)
    step("4/5 Agent tools (ES|QL)", "agent.py", "test-tools", args.out, *env)
    step("5/5 Agent deployment", "agent.py", "deploy", args.out, *env)
    if args.rehearse:
        step("Rehearsal", "agent.py", "rehearse", args.out, *env)
    print("\nDemo environment ready.")


if __name__ == "__main__":
    main()
