#!/usr/bin/env python3
"""Generate a synthetic OpenTelemetry dataset from a scenario file.

Input : scenario.json (see references/scenario-schema.md)
Output: <out>/otlp/{traces,logs,metrics}.ndjson.gz  one OTLP/JSON export request per line
        <out>/ground_truth.json                    what was injected, with measured evidence
        <out>/summary.json                         counts, window, Apdex timeline

Standard library only. Deterministic for a given seed and window end.

Usage:
    python3 generate.py scenario.json --out out/ [--end now|midnight|last_weekday|ISO] [--total-events N]
"""
from __future__ import annotations

import argparse
import bisect
import gzip
import json
import math
import random
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).parent))
NS = 1_000_000_000
MS = 1_000_000
BATCH = 1500                      # records per OTLP export request
SLOW_CALL_MS = 3000               # services log a WARN above this
TASK_TYPES = ["DIALOG", "HTTP", "BACKGROUND", "RFC", "UPDATE"]
INCIDENT_TYPES = {"sap_batch_contention", "external_slow", "database_slow", "deploy_regression",
                  "sap_http_slow", "error_burst"}
ATTR_META = {"source", "propagate", "description"}          # documentation keys of an attribute spec


# --------------------------------------------------------------------------- helpers
def die(msg: str) -> None:
    sys.exit(f"[generate] ERROR: {msg}")


def attr(key: str, value):
    if isinstance(value, bool):
        v = {"boolValue": value}
    elif isinstance(value, int):
        v = {"intValue": str(value)}
    elif isinstance(value, float):
        v = {"doubleValue": round(value, 3)}
    else:
        v = {"stringValue": str(value)}
    return {"key": key, "value": v}


def attrs(d: dict) -> list:
    return [attr(k, v) for k, v in d.items() if v is not None]


def lognorm(rng: random.Random, median: float, sigma: float = 0.35) -> float:
    return median * math.exp(rng.gauss(0, sigma))


EXCEPTIONS = {
    "java": {"timeout": "java.net.SocketTimeoutException", "http": "org.springframework.web.client.HttpServerErrorException",
             "conflict": "org.springframework.dao.OptimisticLockingFailureException",
             "validation": "jakarta.validation.ConstraintViolationException", "state": "java.lang.IllegalStateException"},
    "dotnet": {"timeout": "System.TimeoutException", "http": "System.Net.Http.HttpRequestException",
               "conflict": "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException",
               "validation": "System.ComponentModel.DataAnnotations.ValidationException", "state": "System.InvalidOperationException"},
    "python": {"timeout": "requests.exceptions.ReadTimeout", "http": "requests.exceptions.HTTPError",
               "conflict": "sqlalchemy.orm.exc.StaleDataError", "validation": "pydantic.ValidationError", "state": "RuntimeError"},
    "nodejs": {"timeout": "TimeoutError", "http": "HTTPError", "conflict": "OptimisticLockError",
               "validation": "ValidationError", "state": "Error"},
    "go": {"timeout": "context.DeadlineExceeded", "http": "*url.Error", "conflict": "ErrConflict",
           "validation": "ErrValidation", "state": "ErrInvalidState"},
}


def exc(language: str, kind: str) -> str:
    """Exception name that fits the language of the service that logs it."""
    return EXCEPTIONS.get(language, EXCEPTIONS["java"])[kind]


def gen_value(spec, rng: random.Random):
    """One value for a custom attribute. See references/attributes-guide.md for the spec forms."""
    if isinstance(spec, list):
        return rng.choice(spec)
    if not isinstance(spec, dict):
        return spec
    if spec.get("uuid"):
        return f"{rng.getrandbits(128):032x}"
    if "values" in spec:
        return rng.choices(spec["values"], spec.get("weights"))[0]
    if "format" in spec:
        return spec["format"].format(rng.randint(int(spec.get("min", 1)), int(spec.get("max", 999999))))
    if "min" in spec and "max" in spec:
        if spec.get("decimals"):
            return round(rng.uniform(spec["min"], spec["max"]), int(spec["decimals"]))
        return rng.randint(int(spec["min"]), int(spec["max"]))
    if "value" in spec:
        return spec["value"]
    die(f"attribute spec {spec!r} needs one of: value, values, format, uuid, min/max")


def gen_attrs(block: dict | None, rng: random.Random) -> dict:
    return {key: gen_value(spec, rng) for key, spec in (block or {}).items()}


def reach(spec) -> set:
    """Where a propagated attribute travels: 'services' (service spans, logs, outgoing calls), 'core' (core system logs)."""
    prop = spec.get("propagate") if isinstance(spec, dict) else None
    if not prop:
        return set()
    if prop is True:
        return {"services", "core"}
    targets = {prop} if isinstance(prop, str) else set(prop)
    bad = targets - {"services", "core"}
    if bad:
        die(f"propagate accepts true, 'services', 'core' or a list of both, got {sorted(bad)}")
    return targets


def split_endpoint(ep: str):
    method, _, route = ep.partition(" ")
    return method, route


class Writer:
    """Buffers records per signal, groups them by resource, writes OTLP/JSON lines."""

    def __init__(self, out: Path):
        (out / "otlp").mkdir(parents=True, exist_ok=True)
        self.files = {s: gzip.open(out / "otlp" / f"{s}.ndjson.gz", "wt", encoding="utf-8")
                      for s in ("traces", "logs", "metrics")}
        self.buf = {s: [] for s in self.files}
        self.resources: dict[str, dict] = {}
        self.counts: dict[str, int] = defaultdict(int)      # per data stream
        self.total = 0

    def resource(self, key: str, attributes: dict) -> str:
        if key not in self.resources:
            self.resources[key] = {"attributes": attrs(attributes)}
        return key

    def add(self, signal: str, res_key: str, record: dict, stream: str, n: int = 1) -> None:
        self.buf[signal].append((res_key, record))
        self.counts[stream] += n
        self.total += n
        if len(self.buf[signal]) >= BATCH:
            self.flush(signal)

    def flush(self, signal: str) -> None:
        buf = self.buf[signal]
        if not buf:
            return
        groups: dict[str, list] = defaultdict(list)
        for key, rec in buf:
            groups[key].append(rec)
        scope = {"name": "elastic-ai-demo-builder", "version": "1.0.0"}
        if signal == "traces":
            payload = {"resourceSpans": [{"resource": self.resources[k],
                                          "scopeSpans": [{"scope": scope, "spans": v}]}
                                         for k, v in groups.items()]}
        elif signal == "logs":
            payload = {"resourceLogs": [{"resource": self.resources[k],
                                         "scopeLogs": [{"scope": scope, "logRecords": v}]}
                                        for k, v in groups.items()]}
        else:
            payload = {"resourceMetrics": [{"resource": self.resources[k],
                                            "scopeMetrics": [{"scope": scope, "metrics": v}]}
                                           for k, v in groups.items()]}
        self.files[signal].write(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n")
        self.buf[signal] = []

    def close(self) -> None:
        for s, f in self.files.items():
            self.flush(s)
            f.close()


class Stat:
    __slots__ = ("n", "total", "values")

    def __init__(self):
        self.n, self.total, self.values = 0, 0.0, []

    def add(self, v: float) -> None:
        self.n += 1
        self.total += v
        if len(self.values) < 20000:
            self.values.append(v)

    def avg(self) -> float:
        return round(self.total / self.n, 1) if self.n else 0.0

    def p95(self) -> float:
        if not self.values:
            return 0.0
        s = sorted(self.values)
        return round(s[min(len(s) - 1, int(0.95 * len(s)))], 1)


# --------------------------------------------------------------------------- scenario
class Scenario:
    def __init__(self, raw: dict, end_override: str | None, total_override: int | None):
        self.raw = raw
        c = raw["customer"]
        self.slug = c["slug"].lower()
        if not self.slug.replace("_", "").isalnum() or self.slug == "default":
            die("customer.slug must be alphanumeric (underscores allowed) and not 'default': it becomes the data stream namespace")
        self.prefix = c.get("attribute_prefix", self.slug).lower()
        self.lang = c.get("language", "fr")
        self.tz = ZoneInfo(c.get("timezone", "Europe/Paris"))
        d = raw["dataset"]
        self.total_events = int(total_override or d["total_events"])
        self.hours = int(d.get("window_hours", 24))
        self.seed = int(d.get("seed", 42))
        self.end = self._resolve_end(end_override or d.get("end", "last_weekday"))
        self.start = self.end - timedelta(hours=self.hours)
        a = raw.get("apdex") or {}
        corr = raw.get("correlation") or {}
        self.trace_f2s = bool(corr.get("trace_frontend_to_services", True))     # one trace from the UI down to services
        self.trace_logs = bool(corr.get("trace_in_service_logs", True))         # service logs carry trace_id
        self.trace_core = bool(corr.get("trace_in_core_system_logs", False))    # core system logs carry trace_id
        self.kpi = "apdex" if raw.get("apdex") else "none"    # no apdex block: degradation is read on response time
        self.t_ms = float(a.get("satisfied_ms", 4000))
        self.f_ms = float(a.get("frustrated_ms", 4 * self.t_ms))
        self.target = float(a.get("target", 0.98))
        dim = raw.get("business_dimension")
        self.dim_attr = f"{self.prefix}.{dim['attribute']}" if dim else None
        self.dim_values = dim["values"] if dim else []
        self.front = raw.get("frontend") or raw.get("ihm")
        if not self.front:
            die("the scenario needs a 'frontend' block (the user-facing application)")
        self.services = {s["name"]: s for s in raw["services"]}
        self.sap = raw.get("sap")
        self.externals = {e["name"]: e for e in raw.get("externals", [])}
        self.databases = {d["name"]: d for d in raw.get("databases", [])}
        self.screens = raw["screens"]
        self.endpoints = {(e["service"], e["endpoint"]): e for e in raw["endpoints"]}
        self.weights = raw.get("load_profile", {}).get("hourly_weights") or [1] * 24
        if len(self.weights) != 24:
            die("load_profile.hourly_weights needs exactly 24 values")
        self._validate_topology()
        self.incidents = [self._resolve_incident(i) for i in raw.get("incidents", [])]

    def _resolve_end(self, spec: str) -> datetime:
        now = datetime.now(self.tz)
        if spec == "now":
            return now.replace(second=0, microsecond=0) - timedelta(minutes=now.minute % 5)
        if spec == "midnight":
            return now.replace(hour=0, minute=0, second=0, microsecond=0)
        if spec == "last_weekday":                            # end of the most recent complete Mon-Fri day
            end = now.replace(hour=0, minute=0, second=0, microsecond=0)
            while (end - timedelta(days=1)).weekday() >= 5:
                end -= timedelta(days=1)
            return end
        try:
            dt = datetime.fromisoformat(spec)
        except ValueError:
            die(f"dataset.end must be 'now', 'midnight', 'last_weekday' or an ISO datetime, got {spec!r}")
        return dt if dt.tzinfo else dt.replace(tzinfo=self.tz)

    def _validate_topology(self) -> None:
        for sc in self.screens:
            for call in sc["calls"]:
                if (call["service"], call["endpoint"]) not in self.endpoints:
                    die(f"screen {sc['name']!r} calls unknown endpoint {call['service']} {call['endpoint']}")
        for (svc, _), ep in self.endpoints.items():
            if svc not in self.services:
                die(f"endpoint declared on unknown service {svc!r}")
            for call in ep.get("calls", []):
                if "external" in call and call["external"] not in self.externals:
                    die(f"unknown external {call['external']!r}")
                if "sap" in call and not self.sap:
                    die("an endpoint calls SAP but the scenario has no 'sap' block")
                if "database" in call and call["database"] not in self.databases:
                    die(f"unknown database {call['database']!r}")
                if not any(k in call for k in ("sap", "external", "database")):
                    die(f"endpoint {svc} call needs one of 'sap', 'external', 'database': {call!r}")
        probe = random.Random(0)                              # fail early on a malformed attribute spec
        blocks = [self.front, self.sap or {}, *self.screens, *self.services.values(), *self.externals.values(),
                  *self.databases.values(), *self.endpoints.values()]
        blocks += [c for e in self.endpoints.values() for c in e.get("calls", [])]
        for b in blocks:
            gen_attrs(b.get("attributes"), probe)
            for spec in (b.get("attributes") or {}).values():
                reach(spec)

    def local_time_in_window(self, hhmm: str, day: int = 1) -> datetime:
        h, m = (int(x) for x in hhmm.split(":"))
        cand = self.start.astimezone(self.tz).replace(hour=h, minute=m, second=0, microsecond=0)
        if cand < self.start:
            cand += timedelta(days=1)
        return cand + timedelta(days=day - 1)

    def occurrences(self, hhmm: str) -> list[datetime]:
        out, t = [], self.local_time_in_window(hhmm)
        while t < self.end:
            out.append(t)
            t += timedelta(days=1)
        return out

    def _resolve_incident(self, inc: dict) -> dict:
        if inc.get("type") not in INCIDENT_TYPES:
            die(f"incident {inc.get('id')}: unknown type {inc.get('type')!r}. Known: {sorted(INCIDENT_TYPES)}")
        s = self.local_time_in_window(inc["start"], int(inc.get("day", 1)))
        e = s + timedelta(minutes=int(inc["duration_min"]))
        if e > self.end:
            die(f"incident {inc['id']} ends after the dataset window ({e.isoformat()} > {self.end.isoformat()})")
        out = dict(inc)
        out["_s"], out["_e"] = int(s.timestamp() * NS), int(e.timestamp() * NS)
        out["_start_dt"], out["_end_dt"] = s, e
        out.setdefault("impact_ratio", 0.9)
        t = inc["type"]
        if t == "sap_batch_contention":
            if not self.sap or inc.get("job") not in {j["name"] for j in self.sap.get("jobs", [])}:
                die(f"incident {inc['id']}: 'job' must name one of sap.jobs")
        if t == "external_slow" and inc.get("external") not in self.externals:
            die(f"incident {inc['id']}: unknown external {inc.get('external')!r}")
        if t == "database_slow" and inc.get("database") not in self.databases:
            die(f"incident {inc['id']}: unknown database {inc.get('database')!r}")
        if t in ("deploy_regression", "error_burst"):
            if (inc.get("service"), inc.get("endpoint")) not in self.endpoints:
                die(f"incident {inc['id']}: unknown service/endpoint")
        return out


# --------------------------------------------------------------------------- generator
class Generator:
    def __init__(self, sc: Scenario, out: Path):
        self.sc, self.out = sc, out
        self.rng = random.Random(sc.seed)
        self.arng = random.Random(sc.seed + 6)                # custom attributes: separate stream, timings stay stable
        self.w = Writer(out)
        self.p = sc.prefix
        self.s_ns = int(sc.start.timestamp() * NS)
        self.e_ns = int(sc.end.timestamp() * NS)
        self.reqs: list[tuple] = []                           # (t_ns, screen, dim, dur_ms, zone, incident ids)
        self.dep = defaultdict(Stat)                          # (scope, kind, name) -> duration
        self.ep_total = defaultdict(Stat)                     # (scope, service, endpoint)
        self.ep_own = defaultdict(Stat)
        self.icm_queue = defaultdict(Stat)                    # scope
        self.sap_calls = defaultdict(lambda: [0, 0.0, 0.0])   # 5-min bucket -> [steps, processing ms, wait ms]
        self.versions = defaultdict(set)

    # ---- resources and stream names
    def ds(self, typ: str, dataset: str = "generic") -> str:
        return f"{typ}-{dataset}.otel-{self.sc.slug}"

    def res_service(self, name: str, version: str, lang: str, host: str, dataset: str | None) -> str:
        key = f"{name}@{version}#{dataset}"
        a = {"service.name": name, "service.version": version, "service.namespace": self.sc.raw["customer"].get("system", self.p).lower(),
             "deployment.environment.name": "production", "deployment.environment": "production",
             "telemetry.sdk.name": "opentelemetry", "telemetry.sdk.language": lang, "host.name": host,
             "data_stream.namespace": self.sc.slug}
        if dataset:
            a["data_stream.dataset"] = dataset
        return self.w.resource(key, a)

    def res_sap(self, dataset: str | None) -> str:
        sap = self.sc.sap
        a = {"service.name": sap["name"], "service.namespace": "sap", "host.name": sap["host"], "sap.sid": sap["sid"],
             "deployment.environment.name": "production", "deployment.environment": "production",
             "data_stream.namespace": self.sc.slug}
        if dataset:
            a["data_stream.dataset"] = dataset
        return self.w.resource(f"sap#{dataset}", a)

    def version_at(self, service: str, t: int) -> str:
        for inc in self.sc.incidents:
            if inc["type"] == "deploy_regression" and inc["service"] == service and inc["_s"] <= t < inc["_e"]:
                return inc["new_version"]
        if service == self.sc.front["service"]:
            return self.sc.front["version"]
        return self.sc.services[service]["version"]

    # ---- low-level emitters
    def new_id(self, nbytes: int) -> str:
        return f"{self.rng.getrandbits(nbytes * 8):0{nbytes * 2}x}"

    def span(self, res: str, trace_id: str, span_id: str, parent: str | None, name: str, kind: int,
             start: int, dur_ms: float, a: dict, error: bool) -> None:
        rec = {"traceId": trace_id, "spanId": span_id, "name": name, "kind": kind,
               "startTimeUnixNano": str(start), "endTimeUnixNano": str(start + int(dur_ms * MS)),
               "attributes": attrs(a), "status": {"code": 2} if error else {"code": 1}}
        if parent:
            rec["parentSpanId"] = parent
        self.w.add("traces", res, rec, self.ds("traces"))

    def log(self, res: str, dataset: str, t: int, severity: str, body: str, a: dict,
            trace_id: str | None = None, span_id: str | None = None) -> None:
        num = {"DEBUG": 5, "INFO": 9, "WARN": 13, "ERROR": 17}[severity]
        if dataset.startswith("sap.") and self.sc.sap.get("attributes"):
            a = {**gen_attrs(self.sc.sap["attributes"], self.arng), **a}
        rec = {"timeUnixNano": str(t), "observedTimeUnixNano": str(t), "severityNumber": num,
               "severityText": severity, "body": {"stringValue": body}, "attributes": attrs(a)}
        if trace_id:
            rec["traceId"], rec["spanId"] = trace_id, span_id
        self.w.add("logs", res, rec, self.ds("logs", dataset))

    def gauge(self, res: str, t: int, values: dict) -> None:
        for name, (val, unit) in values.items():
            rec = {"name": name, "unit": unit,
                   "gauge": {"dataPoints": [{"timeUnixNano": str(t), "asDouble": round(val, 4)}]}}
            self.w.add("metrics", res, rec, self.ds("metrics"))

    # ---- incident lookup
    def active(self, t: int) -> list[dict]:
        return [i for i in self.sc.incidents if i["_s"] <= t < i["_e"]]

    def hit(self, inc: dict, t: int, rng: random.Random) -> bool:
        """Is this request affected? Short ramp up/down at both ends of the incident window."""
        span = inc["_e"] - inc["_s"]
        ramp = max(1, int(span * 0.08))
        intensity = min(1.0, (t - inc["_s"]) / ramp + 0.25, (inc["_e"] - t) / ramp + 0.25)
        return rng.random() < inc["impact_ratio"] * intensity

    # ---- request simulation
    def simulate(self, t0: int, screen: dict, rng: random.Random, emit: bool) -> int:
        """Simulate one user request. Returns the number of events produced."""
        sc, p = self.sc, self.p
        act = self.active(t0)
        scope_ids = tuple(i["id"] for i in act)
        scopes = scope_ids or ("baseline",)
        trace_id, root_id = self.new_id(16), self.new_id(8)
        dim = rng.choice(sc.dim_values) if sc.dim_values else None
        events = 1
        own_root = lognorm(rng, screen.get("own_ms", 100), 0.3)
        cursor = t0 + int(own_root * 0.5 * MS)
        status = 200
        pending = []                                           # emitted after the root is known
        req_attrs, shared, shared_core = {}, {}, {}
        if emit:
            for block in (sc.front.get("attributes"), screen.get("attributes")):
                vals = gen_attrs(block, self.arng)
                req_attrs.update(vals)
                for k, spec in (block or {}).items():
                    targets = reach(spec)
                    if "services" in targets:
                        shared[k] = vals[k]
                    if "core" in targets:
                        shared_core[k] = vals[k]

        for call in screen["calls"]:
            svc_name, ep_name = call["service"], call["endpoint"]
            svc, ep = sc.services[svc_name], sc.endpoints[(svc_name, ep_name)]
            method, route = split_endpoint(ep_name)
            version = self.version_at(svc_name, cursor)
            net = rng.uniform(2, 8)
            svc_start = cursor + int(net * MS)
            client_id, server_id = self.new_id(8), self.new_id(8)
            svc_trace = trace_id if sc.trace_f2s else self.new_id(16)   # broken propagation: the service starts its own trace
            log_trace = (svc_trace, server_id) if sc.trace_logs else (None, None)
            own = lognorm(rng, ep.get("own_ms", 80), 0.3)
            svc_status, extra_logs, downstream = 200, [], 0.0
            svc_attrs = {**gen_attrs(svc.get("attributes"), self.arng), **gen_attrs(ep.get("attributes"), self.arng),
                         **shared} if emit else {}
            regress = None
            for inc in act:
                if inc["type"] == "deploy_regression" and inc["service"] == svc_name and inc["endpoint"] == ep_name:
                    if self.hit(inc, t0, rng):
                        regress = inc
                        lo, hi = inc.get("own_ms", [4500, 9000])
                        own = rng.uniform(lo, hi)
                        if rng.random() < inc.get("error_rate", 0.05):
                            svc_status = 500
                            own = max(own, 10000.0)
                if inc["type"] == "error_burst" and inc["service"] == svc_name and inc["endpoint"] == ep_name:
                    if rng.random() < inc.get("error_rate", 0.3):
                        svc_status, regress = 500, inc
            inner = svc_start + int(own * 0.4 * MS)

            for back in ep.get("calls", []):
                bid = self.new_id(8)
                bmethod = back.get("method", "GET")
                dur = lognorm(rng, back["base_ms"], 0.35)
                if rng.random() < 0.004:                       # background noise: rare slow call
                    dur *= rng.uniform(4, 9)
                bstatus, wait, queue = 200, 0.0, 0.0
                if "sap" in back:
                    kind, name, path, host = "sap", sc.sap["name"], back["sap"], sc.sap["host"]
                    for inc in act:
                        if inc["type"] == "sap_batch_contention" and self.hit(inc, t0, rng):
                            factor = lognorm(rng, inc.get("latency_factor", 10), 0.3)
                            wait += dur * (factor - 1) * 0.75
                            dur *= factor
                        if inc["type"] == "sap_http_slow" and self.hit(inc, t0, rng):
                            lo, hi = inc.get("queue_ms", [2500, 6000])
                            queue = rng.uniform(lo, hi)
                            if rng.random() < inc.get("error_rate", 0.03):
                                bstatus = 503
                    bucket = (inner - self.s_ns) // (300 * NS)
                    agg = self.sap_calls[bucket]
                    agg[0] += 1
                    agg[1] += dur
                    agg[2] += wait
                    total = dur + queue
                    for s in scopes:
                        self.icm_queue[s].add(queue)
                elif "database" in back:
                    db = sc.databases[back["database"]]
                    kind, name, path, host = "database", db["name"], back.get("table", ""), db.get("host", db["name"])
                    bmethod = back.get("operation", "SELECT")
                    for inc in act:
                        if inc["type"] == "database_slow" and inc["database"] == name and self.hit(inc, t0, rng):
                            lo, hi = inc.get("latency_ms", [6000, 10000])
                            dur = rng.uniform(lo, hi)
                            if rng.random() < inc.get("timeout_rate", 0.05):
                                dur, bstatus = float(db.get("timeout_ms", 15000)), 504
                    total = dur
                else:
                    ext = sc.externals[back["external"]]
                    kind, name, path, host = "external", ext["name"], back.get("path", "/"), ext["host"]
                    for inc in act:
                        if inc["type"] == "external_slow" and inc["external"] == name and self.hit(inc, t0, rng):
                            lo, hi = inc.get("latency_ms", [8000, 12000])
                            dur = rng.uniform(lo, hi)
                            if rng.random() < inc.get("timeout_rate", 0.1):
                                dur, bstatus = float(ext.get("timeout_ms", 15000)), 504
                    total = dur
                for s in scopes:
                    self.dep[(s, kind, name)].add(total)
                events += 1
                if emit:
                    target = sc.sap if kind == "sap" else sc.databases[name] if kind == "database" else sc.externals[name]
                    call_attrs = {**gen_attrs(target.get("attributes"), self.arng),
                                  **gen_attrs(back.get("attributes"), self.arng), **shared}
                    if kind == "database":
                        proto = {"db.system.name": target.get("system", "other_sql"), "db.namespace": name,
                                 "db.operation.name": bmethod, "db.collection.name": path or None}
                    else:
                        proto = {"http.request.method": bmethod, "url.path": path, "http.response.status_code": bstatus}
                    pending.append((svc_trace, self.res_service(svc_name, version, svc["language"], svc["host"], None),
                                    bid, server_id, bmethod if kind == "external" else f"{bmethod} {path}".strip(), 3,
                                    inner, total,
                                    {**call_attrs, **proto, "server.address": host, "peer.service": name,
                                     f"{p}.dependency.type": kind, f"{p}.dependency.name": name,
                                     f"{p}.layer": "dependency"}, bstatus >= 500))
                if kind == "sap":
                    events += 1
                    if emit:
                        self.log(self.res_sap("sap.icm"), "sap.icm", inner + int(total * MS),
                                 "ERROR" if bstatus >= 500 else "INFO",
                                 f"{bmethod} {path} HTTP/1.1 {bstatus} {int(total)}ms (queue {int(queue)}ms)",
                                 {**gen_attrs(back.get("attributes"), self.arng), **shared_core,
                                  "http.request.method": bmethod, "url.path": path, "http.response.status_code": bstatus,
                                  "sap.icm.response_time_ms": int(total), "sap.icm.queue_time_ms": int(queue),
                                  "sap.icm.processing_time_ms": int(dur), "network.protocol.name": "https",
                                  "client.address": svc["host"], "sap.sid": sc.sap["sid"]},
                                 *((svc_trace, bid) if sc.trace_core else (None, None)))
                if total > SLOW_CALL_MS and bstatus < 500:
                    extra_logs.append(("WARN", "slow_dependency_call",
                                       f"Slow downstream call to {name} {bmethod} {path} took {int(total)} ms (threshold {SLOW_CALL_MS} ms)",
                                       {f"{p}.dependency.type": kind, f"{p}.dependency.name": name,
                                        f"{p}.dependency.duration_ms": int(total)}))
                if bstatus == 504:
                    svc_status = 500 if kind == "database" else 504
                    extra_logs.append(("ERROR", "dependency_timeout",
                                       f"Read timed out calling {name} {bmethod} {path} after {int(total)} ms",
                                       {f"{p}.dependency.type": kind, f"{p}.dependency.name": name,
                                        "exception.type": exc(svc["language"], "timeout"),
                                        "exception.message": "Read timed out"}))
                elif bstatus == 503:
                    svc_status = 502
                    extra_logs.append(("ERROR", "dependency_error",
                                       f"{name} answered 503 Service Unavailable for {bmethod} {path}",
                                       {f"{p}.dependency.type": kind, f"{p}.dependency.name": name,
                                        "exception.type": exc(svc["language"], "http"),
                                        "exception.message": "503 Service Unavailable"}))
                downstream += total
                inner += int(total * MS) + int(rng.uniform(1, 4) * MS)

            if svc_status == 200 and rng.random() < 0.002:     # background noise: rare functional error
                svc_status = 500
                extra_logs.append(("ERROR", "unhandled_exception",
                                   "Unhandled exception while processing request",
                                   {"exception.type": exc(svc["language"], rng.choice(["conflict", "validation"])),
                                    "exception.message": "Request could not be processed"}))
            if regress is not None:
                if regress["type"] == "deploy_regression" and svc_status != 500:
                    msg = regress.get("log_message", "Slow internal processing: {ms} ms")
                    extra_logs.append(("WARN", regress.get("log_pattern", "slow_internal_processing"),
                                       msg.format(n=rng.randint(1200, 2400), ms=int(own)), {}))
                if svc_status == 500:
                    extra_logs.append(("ERROR", "unhandled_exception",
                                       f"Request failed: {regress.get('exception_message', 'Internal error')}",
                                       {"exception.type": regress.get("exception_type", exc(svc["language"], "state")),
                                        "exception.message": regress.get("exception_message", "Internal error")}))
            svc_dur = own + downstream
            for s in scopes:
                self.ep_total[(s, svc_name, ep_name)].add(svc_dur)
                self.ep_own[(s, svc_name, ep_name)].add(own)
            self.versions[svc_name].add(version)
            events += 3 + len(extra_logs)
            if emit:
                res_tr = self.res_service(svc_name, version, svc["language"], svc["host"], None)
                res_lg = self.res_service(svc_name, version, svc["language"], svc["host"], f"{p}.app")
                front_res = self.res_service(sc.front["service"], sc.front["version"], sc.front["language"], sc.front["host"], None)
                pending.append((trace_id, front_res, client_id, root_id, method, 3, cursor, svc_dur + 2 * net,
                                {"http.request.method": method, "server.address": svc["host"], "url.path": route,
                                 "http.response.status_code": svc_status, "peer.service": svc_name,
                                 f"{p}.layer": "ui-client"}, svc_status >= 500))
                pending.append((svc_trace, res_tr, server_id, client_id if sc.trace_f2s else None,
                                f"{method} {route}", 2, svc_start, svc_dur,
                                {**svc_attrs, "http.request.method": method, "http.route": route, "url.path": route,
                                 "http.response.status_code": svc_status, f"{p}.layer": "service"}, svc_status >= 500))
                end = svc_start + int(svc_dur * MS)
                base = {**svc_attrs, "http.request.method": method, "http.route": route, "http.response.status_code": svc_status,
                        f"{p}.duration_ms": int(svc_dur), f"{p}.downstream_ms": int(downstream),
                        f"{p}.own_ms": int(own), "log.file.path": f"/var/log/{p}/{svc_name}/app.log",
                        "log.logger": f"{svc_name}.http.access"}
                self.log(res_lg, f"{p}.app", end, "ERROR" if svc_status >= 500 else "INFO",
                         f"{method} {route} -> {svc_status} in {int(svc_dur)} ms (downstream {int(downstream)} ms)",
                         {**base, f"{p}.log.pattern": "access"}, *log_trace)
                for sev, pattern, body, extra in extra_logs:
                    self.log(res_lg, f"{p}.app", end - int(rng.uniform(1, 20) * MS), sev, body,
                             {**svc_attrs, "http.route": route, "log.file.path": base["log.file.path"],
                              "log.logger": f"{svc_name}.service",
                              f"{p}.log.pattern": pattern, **extra}, *log_trace)
            if svc_status >= 500:
                status = svc_status
            cursor += int((svc_dur + 2 * net) * MS)

        total_ms = (cursor - t0) / MS + own_root * 0.5
        zone = "frustrated" if status >= 500 or total_ms > sc.f_ms else "tolerating" if total_ms > sc.t_ms else "satisfied"
        if emit:
            front_res = self.res_service(sc.front["service"], sc.front["version"], sc.front["language"], sc.front["host"], None)
            a = {"http.request.method": screen.get("method", "GET"), "http.route": screen["route"],
                 "url.path": screen["route"], "http.response.status_code": status, f"{p}.layer": "ui",
                 f"{p}.screen": screen["name"], **req_attrs}
            if sc.kpi == "apdex":
                a.update({"apdex.zone": zone, "apdex.threshold_ms": int(sc.t_ms)})
            if dim:
                a[sc.dim_attr] = dim
            self.span(front_res, trace_id, root_id, None, f"{screen.get('method', 'GET')} {screen['route']}", 2,
                      t0, total_ms, a, status >= 500)
            for tid, res, sid, parent, name, kind, start, dur, a2, err in pending:
                self.span(res, tid, sid, parent, name, kind, start, dur, a2, err)
            self.reqs.append((t0, screen["name"], dim, total_ms, zone, scope_ids, status >= 500))
        return events

    # ---- time sampling
    def sample_times(self, n: int, rng: random.Random) -> list[int]:
        minutes = int((self.e_ns - self.s_ns) // (60 * NS))
        cum, acc = [], 0.0
        for m in range(minutes):
            local = datetime.fromtimestamp(self.s_ns / NS + m * 60, self.sc.tz)
            acc += self.sc.weights[local.hour]
            cum.append(acc)
        out = []
        for _ in range(n):
            m = bisect.bisect_left(cum, rng.random() * acc)
            out.append(self.s_ns + m * 60 * NS + rng.randrange(60 * NS))
        out.sort()
        return out

    def load_factor(self, t: int) -> float:
        local = datetime.fromtimestamp(t / NS, self.sc.tz)
        return self.sc.weights[local.hour] / max(self.sc.weights)

    # ---- fixed emitters (independent of user requests)
    def job_runs(self) -> list[dict]:
        runs = []
        if not self.sc.sap:
            return runs
        jobs = {j["name"]: j for j in self.sc.sap.get("jobs", [])}
        for j in jobs.values():
            for dt in self.sc.occurrences(j["schedule"]):
                s = int(dt.timestamp() * NS)
                runs.append({"job": j, "s": s, "e": s + j["duration_min"] * 60 * NS, "trigger": "scheduled",
                             "user": j["user"], "incident": None})
        for inc in self.sc.incidents:
            if inc["type"] == "sap_batch_contention":
                j = jobs[inc["job"]]
                runs.append({"job": j, "s": inc["_s"], "e": inc["_e"], "trigger": "manual",
                             "user": inc.get("job_user", "SUPPORT_N2"), "incident": inc["id"]})
        return runs

    def emit_sap_fixed(self) -> None:
        sc, sap = self.sc, self.sc.sap
        if not sap:
            return
        rng = random.Random(sc.seed + 1)
        runs = self.job_runs()
        res_jobs = self.res_sap("sap.jobs")
        for r in runs:
            j = r["job"]
            base = {"sap.sid": sap["sid"], "sap.job.name": j["name"], "sap.job.report": j["report"],
                    "sap.job.user": r["user"], "sap.job.trigger": r["trigger"],
                    "sap.job.planned_start": j["schedule"], "sap.job.work_processes": j.get("work_processes", 4)}
            self.log(res_jobs, "sap.jobs", r["s"], "INFO",
                     f"Job {j['name']} started (report {j['report']}, user {r['user']}, trigger {r['trigger']}, planned start {j['schedule']})",
                     {**base, "sap.event": "job_started", "sap.job.status": "running"})
            if r["e"] <= self.e_ns:
                secs = int((r["e"] - r["s"]) / NS)
                self.log(res_jobs, "sap.jobs", r["e"], "INFO",
                         f"Job {j['name']} finished after {secs} s",
                         {**base, "sap.event": "job_finished", "sap.job.status": "finished", "sap.job.duration_s": secs})
        res_wp, res_sys, res_m = self.res_sap("sap.workprocess"), self.res_sap("sap.syslog"), self.res_sap(None)
        dia, bgd = sap.get("dialog_wp", 40), sap.get("background_wp", 12)
        t = self.s_ns
        while t < self.e_ns:
            load = self.load_factor(t)
            act = self.active(t)
            busy = dia * (0.12 + 0.3 * load) * rng.uniform(0.85, 1.15)
            cpu = 12 + 30 * load + rng.uniform(-3, 3)
            queue = 0
            bg = sum(r["job"].get("work_processes", 4) for r in runs if r["s"] <= t < r["e"])
            contention = [i for i in act if i["type"] == "sap_batch_contention"]
            if contention:
                busy = dia * rng.uniform(0.93, 1.0)
                queue = rng.randint(6, 38)
                cpu = rng.uniform(88, 99)
            elif bg:
                cpu += 18
            if any(i["type"] == "sap_http_slow" for i in act):
                busy *= 1.1
            busy_i = min(dia, int(round(busy)))
            self.log(res_wp, "sap.workprocess", t, "INFO",
                     f"WP snapshot DIA {busy_i}/{dia} busy, BGD {min(bgd, bg)}/{bgd} busy, dialog queue {queue}, CPU {cpu:.0f}%",
                     {"sap.sid": sap["sid"], "sap.wp.dialog.total": dia, "sap.wp.dialog.busy": busy_i,
                      "sap.wp.dialog.busy_pct": round(100.0 * busy_i / dia, 1), "sap.wp.dialog.queue_length": queue,
                      "sap.wp.background.total": bgd, "sap.wp.background.busy": min(bgd, bg),
                      "sap.cpu.utilization_pct": round(min(cpu, 100.0), 1)})
            if contention and rng.random() < 0.5:
                self.log(res_sys, "sap.syslog", t + rng.randrange(60 * NS), "WARN",
                         f"No free dialog work process: {queue} requests waiting in dispatcher queue",
                         {"sap.sid": sap["sid"], "sap.event": "dialog_wp_saturation", "sap.syslog.area": "Q0",
                          "sap.wp.dialog.queue_length": queue})
            for inc in act:
                if inc["type"] == "sap_http_slow":
                    for _ in range(3):
                        q = rng.randint(20, 90)
                        self.log(res_sys, "sap.syslog", t + rng.randrange(60 * NS), "WARN",
                                 f"ICM: no free worker thread available, request queued (threads in use 250/250, queue length {q})",
                                 {"sap.sid": sap["sid"], "sap.event": "icm_thread_exhaustion", "sap.syslog.area": "ICM",
                                  "sap.icm.threads.in_use": 250, "sap.icm.threads.max": 250, "sap.icm.queue_length": q})
            if (t - self.s_ns) % (300 * NS) == 0:
                self.gauge(res_m, t, {"system.cpu.utilization": (min(cpu, 100.0) / 100, "1"),
                                      "system.memory.utilization": (rng.uniform(0.62, 0.7), "1")})
            t += 60 * NS

    def emit_service_fixed(self) -> None:
        sc, p = self.sc, self.p
        rng = random.Random(sc.seed + 2)
        hosts = [(sc.front["service"], sc.front)] + list(sc.services.items())
        t = self.s_ns
        while t < self.e_ns:
            load = self.load_factor(t)
            act = self.active(t)
            for name, node in hosts:
                cpu = 0.08 + 0.32 * load + rng.uniform(-0.03, 0.03)
                if any(i["type"] == "deploy_regression" and i["service"] == name for i in act):
                    cpu = rng.uniform(0.82, 0.97)
                res = self.res_service(name, self.version_at(name, t), node["language"], node["host"], None)
                self.gauge(res, t, {"system.cpu.utilization": (max(cpu, 0.02), "1"),
                                    "system.memory.utilization": (rng.uniform(0.45, 0.6), "1")})
            t += 300 * NS
        for inc in sc.incidents:                               # deployment and rollback events
            if inc["type"] != "deploy_regression":
                continue
            svc = sc.services[inc["service"]]
            for ts, ver, verb in ((inc["_s"], inc["new_version"], "deployment"),
                                  (inc["_e"], inc.get("rollback_version", svc["version"]), "rollback")):
                if ts >= self.e_ns:
                    continue
                res = self.res_service(inc["service"], ver, svc["language"], svc["host"], f"{p}.app")
                self.log(res, f"{p}.app", ts, "INFO",
                         f"Started {inc['service']} v{ver} in {rng.uniform(9, 16):.1f} seconds ({verb})",
                         {f"{p}.log.pattern": "deployment", f"{p}.deployment.kind": verb,
                          f"{p}.deployment.version": ver,
                          "log.file.path": f"/var/log/{p}/{inc['service']}/app.log",
                          "log.logger": f"{inc['service']}.startup"})

    def emit_st03(self) -> None:
        sc, sap = self.sc, self.sc.sap
        if not sap:
            return
        rng = random.Random(sc.seed + 3)
        res = self.res_sap("sap.st03")
        runs = self.job_runs()
        for b in range(int((self.e_ns - self.s_ns) // (300 * NS))):
            t = self.s_ns + b * 300 * NS
            load = self.load_factor(t)
            contention = any(i["type"] == "sap_batch_contention" for i in self.active(t))
            jobs_running = [r for r in runs if r["s"] <= t < r["e"]]
            steps, proc, wait = self.sap_calls.get(b, [0, 0.0, 0.0])
            rows = {"HTTP": (steps, proc / steps if steps else 0.0, wait / steps if steps else 0.0)}
            d = 560 * rng.uniform(0.9, 1.1)
            rows["DIALOG"] = (int(900 * load * rng.uniform(0.8, 1.2)) + 5,
                              d * (rng.uniform(5, 8) if contention else 1), d * rng.uniform(3.5, 6) if contention else rng.uniform(5, 20))
            r = 290 * rng.uniform(0.9, 1.1)
            rows["RFC"] = (int(350 * load * rng.uniform(0.8, 1.2)) + 20 + (600 if jobs_running else 0),
                           r * (rng.uniform(2.5, 4) if contention else 1), r * rng.uniform(1.2, 2.2) if contention else rng.uniform(3, 12))
            rows["UPDATE"] = (int(200 * load * rng.uniform(0.8, 1.2)) + 2, 85 * rng.uniform(0.9, 1.1), rng.uniform(1, 5))
            rows["BACKGROUND"] = ((sum(x["job"].get("work_processes", 4) for x in jobs_running) * 5 + rng.randint(0, 3)),
                                  rng.uniform(38000, 62000) if jobs_running else rng.uniform(900, 2500), rng.uniform(0, 30))
            for task in TASK_TYPES:
                n, resp, w = rows[task]
                resp, w = float(resp), float(min(w, resp * 0.9))
                work = max(resp - w, 0.0)
                cpu, db = work * (0.42 if task == "BACKGROUND" else 0.28), work * (0.5 if task == "BACKGROUND" else 0.45)
                self.log(res, "sap.st03", t + 300 * NS - 1, "INFO",
                         f"ST03 workload {task}: steps={n} avg_resp={resp:.0f}ms wait={w:.0f}ms cpu={cpu:.0f}ms db={db:.0f}ms",
                         {"sap.sid": sap["sid"], "sap.st03.task_type": task, "sap.st03.steps": int(n),
                          "sap.st03.avg_response_time_ms": float(resp), "sap.st03.avg_wait_time_ms": float(w),
                          "sap.st03.avg_cpu_time_ms": float(cpu), "sap.st03.avg_db_time_ms": float(db),
                          "sap.st03.interval_s": 300})

    def pad(self, n: int) -> None:
        """Housekeeping log lines used to land exactly on the requested number of events."""
        sc, p = self.sc, self.p
        rng = random.Random(sc.seed + 4)
        names = list(sc.services)
        tasks = ["CacheRefreshJob", "HealthCheck", "ConnectionPoolMonitor", "MetricsFlush"]
        for _ in range(n):
            name = rng.choice(names)
            svc = sc.services[name]
            t = self.s_ns + rng.randrange(self.e_ns - self.s_ns)
            res = self.res_service(name, self.version_at(name, t), svc["language"], svc["host"], f"{p}.app")
            task = rng.choice(tasks)
            self.log(res, f"{p}.app", t, "INFO", f"Scheduled task {task} completed in {rng.randint(8, 140)} ms",
                     {f"{p}.log.pattern": "scheduled_task", "log.file.path": f"/var/log/{p}/{name}/app.log",
                      "log.logger": f"{name}.scheduling.{task}"})

    # ---- orchestration
    def run(self) -> dict:
        sc = self.sc
        self.emit_sap_fixed()
        self.emit_service_fixed()
        n_st03 = int((self.e_ns - self.s_ns) // (300 * NS)) * len(TASK_TYPES) if sc.sap else 0
        budget = sc.total_events - self.w.total - n_st03
        if budget <= 0:
            die(f"total_events={sc.total_events} is too small: the fixed part of the dataset (SAP snapshots, ST03, "
                f"metrics) already needs {self.w.total + n_st03} events for a {sc.hours} h window")
        weights = [s.get("weight", 1) for s in sc.screens]
        probe = random.Random(sc.seed + 5)                    # dry run to estimate events per request
        state = self.rng.getstate()
        times = self.sample_times(3000, probe)
        per_req = sum(self.simulate(t, probe.choices(sc.screens, weights)[0], probe, emit=False) for t in times) / 3000
        self.rng.setstate(state)
        for d in (self.dep, self.ep_total, self.ep_own, self.icm_queue, self.sap_calls, self.versions):
            d.clear()
        n_req = int(budget * 0.985 / per_req)
        for t in self.sample_times(n_req, self.rng):
            self.simulate(t, self.rng.choices(sc.screens, weights)[0], self.rng, emit=True)
        self.emit_st03()
        missing = sc.total_events - self.w.total
        if missing > 0:
            self.pad(missing)
        self.w.close()
        return {"requests": n_req, "padding": max(missing, 0), "overshoot": max(-missing, 0)}


# --------------------------------------------------------------------------- ground truth
TEXT = {
    "fr": {
        "sap_batch_contention": (
            "Le job SAP {job} (report {report}), normalement planifié à {planned}, a été lancé manuellement par {user} "
            "à {start} et a tourné jusqu'à {end}. Il a saturé les work process de dialogue de SAP, ce qui a ralenti "
            "tous les appels HTTP vers SAP.",
            "Arrêter ou replanifier le job dans sa fenêtre nocturne, interdire son lancement en journée et lui "
            "dédier un groupe de serveurs batch pour qu'il ne consomme plus les work process de dialogue."),
        "external_slow": (
            "La dépendance externe {external} a répondu en {avg} ms en moyenne (contre {base} ms en temps normal) "
            "entre {start} et {end}, avec des timeouts. Le temps de traitement propre des services est resté normal.",
            "Escalader chez le fournisseur de {external}, puis mettre en place un timeout court, un circuit breaker "
            "et un mode dégradé (valeur en cache) pour ne plus bloquer l'écran."),
        "deploy_regression": (
            "Le déploiement de {service} en version {version} à {start} a dégradé l'endpoint {endpoint} : son temps "
            "de traitement propre est passé de {base} ms à {avg} ms, alors que SAP et les dépendances externes "
            "répondaient normalement. Retour à la normale après le rollback de {end}.",
            "Rollback vers la version précédente (fait à {end}), puis correction de la régression avant un nouveau "
            "déploiement, avec un test de performance sur {endpoint} dans la chaîne de livraison."),
        "sap_http_slow": (
            "Entre {start} et {end}, la couche HTTP/HTTPS de SAP (ICM) était saturée : les requêtes attendaient "
            "{avg} ms en file d'attente avant d'être traitées. Le traitement SAP lui-même (ST03) restait normal, "
            "aucun job ne tournait et les work process n'étaient pas saturés.",
            "Augmenter le nombre de threads et de connexions ICM (icm/max_threads, icm/max_conn), vérifier le "
            "keep-alive et le pool de connexions côté services appelants, puis superviser la file d'attente ICM."),
        "database_slow": (
            "La base de données {database} ({system}) a répondu en {avg} ms en moyenne (contre {base} ms en temps "
            "normal) entre {start} et {end}, avec des timeouts. Le temps de traitement propre des services et les "
            "autres dépendances sont restés normaux.",
            "Analyser côté base les requêtes lentes de la période (plan d'exécution, verrous, statistiques, index, "
            "saturation des sessions), puis mettre un timeout court et une supervision des temps de requête."),
        "error_burst": (
            "L'endpoint {endpoint} de {service} a renvoyé un taux d'erreurs anormal entre {start} et {end}.",
            "Analyser l'exception remontée dans les logs du service et corriger la cause applicative."),
        "concurrent": "Attention : cet incident se superpose à {ids}. Pendant le recouvrement, les mesures de cette "
                      "fenêtre cumulent les deux causes, et la bonne réponse doit citer les deux.",
        "layers": ["Couche 1, interface utilisateur : l'Apdex chute et les écrans touchés sont identifiés",
                   "Couche 2, services : le service et l'endpoint concernés sont identifiés",
                   "Couche 3, cause racine : quelle dépendance, ou le service lui-même"],
    },
    "en": {
        "sap_batch_contention": (
            "SAP job {job} (report {report}), normally scheduled at {planned}, was started manually by {user} at "
            "{start} and ran until {end}. It saturated SAP dialog work processes, slowing every HTTP call to SAP.",
            "Stop or reschedule the job in its night window, forbid daytime runs, and give it a dedicated batch "
            "server group so it stops consuming dialog work processes."),
        "external_slow": (
            "External dependency {external} answered in {avg} ms on average (versus {base} ms normally) between "
            "{start} and {end}, with timeouts. The services' own processing time stayed normal.",
            "Escalate to the {external} provider, then add a short timeout, a circuit breaker and a degraded mode "
            "(cached value) so the screen is no longer blocked."),
        "deploy_regression": (
            "Deploying {service} version {version} at {start} degraded endpoint {endpoint}: its own processing "
            "time went from {base} ms to {avg} ms while SAP and external dependencies answered normally. Back to "
            "normal after the rollback at {end}.",
            "Roll back to the previous version (done at {end}), fix the regression before redeploying, and add a "
            "performance test on {endpoint} to the delivery pipeline."),
        "sap_http_slow": (
            "Between {start} and {end}, the SAP HTTP/HTTPS layer (ICM) was saturated: requests waited {avg} ms in "
            "queue before being processed. SAP processing itself (ST03) stayed normal, no job was running and work "
            "processes were not saturated.",
            "Raise ICM threads and connections (icm/max_threads, icm/max_conn), check keep-alive and connection "
            "pooling in the calling services, then monitor the ICM queue."),
        "database_slow": (
            "Database {database} ({system}) answered in {avg} ms on average (versus {base} ms normally) between "
            "{start} and {end}, with timeouts. The services' own processing time and the other dependencies stayed "
            "normal.",
            "Analyse the slow queries of the period on the database side (execution plan, locks, statistics, "
            "indexes, session saturation), then add a short timeout and monitor query times."),
        "error_burst": (
            "Endpoint {endpoint} of {service} returned an abnormal error rate between {start} and {end}.",
            "Analyse the exception in the service logs and fix the application cause."),
        "concurrent": "Note: this incident overlaps with {ids}. During the overlap the figures of this window "
                      "combine both causes, and the right answer must name both.",
        "layers": ["Layer 1, UI: Apdex drops and the affected screens are identified",
                   "Layer 2, services: the service and endpoint are identified",
                   "Layer 3, root cause: which dependency, or the service itself"],
    },
}


def apdex(rows) -> float | None:
    n = len(rows)
    if not n:
        return None
    sat = sum(1 for r in rows if r[4] == "satisfied")
    tol = sum(1 for r in rows if r[4] == "tolerating")
    return round((sat + tol / 2) / n, 3)


def custom_attributes(sc: Scenario) -> list[dict]:
    """Inventory of the attributes declared in the scenario: where they land and where they come from."""
    out = []

    def add(block: dict, where: str, signal: str) -> None:
        for key, spec in (block.get("attributes") or {}).items():
            meta = spec if isinstance(spec, dict) else {}
            out.append({"attribute": key, "system": where, "found_in": signal,
                        "source": meta.get("source", "unspecified"),
                        "propagated": sorted(reach(spec)) if where.startswith(sc.front["service"]) else [],
                        "identifier": isinstance(spec, dict) and ("format" in spec or bool(spec.get("uuid"))),
                        "description": meta.get("description", "")})
    add(sc.front, sc.front["service"], "UI spans")
    for scr in sc.screens:
        add(scr, f"{sc.front['service']} / {scr['name']}", "UI spans")
    for svc in sc.services.values():
        add(svc, svc["name"], "service spans and logs")
    for (svc, ep), e in sc.endpoints.items():
        add(e, f"{svc} {ep}", "service spans and logs")
        for c in e.get("calls", []):
            add(c, f"{svc} -> {c.get('sap') or c.get('external') or c.get('database')}", "dependency spans")
    if sc.sap:
        add(sc.sap, sc.sap["name"], "every SAP log record")
    for x in list(sc.externals.values()) + list(sc.databases.values()):
        add(x, x["name"], "dependency spans")
    return out


def latency(rows) -> dict:
    """Response time and error rate of a set of user requests: the reading used when no KPI is defined."""
    n = len(rows)
    if not n:
        return {"requests": 0, "avg_ms": None, "p95_ms": None, "error_rate_pct": None}
    durs = sorted(r[3] for r in rows)
    return {"requests": n, "avg_ms": round(sum(durs) / n), "p95_ms": round(durs[min(n - 1, int(0.95 * n))]),
            "error_rate_pct": round(100.0 * sum(1 for r in rows if r[6]) / n, 1)}


def build_truth(g: Generator, run_info: dict) -> tuple[dict, dict]:
    sc = g.sc
    txt = TEXT.get(sc.lang, TEXT["en"])
    hm = lambda dt: dt.astimezone(sc.tz).strftime("%H:%M")
    iso = lambda dt: dt.astimezone(sc.tz).isoformat(timespec="seconds")
    base_rows = [r for r in g.reqs if not r[5]]
    by_screen = defaultdict(list)
    for r in g.reqs:
        by_screen[r[1]].append(r)
    jobs = {j["name"]: j for j in (sc.sap or {}).get("jobs", [])}
    incidents = []
    for inc in sc.incidents:
        rows = [r for r in g.reqs if inc["id"] in r[5]]
        screens = {}
        for name in by_screen:
            sub = [r for r in rows if r[1] == name]
            if sub:
                base_sub = [r for r in base_rows if r[1] == name]
                lat, base_lat = latency(sub), latency(base_sub)
                screens[name] = {**lat, "baseline_avg_ms": base_lat["avg_ms"],
                                 "baseline_error_rate_pct": base_lat["error_rate_pct"]}
                if sc.kpi == "apdex":
                    screens[name].update(apdex=apdex(sub), baseline_apdex=apdex(base_sub))
        if sc.kpi == "apdex":
            impacted = sorted((n for n, v in screens.items() if v["apdex"] < sc.target), key=lambda n: screens[n]["apdex"])
        else:                                                  # no KPI: twice the usual response time, or errors
            impacted = sorted((n for n, v in screens.items()
                               if v["baseline_avg_ms"] and (v["avg_ms"] >= 2 * v["baseline_avg_ms"]
                                                            or v["error_rate_pct"] >= (v["baseline_error_rate_pct"] or 0) + 3)),
                              key=lambda n: -screens[n]["avg_ms"])
        t, iid = inc["type"], inc["id"]
        fmt = {"start": hm(inc["_start_dt"]), "end": hm(inc["_end_dt"])}
        evidence, services = [], []
        ds = g.ds
        L = (lambda f, en: f) if sc.lang == "fr" else (lambda f, en: en)      # evidence in the customer language
        app = ds("logs", f"{g.p}.app")
        if t == "sap_batch_contention":
            j = jobs[inc["job"]]
            fmt.update(job=j["name"], report=j["report"], planned=j["schedule"], user=inc.get("job_user", "SUPPORT_N2"))
            st, b0 = g.dep[(iid, "sap", sc.sap["name"])], g.dep[("baseline", "sap", sc.sap["name"])]
            evidence = [
                {"stream": ds("logs", "sap.jobs"), "fact": L(
                    f"sap.job.name={j['name']}, sap.job.trigger=manual, démarré à {fmt['start']} alors qu'il est planifié à {j['schedule']}",
                    f"sap.job.name={j['name']}, sap.job.trigger=manual, started {fmt['start']}, planned start {j['schedule']}")},
                {"stream": ds("logs", "sap.workprocess"), "fact": L(
                    "sap.wp.dialog.busy_pct au-dessus de 90 %, avec une file d'attente de dialogue",
                    "sap.wp.dialog.busy_pct above 90 % with a dialog queue")},
                {"stream": ds("logs", "sap.st03"), "fact": L(
                    "avg_wait_time_ms élevé pour DIALOG et HTTP, activité et CPU élevés pour BACKGROUND",
                    "DIALOG and HTTP avg_wait_time_ms high, BACKGROUND steps and CPU high")},
                {"stream": ds("logs", "sap.syslog"), "fact": "sap.event=dialog_wp_saturation"},
                {"stream": ds("traces"), "fact": L(
                    f"les appels vers {sc.sap['name']} durent {st.avg():.0f} ms en moyenne, contre {b0.avg():.0f} ms en temps normal",
                    f"calls to {sc.sap['name']} average {st.avg():.0f} ms versus {b0.avg():.0f} ms in baseline")}]
        elif t in ("external_slow", "database_slow"):
            kind = "external" if t == "external_slow" else "database"
            name = inc[kind]
            st, b0 = g.dep[(iid, kind, name)], g.dep[("baseline", kind, name)]
            fmt.update(avg=int(st.avg()), base=int(b0.avg()), **{kind: name})
            if kind == "database":
                fmt.update(system=sc.databases[name].get("system", "SQL"))
            evidence = [
                {"stream": ds("traces"), "fact": L(
                    f"les appels vers {name} durent {st.avg():.0f} ms en moyenne (p95 {st.p95():.0f} ms), contre {b0.avg():.0f} ms en temps normal",
                    f"calls to {name} average {st.avg():.0f} ms (p95 {st.p95():.0f} ms) versus {b0.avg():.0f} ms in baseline")},
                {"stream": app, "fact": L(
                    f"WARN slow_dependency_call et ERROR dependency_timeout qui nomment {name}",
                    f"WARN slow_dependency_call and ERROR dependency_timeout naming {name}")},
                {"stream": ds("logs", "sap.st03") if sc.sap else ds("traces"), "fact": L(
                    "les autres dépendances et le temps propre des services gardent leur niveau normal",
                    "other dependencies and the services' own time keep their normal level")}]
        elif t in ("deploy_regression", "error_burst"):
            key = (inc["service"], inc["endpoint"])
            own, b0 = g.ep_own[(iid, *key)], g.ep_own[("baseline", *key)]
            fmt.update(service=inc["service"], endpoint=inc["endpoint"], version=inc.get("new_version", ""),
                       avg=int(own.avg()), base=int(b0.avg()))
            evidence = [
                {"stream": ds("traces"), "fact": L(
                    f"service.version={inc.get('new_version')} apparaît à {fmt['start']} pour {inc['service']} et disparaît à {fmt['end']}",
                    f"service.version={inc.get('new_version')} appears at {fmt['start']} for {inc['service']} and disappears at {fmt['end']}")},
                {"stream": app, "fact": L(
                    f"{g.p}.own_ms vaut {own.avg():.0f} ms en moyenne contre {b0.avg():.0f} ms en temps normal, {g.p}.downstream_ms ne bouge pas ; "
                    f"ligne de déploiement ; WARN {inc.get('log_pattern', 'slow_internal_processing')}",
                    f"{g.p}.own_ms averages {own.avg():.0f} ms versus {b0.avg():.0f} ms in baseline while {g.p}.downstream_ms is unchanged; "
                    f"deployment log line; WARN {inc.get('log_pattern', 'slow_internal_processing')}")},
                {"stream": ds("traces"), "fact": L(
                    "les appels vers les dépendances gardent leur durée normale",
                    "calls to the dependencies keep their normal duration")}]
        elif t == "sap_http_slow":
            q = g.icm_queue[iid]
            fmt.update(avg=int(q.avg()))
            evidence = [
                {"stream": ds("logs", "sap.icm"), "fact": L(
                    f"sap.icm.queue_time_ms vaut {q.avg():.0f} ms en moyenne (0 en temps normal) alors que sap.icm.processing_time_ms reste normal ; quelques 503",
                    f"sap.icm.queue_time_ms averages {q.avg():.0f} ms (0 in baseline) while sap.icm.processing_time_ms is normal; some 503")},
                {"stream": ds("logs", "sap.syslog"), "fact": L(
                    "sap.event=icm_thread_exhaustion (250 threads utilisés sur 250)",
                    "sap.event=icm_thread_exhaustion (threads in use 250/250)")},
                {"stream": ds("logs", "sap.st03"), "fact": L(
                    "avg_response_time_ms normal pour HTTP : le traitement interne de SAP n'est pas le goulot",
                    "HTTP avg_response_time_ms normal: SAP internal processing is not the bottleneck")},
                {"stream": ds("logs", "sap.jobs"), "fact": L(
                    "aucun job ne tourne dans la fenêtre ; les work process ne sont pas saturés",
                    "no job running in the window; work processes not saturated")}]
        for (scope, svc, ep), st in g.ep_total.items():
            if scope == iid:
                b = g.ep_total[("baseline", svc, ep)]
                if b.n and st.avg() > 2.5 * b.avg():
                    services.append({"service": svc, "endpoint": ep, "avg_ms": st.avg(), "baseline_avg_ms": b.avg()})
        cause, fix = txt[t]
        concurrent = [o["id"] for o in sc.incidents
                      if o["id"] != iid and o["_s"] < inc["_e"] and inc["_s"] < o["_e"]]
        cause = cause.format(**fmt)
        if concurrent:
            cause += " " + txt["concurrent"].format(ids=", ".join(concurrent))
        incidents.append({
            "id": iid, "group": inc.get("group"), "type": t, "title": inc.get("title", t),
            "start": iso(inc["_start_dt"]), "end": iso(inc["_end_dt"]),
            "start_local": fmt["start"], "end_local": fmt["end"],
            "requests": len(rows), "apdex": apdex(rows) if sc.kpi == "apdex" else None,
            **{k: v for k, v in latency(rows).items() if k != "requests"},
            "baseline_avg_ms": latency(base_rows)["avg_ms"],
            "impacted_screens": impacted, "screens": screens,
            "impacted_endpoints": sorted(services, key=lambda s: -s["avg_ms"]),
            "investigation_layers": txt["layers"],
            "concurrent_with": concurrent,
            "root_cause": cause, "remediation": fix.format(**fmt), "evidence": evidence})

    bucket = 900 * NS
    timeline = []
    grouped = defaultdict(list)
    for r in g.reqs:
        grouped[(r[0] - g.s_ns) // bucket].append(r)
    for b in range(int((g.e_ns - g.s_ns) // bucket)):
        rows = grouped.get(b, [])
        ts = datetime.fromtimestamp((g.s_ns + b * bucket) / NS, sc.tz)
        timeline.append({"t": ts.strftime("%Y-%m-%d %H:%M"), **latency(rows),
                         "apdex": apdex(rows) if sc.kpi == "apdex" else None})
    truth = {
        "customer": sc.raw["customer"]["name"], "namespace": sc.slug,
        "window": {"start": iso(sc.start), "end": iso(sc.end), "timezone": str(sc.tz)},
        "kpi": sc.kpi,
        "apdex": {"satisfied_ms": sc.t_ms, "frustrated_ms": sc.f_ms, "target": sc.target,
                  "overall": apdex(g.reqs), "baseline": apdex(base_rows)} if sc.kpi == "apdex" else None,
        "response_time": {"overall": latency(g.reqs), "baseline": latency(base_rows)},
        "decoys": [f"{j['name']} runs every night at {j['schedule']} for about {j['duration_min']} min with no user impact"
                   for j in jobs.values()],
        "incidents": incidents}
    summary = {
        "customer": sc.raw["customer"]["name"], "namespace": sc.slug, "attribute_prefix": g.p,
        "window": truth["window"], "seed": sc.seed,
        "total_events": g.w.total, "requested_events": sc.total_events,
        "user_requests": run_info["requests"], "padding_events": run_info["padding"],
        "events_by_data_stream": dict(sorted(g.w.counts.items())),
        "events_by_signal": {s: sum(v for k, v in g.w.counts.items() if k.startswith(s)) for s in ("traces", "logs", "metrics")},
        "kpi": sc.kpi, "apdex": truth["apdex"], "response_time": truth["response_time"],
        "by_screen": {n: {**latency(r), "apdex": apdex(r) if sc.kpi == "apdex" else None}
                      for n, r in sorted(by_screen.items())},
        "custom_attributes": custom_attributes(sc),
        "correlation": {"trace_frontend_to_services": sc.trace_f2s, "trace_in_service_logs": sc.trace_logs,
                        "trace_in_core_system_logs": sc.trace_core,
                        "propagated_keys": [{"attribute": c["attribute"], "reaches": c["propagated"],
                                             "identifier": c["identifier"]}
                                            for c in custom_attributes(sc) if c["propagated"]]},
        "service_versions": {k: sorted(v) for k, v in g.versions.items()},
        "timeline_15min": timeline}
    return truth, summary


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("scenario")
    ap.add_argument("--out", default="out")
    ap.add_argument("--end", help="override dataset.end: now | midnight | last_weekday | ISO datetime")
    ap.add_argument("--total-events", type=int, help="override dataset.total_events")
    args = ap.parse_args()
    raw = json.loads(Path(args.scenario).read_text(encoding="utf-8"))
    if raw.get("model") == "deal_flow":                       # asynchronous deal lifecycle: see deal_flow.py
        import deal_flow
        return deal_flow.run(raw, Path(args.out), args.end, args.total_events)
    sc = Scenario(raw, args.end, args.total_events)
    out = Path(args.out)
    g = Generator(sc, out)
    info = g.run()
    truth, summary = build_truth(g, info)
    (out / "ground_truth.json").write_text(json.dumps(truth, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "scenario.json").write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"Window   : {truth['window']['start']} -> {truth['window']['end']}")
    print(f"Events   : {summary['total_events']} (requested {summary['requested_events']}), "
          f"{summary['user_requests']} user requests, {summary['padding_events']} padding log lines")
    for k, v in summary["events_by_data_stream"].items():
        print(f"  {k:<42} {v:>8}")
    a, rt = truth["apdex"], truth["response_time"]
    warn = []
    if a:
        print(f"Apdex    : overall {a['overall']}, baseline {a['baseline']} (target {a['target']})")
        if a["baseline"] is not None and a["baseline"] < a["target"]:
            warn.append(f"baseline Apdex {a['baseline']} is below the target {a['target']}: lower base latencies")
    else:
        print(f"KPI      : none. Response time: baseline avg {rt['baseline']['avg_ms']} ms, p95 {rt['baseline']['p95_ms']} ms, "
              f"errors {rt['baseline']['error_rate_pct']} %")
    co = summary["correlation"]
    print("Correlation: trace_id " + ("UI -> services" if co["trace_frontend_to_services"] else "stops at the UI")
          + (", in service logs" if co["trace_in_service_logs"] else ", not in service logs")
          + (", in core system logs" if co["trace_in_core_system_logs"] else "")
          + "; keys: " + (", ".join(f"{k['attribute']} -> {'+'.join(k['reaches'])}" for k in co["propagated_keys"]) or "none"))
    if summary["custom_attributes"]:
        by = defaultdict(int)
        for c in summary["custom_attributes"]:
            by[c["source"]] += 1
        print("Attributes: " + ", ".join(f"{n} from {src}" for src, n in sorted(by.items())))
    for i in truth["incidents"]:
        level = f"apdex {i['apdex']}" if a else f"avg {i['avg_ms']} ms (baseline {i['baseline_avg_ms']} ms), errors {i['error_rate_pct']} %"
        print(f"  {i['id']:<7} {i['start_local']}-{i['end_local']} {i['type']:<22} {level} "
              f"screens: {', '.join(i['impacted_screens']) or 'NONE'}")
        if not i["impacted_screens"]:
            warn.append(f"{i['id']} does not visibly degrade any screen "
                        f"({'none below the Apdex target' if a else 'none at twice its usual response time'}): strengthen it")
        if i["requests"] < 50:
            warn.append(f"{i['id']} only has {i['requests']} requests in its window: move it to a busier hour or raise total_events")
    if info["overshoot"]:
        warn.append(f"dataset is {info['overshoot']} events above the requested total")
    for wmsg in warn:
        print(f"WARNING: {wmsg}")


if __name__ == "__main__":
    main()
