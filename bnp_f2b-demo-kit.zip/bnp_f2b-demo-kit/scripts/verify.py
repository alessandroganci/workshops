#!/usr/bin/env python3
"""Check that the dataset really is in Elasticsearch and that every incident is visible in it.

    python3 verify.py out/ [--env-file demo.env] [--wait 120]

1. Counts documents per data stream and compares with out/summary.json.
2. Recomputes the Apdex of each incident window with ES|QL and compares with out/ground_truth.json.

Exit code 0 when logs and traces match exactly and every incident is visible. Metrics are reported but never
block: time series data streams can refuse old timestamps (see references/elastic-setup.md).
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import esql, load_env  # noqa: E402


def counts(cfg: dict, ns: str) -> dict[str, int]:
    found: dict[str, int] = {}
    for typ in ("logs", "traces", "metrics"):
        try:
            rows = esql(cfg, f"FROM {typ}-*-{ns} | STATS n = COUNT(*) BY dataset = data_stream.dataset")
        except SystemExit as e:                                # no data stream of this type yet
            if "Unknown index" in str(e) or "no such index" in str(e) or "verification_exception" in str(e):
                continue
            raise
        for r in rows:
            found[f"{typ}-{r['dataset']}-{ns}"] = r["n"]
    return found


def verify_deal_flow(cfg: dict, ns: str, p: str, truth: dict, found: dict) -> bool:
    """Deal lifecycle model: recompute the descent time of the slowdown and the lost deals of the loss incident."""
    ok = True
    deal = f"logs-{p}.deal*-{ns}"
    if not found.get(f"logs-{p}.deal.otel-{ns}"):
        print("  no deal lifecycle log indexed, cannot check incidents")
        return False
    print("\nIncident visibility (recomputed in Elasticsearch):")
    for inc in truth["incidents"]:
        if inc["type"] == "queue_slowdown":
            from datetime import datetime, timedelta
            end = (datetime.fromisoformat(inc["end"]) + timedelta(minutes=30)).isoformat()
            rows = esql(cfg, f"FROM {deal} | WHERE @timestamp >= ?start AND @timestamp < ?end AND attributes.{p}.event == \"deal_received_bo\" "
                             f"| STATS n = COUNT(*), v = AVG(attributes.{p}.descent_time_min)", [{"start": inc["start"]}, {"end": end}])
            got = round(rows[0]["v"], 1) if rows and rows[0]["n"] else None
            exp = inc["descent"]["avg_min"]
            vis = got is not None and abs(got - exp) <= 0.2 and got > truth["kpi_rule"]["descent_ok_min"]
            print(f"  {inc['id']:<8}{inc['start_local']}-{inc['end_local']}  average descent expected {exp} min, in Elasticsearch {got}  "
                  f"{'ok' if vis else 'NOT VISIBLE'}")
        else:
            rows = esql(cfg, f"FROM {deal} | WHERE attributes.{p}.desk == ?desk AND attributes.{p}.event == \"deal_validated_mo\" "
                             f"AND attributes.{p}.deal.status == \"PENDING_MO\" AND @timestamp >= ?start AND @timestamp < ?end "
                             f"| STATS n = COUNT(*)", [{"desk": inc["desk"]}, {"start": inc["start"]}, {"end": inc["end"]}])
            got = rows[0]["n"] if rows else 0
            vis = got == inc["lost_deals"]
            print(f"  {inc['id']:<8}{inc['start_local']}-{inc['end_local']}  lost deals expected {inc['lost_deals']}, in Elasticsearch {got}  "
                  f"{'ok' if vis else 'NOT VISIBLE'}")
        ok &= vis
    return ok


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("out")
    ap.add_argument("--env-file")
    ap.add_argument("--wait", type=int, default=120, help="seconds to wait for indexing to catch up")
    args = ap.parse_args()
    cfg = load_env(args.env_file)
    out = Path(args.out)
    summary = json.loads((out / "summary.json").read_text(encoding="utf-8"))
    truth = json.loads((out / "ground_truth.json").read_text(encoding="utf-8"))
    ns, p = summary["namespace"], summary["attribute_prefix"]
    expected = summary["events_by_data_stream"]
    must = {k: v for k, v in expected.items() if not k.startswith("metrics-")}

    deadline = time.time() + args.wait
    while True:
        found = counts(cfg, ns)
        if all(found.get(k, 0) >= v for k, v in must.items()) or time.time() > deadline:
            break
        print(f"waiting for indexing: {sum(found.get(k, 0) for k in must)}/{sum(must.values())} logs and traces indexed "
              f"(up to {max(0, int(deadline - time.time()))} s more, --wait 0 to skip)", flush=True)
        time.sleep(10)

    ok = True
    print(f"{'data stream':<44}{'expected':>10}{'indexed':>10}")
    for k in sorted(set(expected) | set(found)):
        exp, got = expected.get(k, 0), found.get(k, 0)
        if k.startswith("metrics-"):
            if not exp:
                note = "aggregated by the OTLP endpoint (informational)"
            else:
                note = "metric points are grouped into documents" if got else "not indexed: old timestamps refused (informational)"
            print(f"{k:<44}{exp:>10}{got:>10}  {note}")
            continue
        state = "ok" if exp == got else ("DUPLICATES?" if got > exp else "MISSING")
        ok &= exp == got
        print(f"{k:<44}{exp:>10}{got:>10}  {state}")
    total_exp, total_got = sum(must.values()), sum(found.get(k, 0) for k in must)
    print(f"{'logs + traces':<44}{total_exp:>10}{total_got:>10}")

    if truth.get("model") == "deal_flow":
        ok &= verify_deal_flow(cfg, ns, p, truth, found)
        if not ok:
            sys.exit("\nVerification failed. MISSING everywhere: the data was probably sent to another project, check that the "
                     "three URLs of the env file belong to the same project. MISSING partly: wait and rerun. "
                     "DUPLICATES: the dataset was sent twice, run cleanup.py and ingest again.")
        print("\nDataset verified.")
        return
    with_kpi = truth.get("kpi", "apdex") == "apdex"
    print(f"\nIncident visibility ({'Apdex' if with_kpi else 'average response time'} recomputed in Elasticsearch):")
    where = f"FROM traces-*-{ns} | WHERE @timestamp >= ?start AND @timestamp < ?end AND attributes.{p}.screen IS NOT NULL "
    if with_kpi:
        target = truth["apdex"]["target"]
        query = where + ('| EVAL sat = CASE(attributes.apdex.zone == "satisfied", 1, 0), tol = CASE(attributes.apdex.zone == "tolerating", 1, 0) '
                         "| STATS n = COUNT(*), s = SUM(sat), t = SUM(tol) | EVAL value = ROUND((s + t / 2.0) / n, 3)")
    else:
        query = where + "| STATS n = COUNT(*), d = AVG(duration) | EVAL value = ROUND(d / 1000000)"
    for inc in truth["incidents"]:
        if not found.get(f"traces-generic.otel-{ns}"):
            print(f"  {inc['id']:<8}no trace indexed, cannot check")
            ok = False
            continue
        rows = esql(cfg, query, [{"start": inc["start"]}, {"end": inc["end"]}])
        got = rows[0]["value"] if rows and rows[0]["n"] else None
        if with_kpi:
            exp = inc["apdex"]
            visible = got is not None and got < target and abs(got - exp) < 0.01
        else:
            exp = inc["avg_ms"]
            visible = got is not None and abs(got - exp) <= max(3, 0.01 * exp)
        ok &= visible
        print(f"  {inc['id']:<8}{inc['start_local']}-{inc['end_local']}  expected {exp}  in Elasticsearch {got}  "
              f"{'ok' if visible else 'NOT VISIBLE'}")
    if not ok:
        sys.exit("\nVerification failed. MISSING everywhere: the data was probably sent to another project, check that the "
                 "three URLs of the env file belong to the same project. MISSING partly: wait and rerun. "
                 "DUPLICATES: the dataset was sent twice, run cleanup.py and ingest again.")
    print("\nDataset verified.")


if __name__ == "__main__":
    main()
