#!/usr/bin/env python3
"""Deal lifecycle generator: an asynchronous Front-to-Back chain, for scenarios with "model": "deal_flow".

A deal is validated in the front office, validated by the middle office, queued, routed by an integration bus
and received by one back office system. Each step is a span of one end-to-end trace and a business log line
carrying the deal id, so the dataset answers three questions the request model cannot: how long a deal takes
to go down the chain (minutes), at which step it waits, and which deals never arrived (lost deals).

    python3 deal_flow.py scenario.json --out out/      (also reached through generate.py)
    python3 deal_flow.py --build-agent out/            (also reached through agent.py build)

Outputs: the same files as generate.py (otlp/, ground_truth.json, summary.json, scenario.json) plus agent.json.
Data streams: traces-generic.otel-<ns>, logs-<p>.deal.otel-<ns> (business lifecycle), logs-<p>.app.otel-<ns>
(technical logs), metrics-generic.otel-<ns>.
Incident types: queue_slowdown (a queue consumer version slows message processing, the backlog grows) and
status_not_persisted (a version shows deals as validated without persisting the status, for one desk: they are
never sent downstream). Standard library only, deterministic for a seed and a window end.
"""
from __future__ import annotations

import argparse
import heapq
import json
import math
import random
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).parent))
from generate import MS, NS, Writer, attrs, die  # noqa: E402

MIN = 60 * NS
STAGES = [  # order, event, system role, label shown to people
    (1, "deal_validated_fo", "front", "validé et envoyé par le trader (Front Office)"),
    (2, "deal_received_mo", "mo", "reçu par le Middle Office"),
    (3, "deal_validated_mo", "mo", "validé par le Middle Office"),
    (4, "deal_sent_bo", "mo", "envoyé vers la file d'attente"),
    (5, "deal_dequeued", "queue", "consommé par Service Queue"),
    (6, "deal_routed", "bus", "routé par le bus d'intégration"),
    (7, "deal_received_bo", "bo", "reçu par le Back Office"),
    (8, "deal_validated_bo", "bo", "validé par le Back Office"),
    (9, "deal_completed", "bo", "envoyé au broker ou au workflow OTC"),
]
STAGE_LABEL = {o: lab for o, _, _, lab in STAGES}
ROLES = {"front": 0, "mo": 1, "queue": 2, "bus": 3}          # index in scenario services, by layer order


def lognorm(rng, median, sigma):
    return median * math.exp(rng.gauss(0, sigma))


class Deal:
    __slots__ = ("id", "desk", "product", "instrument", "target", "broker", "trader", "mo_user", "t", "lost_at",
                 "lost_reason", "incident", "trace", "sq_ms", "sq_version", "mo_version", "seq")

    def __init__(self):
        self.t = {}                     # stage order -> ns
        self.lost_at = None
        self.lost_reason = None
        self.incident = set()
        self.sq_ms = 0.0
        self.sq_version = self.mo_version = self.broker = None


class DealFlow:
    def __init__(self, raw: dict, out: Path, end_override=None, total_override=None):
        self.raw, self.out = raw, out
        c = raw["customer"]
        self.slug = c["slug"].lower()
        if not self.slug.replace("_", "").isalnum() or self.slug == "default":
            die("customer.slug must be alphanumeric (underscores allowed) and not 'default'")
        self.p = c.get("attribute_prefix", self.slug).lower()
        self.tz = ZoneInfo(c.get("timezone", "Europe/Paris"))
        d = raw["dataset"]
        self.total = int(total_override or d["total_events"])
        self.seed = int(d.get("seed", 42))
        self.end = self._resolve_end(end_override or d.get("end", "last_weekday"))
        self.start = self.end - timedelta(hours=int(d.get("window_hours", 24)))
        self.s_ns, self.e_ns = int(self.start.timestamp() * NS), int(self.end.timestamp() * NS)
        self.k = raw["kpi"]
        self.dim = raw["business_dimension"]
        self.svc = {s["name"]: s for s in raw["services"]}
        names = [s["name"] for s in raw["services"]]
        self.front, self.mo, self.queue, self.bus = names[0], names[1], names[2], names[3]
        self.products = raw["products"]
        for prod in self.products.values():
            if prod["target"] not in self.svc:
                die(f"product target {prod['target']!r} is not a service")
        self.wkf = next((n for n in names if "WKF" in n.upper()), None)
        self.incidents = []
        for inc in raw.get("incidents", []):
            s = self.at(inc["start"])
            i = dict(inc, _s=s, _e=s + int(inc["duration_min"]) * MIN)
            if i["_e"] > self.e_ns:
                die(f"incident {inc['id']} ends after the window")
            if inc["type"] not in ("queue_slowdown", "status_not_persisted"):
                die(f"incident {inc['id']}: unknown type {inc['type']}")
            self.incidents.append(i)
        self.inc = {i["type"]: i for i in self.incidents}

    # ---------------------------------------------------------------- time
    def _resolve_end(self, spec):
        now = datetime.now(self.tz)
        if spec == "now":
            return now.replace(second=0, microsecond=0) - timedelta(minutes=now.minute % 5)
        if spec == "midnight":
            return now.replace(hour=0, minute=0, second=0, microsecond=0)
        if spec == "last_weekday":
            end = now.replace(hour=0, minute=0, second=0, microsecond=0)
            while (end - timedelta(days=1)).weekday() >= 5:
                end -= timedelta(days=1)
            return end
        dt = datetime.fromisoformat(spec)
        return dt if dt.tzinfo else dt.replace(tzinfo=self.tz)

    def at(self, hhmm: str) -> int:
        h, m = (int(x) for x in hhmm.split(":"))
        cand = self.start.astimezone(self.tz).replace(hour=h, minute=m, second=0, microsecond=0)
        if cand < self.start:
            cand += timedelta(days=1)
        return int(cand.timestamp() * NS)

    def local(self, t: int) -> datetime:
        return datetime.fromtimestamp(t / NS, self.tz)

    def hm(self, t: int) -> str:
        return self.local(t).strftime("%H:%M")

    def minute_weights(self, peaks_extra=()):
        w = self.raw["load_profile"]["hourly_weights"]
        peaks = [(self.at(p["start"]), self.at(p["end"]), p["factor"]) for p in self.raw["load_profile"].get("peaks", [])]
        peaks += list(peaks_extra)
        out = []
        for m in range((self.e_ns - self.s_ns) // MIN):
            t = self.s_ns + m * MIN
            f = w[self.local(t).hour]
            for s, e, fac in peaks:
                if s <= t < e:
                    f *= fac
            out.append(f)
        return out

    def sample(self, n, weights, rng):
        cum, acc = [], 0.0
        for x in weights:
            acc += x
            cum.append(acc)
        import bisect
        return sorted(self.s_ns + bisect.bisect_left(cum, rng.random() * acc) * MIN + rng.randrange(MIN) for _ in range(n))

    # ---------------------------------------------------------------- plan
    def version(self, system: str, t: int) -> str:
        for i in self.incidents:
            if i["system"] == system and i["_s"] <= t < i["_e"]:
                return i["new_version"]
        for d in self.raw.get("decoy_deployments", []):
            if d["system"] == system:
                return d["to"] if t >= self.at(d["time"]) else d["from"]
        return self.svc[system]["version"]

    def queue_wait_s(self, t4: int, rng) -> float:
        base = lognorm(rng, self.raw["timing"].get("queue_wait_median_s", 2.5), 0.5)
        for p in self.raw["load_profile"].get("peaks", []):
            if self.at(p["start"]) <= t4 < self.at(p["end"]):
                base = lognorm(rng, 20, 0.5)                     # peak: the queue fills a little, harmless
        i = self.inc.get("queue_slowdown")
        if not i:
            return base
        s, e = i["_s"], i["_e"]
        drain = e + 20 * MIN
        if s <= t4 < e:
            ramp = min(1.0, (t4 - s) / (15 * MIN))
            lo, hi = i.get("wait_min", [28, 58])
            w = max(base, ramp * rng.uniform(lo, hi) * 60)
            cap = (e + rng.uniform(4, 18) * MIN - t4) / NS          # rollback: the backlog drains quickly
            return max(base, min(w, cap))
        if e <= t4 < drain:
            return max(base, (drain - t4) / NS * rng.uniform(0.3, 0.6))
        return base

    def plan(self, n: int) -> list[Deal]:
        rng = random.Random(self.seed)
        extra = []
        i2 = self.inc.get("status_not_persisted")
        times = self.sample(n, self.minute_weights(), rng)
        timing = self.raw["timing"]
        desks, dw = self.dim["values"], self.dim["weights"]
        losses = [(self.at(x["time"]), x) for x in self.raw.get("baseline_losses", [])]
        deals = []
        base_id = 4_812_000 + rng.randrange(1000)
        for k, t1 in enumerate(times):
            d = Deal()
            d.seq = k
            d.id = f"F2B-{base_id + k:08d}"
            d.desk = rng.choices(desks, dw)[0]
            mix = self.raw["desk_products"][d.desk]
            d.product = rng.choices(list(mix), list(mix.values()))[0]
            prod = self.products[d.product]
            d.instrument = rng.choice(self.raw.get("desk_instruments", {}).get(d.desk, {}).get(d.product) or prod["instruments"])
            d.target = prod["target"]
            d.broker = rng.choice(self.raw["brokers"])["name"] if d.target != "Murex Back" else None
            d.trader = f"TRD{rng.randint(101, 189)}"
            d.mo_user = f"MO{rng.randint(201, 236)}"
            d.trace = f"{rng.getrandbits(128):032x}"
            d.t[1] = t1
            d.t[2] = t1 + int(rng.uniform(0.2, 1.2) * NS)
            med = timing["mo_validation_hft_median_min"] if d.product == "hft" else timing["mo_validation_median_min"]
            d.t[3] = d.t[2] + int(min(24.0, max(0.3, lognorm(rng, med, 0.55))) * MIN)
            d.mo_version = self.version(self.mo, d.t[3])
            if i2 and d.desk == i2["desk"] and i2["_s"] <= d.t[3] < i2["_e"]:
                d.lost_at, d.lost_reason = 3, i2["id"]
                d.incident.add(i2["id"])
                deals.append(d)
                continue
            d.t[4] = d.t[3] + int(rng.uniform(0.05, 0.4) * NS)
            wait = self.queue_wait_s(d.t[4], rng)
            d.t[5] = d.t[4] + int(wait * NS)
            d.sq_version = self.version(self.queue, d.t[5])
            q = self.inc.get("queue_slowdown")
            if q and d.sq_version == q["new_version"]:
                lo, hi = q.get("processing_ms", [2500, 5200])
                d.sq_ms = rng.uniform(lo, hi)
            else:
                d.sq_ms = lognorm(rng, 35, 0.35)
            if q and wait > 600:
                d.incident.add(q["id"])
            hit = next((x for x in losses if d.t[5] >= x[0] and x[1].get("desk", d.desk) == d.desk), None)
            if hit:
                losses.remove(hit)
                d.lost_at = 5
                d.lost_reason = hit[1]["reason"].format(instrument=d.instrument, product=prod["label"])
                deals.append(d)
                continue
            d.t[6] = d.t[5] + int((d.sq_ms / 1000 + rng.uniform(0.3, 1.5)) * NS)
            d.t[7] = d.t[6] + int(rng.uniform(0.2, 1.0) * NS)
            bo_med = timing["bo_validation_median_min"].get(d.target, 2)
            d.t[8] = d.t[7] + int(max(0.005, lognorm(rng, bo_med, 0.5)) * MIN)
            d.t[9] = d.t[8] + int(rng.uniform(0.2, 1.0) * NS)
            deals.append(d)
        return deals

    @staticmethod
    def deal_events(d: Deal, e_ns: int) -> int:
        n = 0
        for o, t in d.t.items():
            if t >= e_ns:
                continue
            n += {1: 3, 2: 2, 3: 2, 4: 2, 5: 2, 6: 2, 7: 2, 8: 2, 9: 2}[o]    # spans + business log per stage
        if d.lost_at == 3 and d.t[3] < e_ns:
            n += 1                                                       # WARN status_transition_rejected
        if d.lost_at == 5 and d.t[5] < e_ns:
            n += 2                                                       # ERROR at the bus
        if d.sq_ms and d.sq_ms > 1000 and d.t.get(5, e_ns) < e_ns:
            n += 1                                                       # WARN slow processing
        return n

    # ---------------------------------------------------------------- emit
    def res(self, system: str, version: str, dataset: str | None) -> str:
        s = self.svc[system]
        key = f"{system}@{version}#{dataset}"
        a = {"service.name": system, "service.version": version, "service.namespace": self.raw["customer"]["system"].lower(),
             "deployment.environment.name": "production", "deployment.environment": "production",
             "telemetry.sdk.name": "opentelemetry", "telemetry.sdk.language": s.get("language", "java"),
             "host.name": s["host"], "data_stream.namespace": self.slug, f"{self.p}.layer": s.get("layer", "")}
        if dataset:
            a["data_stream.dataset"] = dataset
        return self.w.resource(key, a)

    def ds(self, typ, dataset="generic"):
        return f"{typ}-{dataset}.otel-{self.slug}"

    def span(self, system, version, trace, sid, parent, name, kind, start, dur_ms, a, error=False):
        rec = {"traceId": trace, "spanId": sid, "name": name, "kind": kind, "startTimeUnixNano": str(start),
               "endTimeUnixNano": str(start + int(dur_ms * MS)), "attributes": attrs(a),
               "status": {"code": 2} if error else {"code": 1}}
        if parent:
            rec["parentSpanId"] = parent
        self.w.add("traces", self.res(system, version, None), rec, self.ds("traces"))

    def log(self, system, version, dataset, t, sev, body, a, trace=None, sid=None):
        num = {"DEBUG": 5, "INFO": 9, "WARN": 13, "ERROR": 17}[sev]
        rec = {"timeUnixNano": str(t), "observedTimeUnixNano": str(t), "severityNumber": num, "severityText": sev,
               "body": {"stringValue": body}, "attributes": attrs(a)}
        if trace:
            rec["traceId"], rec["spanId"] = trace, sid
        self.w.add("logs", self.res(system, version, dataset), rec, self.ds("logs", dataset))

    def sid(self):
        return f"{self.rng.getrandbits(64):016x}"

    def emit_deal(self, d: Deal) -> None:
        p, e = self.p, self.e_ns
        prod = self.products[d.product]
        code = self.dim.get("codes", {}).get(d.desk, d.desk)
        base = {f"{p}.deal.id": d.id, f"{p}.desk": d.desk, f"{p}.desk.code": code, f"{p}.product_type": prod["label"],
                f"{p}.instrument": d.instrument, f"{p}.target_system": d.target}
        if d.broker:
            base[f"{p}.broker"] = d.broker
        deal_ds, app_ds = f"{p}.deal", f"{p}.app"
        prev = d.t[1]

        def blog(system, version, o, t, body, status, sid, extra=None, sev="INFO"):
            nonlocal prev
            a = {**base, f"{p}.event": STAGES[o - 1][1], f"{p}.stage.order": o, f"{p}.stage": system,
                 f"{p}.stage.wait_s": round((t - prev) / NS, 1), f"{p}.deal.status": status,
                 f"{p}.log.pattern": STAGES[o - 1][1], "log.logger": f"{system.lower().replace(' ', '_')}.deal.lifecycle"}
            a.update(extra or {})
            prev = t
            self.log(system, version, deal_ds, t, sev, body, a, d.trace, sid)

        # 1 Front office: trader validates and sends to MO
        fv = self.version(self.front, d.t[1])
        root, prodspan = self.sid(), self.sid()
        self.span(self.front, fv, d.trace, root, None, "Validate Deal", 2, d.t[1], lognorm(self.rng, 180, 0.3),
                  {**base, f"{p}.screen": "Validate Deal", f"{p}.user": d.trader, f"{p}.layer": "ui"})
        self.span(self.front, fv, d.trace, prodspan, root, "deals.fo publish", 4, d.t[1] + 150 * MS, lognorm(self.rng, 8, 0.3),
                  {**base, "messaging.system": "jms", "messaging.destination.name": "deals.fo", "messaging.operation.type": "publish"})
        blog(self.front, fv, 1, d.t[1], f"Deal {d.id} validated by trader {d.trader} (desk {d.desk}, {d.instrument}) and sent to Middle Office",
             "SENT_TO_MO", root, {f"{p}.user": d.trader})
        if d.t[2] >= e:
            return
        # 2-4 Middle office
        mv = self.version(self.mo, d.t[2])
        cons = self.sid()
        self.span(self.mo, mv, d.trace, cons, prodspan, "deals.fo process", 5, d.t[2], lognorm(self.rng, 40, 0.3),
                  {**base, "messaging.system": "jms", "messaging.destination.name": "deals.fo", "messaging.operation.type": "process"})
        blog(self.mo, mv, 2, d.t[2], f"Deal {d.id} received from Fast, status PENDING_MO", "PENDING_MO", cons)
        if d.t[3] >= e:
            return
        mv = d.mo_version
        val = self.sid()
        lost3 = d.lost_at == 3
        self.span(self.mo, mv, d.trace, val, cons, "Validate Deal", 2, d.t[3], lognorm(self.rng, 220, 0.3),
                  {**base, f"{p}.screen": "Validate Deal", f"{p}.user": d.mo_user, f"{p}.layer": "ui",
                   f"{p}.deal.status": "PENDING_MO" if lost3 else "VALIDATED", f"{p}.deal.status_displayed": "VALIDATED"})
        blog(self.mo, mv, 3, d.t[3], f"Deal {d.id} validated by {d.mo_user}, displayed status VALIDATED",
             "PENDING_MO" if lost3 else "VALIDATED", val,
             {f"{p}.user": d.mo_user, f"{p}.deal.status_displayed": "VALIDATED"})
        if lost3:
            i2 = self.inc["status_not_persisted"]
            self.log(self.mo, mv, app_ds, d.t[3] + 30 * MS, "WARN",
                     i2["log_message"].format(deal=d.id, code=code),
                     {**base, f"{p}.log.pattern": i2["log_pattern"], "exception.type": i2["exception_type"],
                      "exception.message": f"No workflow mapping for desk {code}", f"{p}.deal.status": "PENDING_MO",
                      f"{p}.deal.status_displayed": "VALIDATED", "log.logger": "mx.workflow.StatusTransition"}, d.trace, val)
            return
        pub = self.sid()
        self.span(self.mo, mv, d.trace, pub, val, "deals.validated publish", 4, d.t[4], lognorm(self.rng, 12, 0.3),
                  {**base, "messaging.system": "kafka", "messaging.destination.name": "deals.validated",
                   "messaging.operation.type": "publish"})
        blog(self.mo, mv, 4, d.t[4], f"Deal {d.id} sent to Back Office (topic deals.validated)", "SENT_TO_BO", pub)
        if d.t[5] >= e:
            return
        # 5 Service Queue
        sv = d.sq_version
        sq = self.sid()
        wait_s = (d.t[5] - d.t[4]) / NS
        self.span(self.queue, sv, d.trace, sq, pub, "deals.validated process", 5, d.t[5], d.sq_ms,
                  {**base, "messaging.system": "kafka", "messaging.destination.name": "deals.validated",
                   "messaging.consumer.group.name": "fobo-dispatch", "messaging.operation.type": "process",
                   f"{p}.queue.wait_s": round(wait_s, 1)})
        blog(self.queue, sv, 5, d.t[5], f"Deal {d.id} consumed from deals.validated after {wait_s:.1f} s in queue, processed in {d.sq_ms:.0f} ms",
             "IN_TRANSIT", sq, {f"{p}.queue.wait_s": round(wait_s, 1), f"{p}.processing_ms": round(d.sq_ms)})
        q = self.inc.get("queue_slowdown")
        if d.sq_ms > 1000 and q:
            self.log(self.queue, sv, app_ds, d.t[5] + int(d.sq_ms * MS), "WARN",
                     q["log_message"].format(deal=d.id, ms=int(d.sq_ms * 0.9)),
                     {**base, f"{p}.log.pattern": q["log_pattern"], f"{p}.processing_ms": round(d.sq_ms),
                      "log.logger": "sq.enrichment.ReferenceDataClient"}, d.trace, sq)
        if d.lost_at == 5:
            tf = d.t[5] + int((d.sq_ms + 400) * MS)
            blog(self.bus, self.version(self.bus, d.t[5]), 6, tf, f"Deal {d.id} rejected by routing: {d.lost_reason}",
                 "ROUTING_FAILED", sq, {f"{p}.event": "deal_routing_failed", f"{p}.log.pattern": "deal_routing_failed"}, sev="ERROR")
            self.log(self.bus, self.version(self.bus, d.t[5]), app_ds, tf, "ERROR",
                     f"Routing failed for deal {d.id}: {d.lost_reason}",
                     {**base, f"{p}.log.pattern": "routing_failed", "exception.type": "com.tibco.bw.RoutingException",
                      "exception.message": d.lost_reason, "log.logger": "fobo.dispatch.Router"}, d.trace, sq)
            return
        if d.t[6] >= e:
            return
        # 6 FOBO
        bv = self.version(self.bus, d.t[6])
        bus = self.sid()
        self.span(self.bus, bv, d.trace, bus, sq, f"route deal to {d.target}", 5, d.t[6], lognorm(self.rng, 180, 0.3),
                  {**base, "messaging.system": "tibco", "messaging.destination.name": f"bo.{d.target.lower().replace(' ', '_')}",
                   "messaging.operation.type": "process"})
        blog(self.bus, bv, 6, d.t[6], f"Deal {d.id} routed to {d.target} ({prod['label']})", "IN_TRANSIT", bus)
        if d.t[7] >= e:
            return
        # 7-9 Back office
        tv = self.version(d.target, d.t[7])
        rec = self.sid()
        descent = (d.t[7] - d.t[1]) / MIN
        self.span(d.target, tv, d.trace, rec, bus, "deal receive", 5, d.t[7], lognorm(self.rng, 60, 0.3),
                  {**base, "messaging.operation.type": "receive", f"{p}.descent_time_min": round(descent, 2)})
        blog(d.target, tv, 7, d.t[7], f"Deal {d.id} received in {d.target}, {descent:.1f} min after front office validation",
             "RECEIVED_BO", rec, {f"{p}.descent_time_min": round(descent, 2)})
        if d.t[8] >= e:
            return
        tv = self.version(d.target, d.t[8])
        bval = self.sid()
        screen = "Validate Block" if d.target == "HF Trader" else "Validate Deal"
        self.span(d.target, tv, d.trace, bval, rec, screen, 2, d.t[8], lognorm(self.rng, 150, 0.3),
                  {**base, f"{p}.screen": screen, f"{p}.layer": "ui"})
        blog(d.target, tv, 8, d.t[8], f"Deal {d.id} validated in {d.target}", "VALIDATED_BO", bval)
        if d.t[9] >= e:
            return
        last = self.sid()
        if d.target == "Murex Back" and self.wkf:
            wv = self.version(self.wkf, d.t[9])
            self.span(self.wkf, wv, d.trace, last, bval, "Start WKF", 2, d.t[9], lognorm(self.rng, 260, 0.3),
                      {**base, f"{p}.screen": "Start WKF"})
            blog(self.wkf, wv, 9, d.t[9], f"OTC workflow started for deal {d.id}", "WKF_STARTED", last)
        else:
            bk = next(b for b in self.raw["brokers"] if b["name"] == d.broker)
            self.span(d.target, tv, d.trace, last, bval, "POST /orders", 3, d.t[9], lognorm(self.rng, 90, 0.35),
                      {**base, "http.request.method": "POST", "url.path": "/orders", "server.address": bk["host"],
                       "peer.service": d.broker, "http.response.status_code": 201})
            blog(d.target, tv, 9, d.t[9], f"Deal {d.id} sent to broker {d.broker}", "SENT_TO_BROKER", last)

    def emit_fixed(self) -> int:
        """Technical logs and metrics independent of deals. Returns the number of events written."""
        before = self.w.total
        p, app_ds = self.p, f"{self.p}.app"
        rng = random.Random(self.seed + 3)
        # deployments
        for i in self.incidents:
            for t, v, kind in ((i["_s"], i["new_version"], "deployed"), (i["_e"], i["rollback_version"], "rolled back")):
                self.log(i["system"], v, app_ds, t, "INFO",
                         f"{i['system']} {v} started ({'deployment ' + i['deployment'] if kind == 'deployed' else 'rollback of ' + i['deployment']})",
                         {f"{p}.log.pattern": "deployment", f"{p}.deployment.id": i["deployment"],
                          f"{p}.deployment.action": kind, "log.logger": "deploy"})
        for dd in self.raw.get("decoy_deployments", []):
            t = self.at(dd["time"])
            self.log(dd["system"], dd["to"], app_ds, t, "INFO", f"{dd['system']} {dd['to']} started (previous {dd['from']}): {dd['change']}",
                     {f"{p}.log.pattern": "deployment", f"{p}.deployment.action": "deployed", "log.logger": "deploy"})
        # nightly jobs (decoys)
        for j in self.raw.get("nightly_jobs", []):
            s = self.at(j["start"])
            e = s + j["duration_min"] * MIN
            v = self.version(j["system"], s)
            common = {f"{p}.job.name": j["name"], f"{p}.job.trigger": "scheduled", f"{p}.job.planned_start": j["start"],
                      "log.logger": "batch.scheduler"}
            self.log(j["system"], v, app_ds, s, "INFO", f"Batch {j['name']} started (scheduled {j['start']})",
                     {**common, f"{p}.log.pattern": "batch_started"})
            t = s + 10 * MIN
            while t < e:
                self.log(j["system"], v, app_ds, t, "INFO",
                         f"Batch {j['name']} progress {int(100 * (t - s) / (e - s))} %",
                         {**common, f"{p}.log.pattern": "batch_progress"})
                t += 10 * MIN
            self.log(j["system"], v, app_ds, e, "INFO", f"Batch {j['name']} finished after {j['duration_min']} min",
                     {**common, f"{p}.log.pattern": "batch_finished", f"{p}.job.duration_min": j["duration_min"]})
        # background WARN noise on every system, so a WARN alone is not a cause
        noise = {"Fast": "Market data snapshot refresh took 1450 ms", "Murex FO": "Pricing cache refreshed with 3 stale curves",
                 "Service Queue": "Consumer heartbeat delayed 1200 ms", "FOBO": "JMS connection pool at 80 % of capacity",
                 "Calypso": "Static data reload took 2100 ms", "Murex Back": "Market data feed reconnected",
                 "HF Trader": "Broker session resend request handled", "OTC WKF": "Workflow engine GC pause 650 ms"}
        for name in self.svc:
            for _ in range(6):
                t = self.s_ns + int(rng.uniform(6, 22) * 60 * MIN)
                self.log(name, self.version(name, t), app_ds, t, "WARN", noise.get(name, "Slow internal operation"),
                         {f"{p}.log.pattern": "background_warning", "log.logger": "runtime"})
        # queue status, one line per minute, and lag gauge
        events = []
        for d in self.deals:
            if 4 in d.t:
                events.append((d.t[4], d.t.get(5, 10 ** 30)))
        events.sort()
        heap, idx = [], 0
        lagstats = []
        for m in range((self.e_ns - self.s_ns) // MIN):
            t = self.s_ns + (m + 1) * MIN
            while idx < len(events) and events[idx][0] <= t:
                heapq.heappush(heap, (events[idx][1], events[idx][0]))
                idx += 1
            while heap and heap[0][0] <= t:
                heapq.heappop(heap)
            lag = len(heap)
            oldest = max(((t - enq) / NS for _, enq in heap), default=0.0)
            v = self.version(self.queue, t)
            lagstats.append((t, lag, oldest))
            sev = "WARN" if oldest > 600 else "INFO"
            self.log(self.queue, v, app_ds, t, sev,
                     f"Consumer group fobo-dispatch on deals.validated: lag {lag} messages, oldest message {oldest:.0f} s",
                     {f"{p}.log.pattern": "consumer_lag", f"{p}.queue.lag_messages": lag,
                      f"{p}.queue.oldest_message_age_s": round(oldest, 1), "messaging.destination.name": "deals.validated",
                      "messaging.consumer.group.name": "fobo-dispatch", "log.logger": "sq.consumer.LagMonitor"})
            self.w.add("metrics", self.res(self.queue, v, None),
                       {"name": "messaging.kafka.consumer.lag", "unit": "{message}",
                        "gauge": {"dataPoints": [{"timeUnixNano": str(t), "asDouble": float(lag),
                                                  "attributes": attrs({"messaging.consumer.group.name": "fobo-dispatch"})}]}},
                       self.ds("metrics"))
        self.lagstats = lagstats
        # CPU of every system every 5 minutes
        jobs = [(self.at(j["start"]), self.at(j["start"]) + j["duration_min"] * MIN, j["system"]) for j in self.raw.get("nightly_jobs", [])]
        w = self.raw["load_profile"]["hourly_weights"]
        for m in range(0, (self.e_ns - self.s_ns) // MIN, 5):
            t = self.s_ns + m * MIN
            for name in self.svc:
                cpu = 0.12 + 0.35 * w[self.local(t).hour] + rng.uniform(-0.03, 0.03)
                if any(s <= t < e and sys_ == name for s, e, sys_ in jobs):
                    cpu = rng.uniform(0.78, 0.9)
                self.w.add("metrics", self.res(name, self.version(name, t), None),
                           {"name": "system.cpu.utilization", "unit": "1",
                            "gauge": {"dataPoints": [{"timeUnixNano": str(t), "asDouble": round(cpu, 4)}]}},
                           self.ds("metrics"))
        return self.w.total - before

    def emit_ui(self, n: int) -> None:
        """Screen navigation spans (List Deal, Deal Status...): the padding that brings the total to the exact count."""
        if n <= 0:
            return
        rng = random.Random(self.seed + 5)
        p = self.p
        i2 = self.inc.get("status_not_persisted")
        extra = []
        if i2:
            extra = [(i2["_s"] + 30 * MIN, i2["_e"] + 30 * MIN, 1.0)]
        times = self.sample(n, self.minute_weights(), rng)
        screens = [(s["name"], sc) for s in self.raw["services"] for sc in s.get("screens", [])
                   if sc not in ("Validate Deal", "Send Deal MO", "Send Deal BO", "Start WKF", "Validate Block", "Send Deal Broker")]
        for t in times:
            system, screen = rng.choice(screens)
            desk = rng.choices(self.dim["values"], self.dim["weights"])[0]
            # traders and MO of the impacted desk keep checking deal status during the lost deals incident
            if i2 and i2["_s"] + 30 * MIN <= t < i2["_e"] + 30 * MIN and rng.random() < 0.35:
                system, screen, desk = rng.choice([(self.front, "Deal Status"), (self.mo, "Deal Status"), (self.mo, "List Deal")]) + (i2["desk"],)
            v = self.version(system, t)
            trace = f"{rng.getrandbits(128):032x}"
            self.span(system, v, trace, f"{rng.getrandbits(64):016x}", None, screen, 2, t, lognorm(rng, 260, 0.4),
                      {f"{p}.screen": screen, f"{p}.desk": desk, f"{p}.layer": "ui", f"{p}.user": f"U{rng.randint(100, 999)}"})

    def run(self) -> dict:
        self.out.mkdir(parents=True, exist_ok=True)
        target = self.total
        # choose the number of deals so that deals + fixed + about 10 % navigation reach the target
        fixed_guess = (self.e_ns - self.s_ns) // MIN * 2 + (self.e_ns - self.s_ns) // (5 * MIN) * len(self.svc) + 200
        n = max(100, int((target * 0.9 - fixed_guess) / 19))
        for _ in range(8):
            deals = self.plan(n)
            dev = sum(self.deal_events(d, self.e_ns) for d in deals)
            if dev + fixed_guess <= target * 0.92:
                break
            n = int(n * (target * 0.9 - fixed_guess) / dev)
        self.deals = deals
        self.w = Writer(self.out)
        self.rng = random.Random(self.seed + 7)
        for d in deals:
            self.emit_deal(d)
        deal_events = self.w.total
        fixed = self.emit_fixed()
        pad = target - self.w.total
        if pad < 0:
            die(f"dataset overshoots the target by {-pad} events: raise total_events")
        self.emit_ui(pad)
        self.w.close()
        return {"deals": len(deals), "deal_events": deal_events, "fixed": fixed, "padding": pad}

    # ---------------------------------------------------------------- truth
    def truth(self, info: dict) -> tuple[dict, dict]:
        k, p = self.k, self.p
        iso = lambda t: self.local(t).isoformat(timespec="seconds")       # noqa: E731
        arrived = [d for d in self.deals if d.t.get(7, 10 ** 30) < self.e_ns]
        desc = lambda d: (d.t[7] - d.t[1]) / MIN                           # noqa: E731

        def stats(ds):
            v = sorted(desc(d) for d in ds)
            if not v:
                return {"deals": 0, "avg_min": None, "p95_min": None, "max_min": None, "over_ok": 0, "over_critical": 0}
            return {"deals": len(v), "avg_min": round(sum(v) / len(v), 1), "p95_min": round(v[min(len(v) - 1, int(0.95 * len(v)))], 1),
                    "max_min": round(v[-1], 1), "over_ok": sum(1 for x in v if x > k["descent_ok_min"]),
                    "over_critical": sum(1 for x in v if x > k["descent_critical_min"])}

        inc_ids = {i["id"] for i in self.incidents}
        base = [d for d in arrived if not (d.incident & inc_ids)]
        lost = [d for d in self.deals if d.lost_at and d.t[d.lost_at] < self.e_ns - k["lost_age_min"] * MIN]
        incidents = []
        q, s2 = self.inc.get("queue_slowdown"), self.inc.get("status_not_persisted")
        bstats = stats(base)
        if q:
            win = [d for d in arrived if q["_s"] <= d.t[7] < q["_e"] + 30 * MIN]
            st = stats(win)
            affected = [d for d in arrived if q["id"] in d.incident]
            waits = sorted((d.t[5] - d.t[4]) / MIN for d in affected) or [0]
            peak = max((x for x in self.lagstats if q["_s"] <= x[0] < q["_e"] + 30 * MIN), key=lambda x: x[1])
            per_desk = defaultdict(list)
            for d in win:
                per_desk[d.desk].append(desc(d))
            first_deg = next((t for t, lag, old in self.lagstats if t >= q["_s"] and old > k["descent_ok_min"] * 60), None)
            cross = None
            buckets = defaultdict(list)
            for d in arrived:
                buckets[(d.t[7] - self.s_ns) // (15 * MIN)].append(desc(d))
            for b in sorted(buckets):
                t = self.s_ns + b * 15 * MIN
                if t >= q["_s"] and sum(buckets[b]) / len(buckets[b]) > k["descent_ok_min"]:
                    cross = t
                    break
            incidents.append({
                "id": q["id"], "type": q["type"], "title": q["title"], "system": q["system"],
                "start": iso(q["_s"]), "end": iso(q["_e"]), "start_local": self.hm(q["_s"]), "end_local": self.hm(q["_e"]),
                "impact_end_local": self.hm(max(d.t[7] for d in affected) if affected else q["_e"]),
                "descent": st, "baseline_descent": bstats, "affected_deals": len(affected),
                "queue_wait_avg_min": round(sum(waits) / len(waits), 1), "queue_wait_max_min": round(waits[-1], 1),
                "peak_lag_messages": peak[1], "peak_lag_local": self.hm(peak[0]), "peak_oldest_message_min": round(peak[2] / 60, 1),
                "avg_degraded_from_local": self.hm(cross) if cross else None,
                "desks": {k2: round(sum(v) / len(v), 1) for k2, v in sorted(per_desk.items())},
                "versions": {"new": q["new_version"], "previous": q["rollback_version"]},
                "root_cause": (f"Le déploiement de {q['system']} {q['new_version']} ({q['deployment']}) à {self.hm(q['_s'])} a désactivé "
                               f"le cache d'enrichissement : chaque message déclenche une lecture directe des données de référence, "
                               f"le traitement passe d'environ 35 ms à 2,5 à 5 s par deal et la file deals.validated s'engorge "
                               f"(jusqu'à {peak[1]} messages en attente, le plus ancien depuis {peak[2] / 60:.0f} min). Tous les desks "
                               f"sont touchés : le temps de descente moyen monte à {st['avg_min']} min (p95 {st['p95_min']} min, "
                               f"max {st['max_min']} min) contre {bstats['avg_min']} min en temps normal, avec {st['over_critical']} deals "
                               f"au-delà d'une heure. Le Middle Office, FOBO et les systèmes Back Office répondent normalement. "
                               f"Retour à la normale après le rollback en {q['rollback_version']} à {self.hm(q['_e'])}, file vidée vers "
                               f"{self.hm(max(d.t[5] for d in affected) if affected else q['_e'])}."),
                "remediation": (f"Rollback en {q['rollback_version']} (fait à {self.hm(q['_e'])}). Réactiver le cache "
                                f"(sq.enrichment.cache.enabled=true) avant de relivrer la 2.8.0, ajouter un test de charge sur la "
                                f"consommation de deals.validated et une alerte sur l'âge du plus ancien message (au-delà de 10 min)."),
                "evidence": [
                    {"stream": self.ds("logs", f"{p}.deal"), "fact": f"{p}.descent_time_min moyen {st['avg_min']} min sur les deals reçus en Back Office entre {self.hm(q['_s'])} et {self.hm(q['_e'] + 30 * MIN)}, contre {bstats['avg_min']} min en temps normal ; tous les desks touchés"},
                    {"stream": self.ds("logs", f"{p}.deal"), "fact": f"{p}.stage.wait_s élevé uniquement sur l'étape deal_dequeued (Service Queue) : attente moyenne {round(sum(waits) / len(waits), 1)} min, max {waits[-1]:.0f} min"},
                    {"stream": self.ds("logs", f"{p}.app"), "fact": f"consumer_lag : jusqu'à {peak[1]} messages et {peak[2] / 60:.0f} min d'ancienneté vers {self.hm(peak[0])}"},
                    {"stream": self.ds("traces"), "fact": f"service.version {q['new_version']} de {q['system']} vue de {self.hm(q['_s'])} à {self.hm(q['_e'])}, spans « deals.validated process » de 2,5 à 5 s"},
                    {"stream": self.ds("logs", f"{p}.app"), "fact": f"WARN {q['log_pattern']} : enrichment cache disabled, falling back to direct lookup"}],
                "concurrent_with": []})
        if s2:
            l2 = sorted((d for d in self.deals if d.lost_reason == s2["id"]), key=lambda d: d.t[3])
            crit = l2[k["lost_critical_count"] - 1].t[3] + k["lost_age_min"] * MIN if len(l2) >= k["lost_critical_count"] else None
            by_prod = defaultdict(int)
            for d in l2:
                by_prod[self.products[d.product]["label"]] += 1
            other = [d for d in self.deals if d.desk != s2["desk"] and s2["_s"] <= d.t[3] < s2["_e"] and d.t.get(7, 10 ** 30) < self.e_ns]
            code = self.dim.get("codes", {}).get(s2["desk"], s2["desk"])
            incidents.append({
                "id": s2["id"], "type": s2["type"], "title": s2["title"], "system": s2["system"], "desk": s2["desk"],
                "start": iso(s2["_s"]), "end": iso(s2["_e"]), "start_local": self.hm(s2["_s"]), "end_local": self.hm(s2["_e"]),
                "lost_deals": len(l2), "lost_by_product": dict(by_prod),
                "first_lost_local": self.hm(l2[0].t[3]) if l2 else None, "last_lost_local": self.hm(l2[-1].t[3]) if l2 else None,
                "critical_from_local": self.hm(crit) if crit else None,
                "other_desks_descent": stats(other),
                "lost_deal_ids_sample": [d.id for d in l2[:5]],
                "versions": {"new": s2["new_version"], "previous": s2["rollback_version"]},
                "root_cause": (f"Le patch {s2['system']} {s2['new_version']} ({s2['deployment']}) appliqué à {self.hm(s2['_s'])} n'a pas de "
                               f"correspondance de workflow pour le desk {s2['desk']} ({code}) : à la validation Middle Office, la "
                               f"transition PENDING_MO → VALIDATED est rejetée par une exception interceptée, l'écran affiche « VALIDATED » "
                               f"mais le statut reste PENDING_MO et le deal n'est jamais envoyé vers Service Queue. {len(l2)} deals de "
                               f"ce desk validés entre {self.hm(l2[0].t[3]) if l2 else '-'} et {self.hm(l2[-1].t[3]) if l2 else '-'} "
                               f"ne sont jamais arrivés en Back Office ; le seuil critique (10 deals perdus depuis plus d'une heure) est "
                               f"franchi à {self.hm(crit) if crit else '-'}. Les autres desks descendent normalement "
                               f"({stats(other)['avg_min']} min en moyenne). Plus aucune perte après le retour en {s2['rollback_version']} "
                               f"à {self.hm(s2['_e'])}, mais les deals perdus restent bloqués dans Murex FO."),
                "remediation": (f"Rollback du patch (fait à {self.hm(s2['_e'])}), puis rejouer les {len(l2)} deals bloqués en "
                                f"PENDING_MO depuis l'écran Reconciliation de Murex FO à partir de la liste des deal id. Corriger la table "
                                f"de correspondance des workflows pour {code} avant de réappliquer le patch, ne plus intercepter "
                                f"silencieusement l'exception de transition, et alerter dès qu'un deal validé n'atteint pas Service "
                                f"Queue en 5 minutes."),
                "evidence": [
                    {"stream": self.ds("logs", f"{p}.deal"), "fact": f"{len(l2)} deals du desk {s2['desk']} avec deal_validated_fo mais sans deal_received_bo ; dernière étape atteinte : deal_validated_mo (Murex FO)"},
                    {"stream": self.ds("logs", f"{p}.deal"), "fact": f"sur ces deals, {p}.deal.status=PENDING_MO alors que {p}.deal.status_displayed=VALIDATED"},
                    {"stream": self.ds("logs", f"{p}.app"), "fact": f"WARN {s2['log_pattern']} ({s2['exception_type']}) : no workflow mapping for desk {code}, uniquement entre {self.hm(s2['_s'])} et {self.hm(s2['_e'])}"},
                    {"stream": self.ds("traces"), "fact": f"service.version {s2['new_version']} de {s2['system']} de {self.hm(s2['_s'])} à {self.hm(s2['_e'])} ; les traces de ces deals s'arrêtent à « Validate Deal » dans Murex FO"},
                    {"stream": self.ds("traces"), "fact": f"consultations « Deal Status » en hausse pour le desk {s2['desk']} pendant l'incident"}],
                "concurrent_with": []})
        others = [d for d in self.deals if d.lost_at == 5]
        decoys = [f"Batch {j['name']} ({j['label']}) sur {j['system']} de {j['start']} pendant {j['duration_min']} min : planifié, aucun deal en cours"
                  for j in self.raw.get("nightly_jobs", [])]
        decoys += [f"Pic d'activité « {pk['label']} » de {pk['start']} à {pk['end']} : volume ×{pk['factor']}, file un peu plus remplie, descente normale"
                   for pk in self.raw["load_profile"].get("peaks", [])]
        decoys += [f"Déploiement de {dd['system']} {dd['to']} à {dd['time']} ({dd['change']}) : sans effet sur la descente"
                   for dd in self.raw.get("decoy_deployments", [])]
        decoys += [f"Deal {d.id} ({d.desk}) perdu dans FOBO à {self.hm(d.t[5])} : {d.lost_reason}. Cas isolé, sous le seuil critique"
                   for d in others]
        # 15 minute timeline by arrival in back office, and lost deals by validation time
        timeline = []
        b_arr, b_lost = defaultdict(list), defaultdict(int)
        for d in arrived:
            b_arr[(d.t[7] - self.s_ns) // (15 * MIN)].append(desc(d))
        for d in self.deals:
            if d.lost_at:
                b_lost[(d.t[1] - self.s_ns) // (15 * MIN)] += 1
        for b in range((self.e_ns - self.s_ns) // (15 * MIN)):
            v = sorted(b_arr.get(b, []))
            timeline.append({"t": self.local(self.s_ns + b * 15 * MIN).strftime("%Y-%m-%d %H:%M"), "deals": len(v),
                             "avg_min": round(sum(v) / len(v), 1) if v else None,
                             "p95_min": round(v[min(len(v) - 1, int(0.95 * len(v)))], 1) if v else None,
                             "max_min": round(v[-1], 1) if v else None, "lost": b_lost.get(b, 0)})
        window = {"start": iso(self.s_ns), "end": iso(self.e_ns), "timezone": str(self.tz)}
        attrs_list = [
            (f"{p}.deal.id", "toute la chaîne", "customer", "Identifiant deal interne, clé métier commune"),
            (f"{p}.desk", "toute la chaîne", "customer", "Desk de trading, axe d'analyse métier"),
            (f"{p}.product_type", "toute la chaîne", "customer", "Type de produit : dérivé listé, OTC, haute fréquence"),
            (f"{p}.broker", "Calypso, HF Trader", "customer", "Broker destinataire"),
            (f"{p}.deal.status", "toute la chaîne", "literature", "Statut persisté du deal"),
            (f"{p}.deal.status_displayed", "Murex FO", "literature", "Statut affiché à l'écran"),
            (f"{p}.instrument", "toute la chaîne", "literature", "Instrument traité"),
            (f"{p}.target_system", "toute la chaîne", "literature", "Système Back Office cible"),
            (f"{p}.event", "logs de cycle de vie", "literature", "Étape du cycle de vie"),
            (f"{p}.stage.wait_s", "logs de cycle de vie", "literature", "Secondes écoulées depuis l'étape précédente"),
            (f"{p}.descent_time_min", "réception Back Office", "literature", "Temps de descente Front → Back en minutes"),
            (f"{p}.queue.lag_messages", "Service Queue", "literature", "Messages en attente dans deals.validated"),
        ]
        truth = {"model": "deal_flow", "customer": self.raw["customer"]["name"], "namespace": self.slug, "window": window,
                 "kpi": "descent", "kpi_rule": k, "descent": {"baseline": bstats, "overall": stats(arrived)},
                 "lost_total": len(lost), "decoys": decoys, "incidents": incidents}
        counts = dict(sorted(self.w.counts.items()))
        summary = {"model": "deal_flow", "customer": truth["customer"], "namespace": self.slug, "attribute_prefix": p,
                   "window": window, "seed": self.seed, "total_events": self.w.total, "requested_events": self.total,
                   "deals": info["deals"], "user_requests": info["deals"], "padding_events": info["padding"],
                   "events_by_data_stream": counts,
                   "events_by_signal": {s: sum(v for k2, v in counts.items() if k2.startswith(s)) for s in ("traces", "logs", "metrics")},
                   "kpi": "descent", "descent": truth["descent"], "lost_total": len(lost),
                   "custom_attributes": [{"attribute": a, "system": w, "found_in": "spans et logs", "source": s,
                                          "propagated": ["services", "core"] if a == f"{p}.deal.id" else [],
                                          "identifier": a == f"{p}.deal.id", "description": dsc} for a, w, s, dsc in attrs_list],
                   "correlation": {"trace_frontend_to_services": True, "trace_in_service_logs": True, "trace_in_core_system_logs": True,
                                   "end_to_end": True,
                                   "propagated_keys": [{"attribute": f"{p}.deal.id", "reaches": ["services", "core"], "identifier": True}]},
                   "service_versions": {n: sorted({self.version(n, t) for t in range(self.s_ns, self.e_ns, 5 * MIN)}) for n in self.svc},
                   "timeline_15min": timeline}
        return truth, summary


# -------------------------------------------------------------------- agent
TIME = {"start": {"type": "date", "description": "Start of the time range, ISO 8601 with timezone offset, e.g. 2026-01-15T09:30:00+01:00"},
        "end": {"type": "date", "description": "End of the time range (exclusive), ISO 8601 with timezone offset"}}
RANGE = "@timestamp >= ?start AND @timestamp < ?end"
BUILTIN = ["platform.core.search", "platform.core.list_indices", "platform.core.get_index_mapping",
           "platform.core.generate_esql", "platform.core.execute_esql"]


def build_agent(out: Path) -> None:
    scn = json.loads((out / "scenario.json").read_text(encoding="utf-8"))
    summary = json.loads((out / "summary.json").read_text(encoding="utf-8"))
    truth = json.loads((out / "ground_truth.json").read_text(encoding="utf-8"))
    ns, p, k = summary["namespace"], summary["attribute_prefix"], scn["kpi"]
    c = scn["customer"]
    deal, app, tr = f"logs-{p}.deal*-{ns}", f"logs-{p}.app*-{ns}", f"traces-*-{ns}"
    a = lambda f: f"attributes.{p}.{f}"                                    # noqa: E731
    tools = []

    def tool(name, desc, query, extra=None, time=True, layer=""):
        tools.append({"id": f"{ns}.{name}", "type": "esql", "description": " ".join(desc.split()),
                      "tags": [ns, "demo"] + ([layer] if layer else []),
                      "configuration": {"query": " ".join(query.split()), "params": {**(TIME if time else {}), **(extra or {})}}})

    lvl = (f"| EVAL d = {a('descent_time_min')}, deg = CASE(d > {k['descent_ok_min']} AND d <= {k['descent_critical_min']}, 1, 0), "
           f"crit = CASE(d > {k['descent_critical_min']}, 1, 0)")
    agg = ("deals = COUNT(*), avg_descent_min = ROUND(AVG(d), 1), p95_descent_min = ROUND(PERCENTILE(d, 95), 1), "
           "max_descent_min = ROUND(MAX(d), 1), degraded_30_60 = SUM(deg), critical_over_60 = SUM(crit)")
    rule = (f"Rule: up to {k['descent_ok_min']} min is OK, {k['descent_ok_min']} to {k['descent_critical_min']} min is degraded, "
            f"over {k['descent_critical_min']} min is critical.")
    arr = f"FROM {deal} | WHERE {RANGE} AND {a('event')} == \"deal_received_bo\""
    tool("descent_time_timeline", f"""KPI. Front-to-back descent time of deals per 15-minute bucket of ARRIVAL in the back
         office: deals arrived, average, p95 and max descent time in minutes, number of degraded and critical deals.
         {rule} Use it first, on the whole day, to find WHEN deals went down slowly.""",
         f"{arr} {lvl} | STATS {agg} BY bucket = BUCKET(@timestamp, 15 minutes) | SORT bucket | LIMIT 300", layer="kpi")
    tool("descent_time_by_desk", f"""KPI by business axis. Descent time per trading desk over a time range (by arrival in the
         back office). Use it to tell whether a slowdown hits every desk (a shared component) or one desk. {rule}""",
         f"{arr} {lvl} | STATS {agg} BY desk = {a('desk')} | SORT avg_descent_min DESC | LIMIT 50", layer="kpi")
    tool("descent_time_by_product", f"""KPI by product. Descent time per product type and back office target system (Calypso,
         Murex Back, HF Trader) and broker over a time range. Use it to tell whether one back office branch is involved. {rule}""",
         f"""{arr} {lvl} | STATS {agg} BY product_type = {a('product_type')}, target_system = {a('target_system')},
         broker = {a('broker')} | SORT avg_descent_min DESC | LIMIT 50""", layer="kpi")
    tool("stage_waits", """Chain. Time spent waiting before each step of the deal lifecycle over a time range: for every step
         (1 trader validation in Fast, 2 received by Murex FO, 3 validated by Middle Office, 4 sent to the queue,
         5 consumed by Service Queue, 6 routed by FOBO, 7 received by the back office, 8 validated by the back office,
         9 sent to broker or OTC workflow), the number of deals and the average, p95 and max seconds since the
         previous step. Use it to find AT WHICH LINK of the chain deals wait. Step 3 includes the human Middle Office
         validation (a few minutes is normal); compare with a healthy period of the same length.""",
         f"""FROM {deal} | WHERE {RANGE} | STATS deals = COUNT(*), avg_wait_s = ROUND(AVG({a('stage.wait_s')}), 1),
         p95_wait_s = ROUND(PERCENTILE({a('stage.wait_s')}, 95), 1), max_wait_s = ROUND(MAX({a('stage.wait_s')}), 1)
         BY step = {a('stage.order')}, event = {a('event')}, system = resource.attributes.service.name
         | SORT step, system | LIMIT 50""", layer="chain")
    lost_core = f"""FROM {deal} | WHERE {RANGE}
         | EVAL fo = CASE({a('event')} == "deal_validated_fo", 1, 0), bo = CASE({a('event')} == "deal_received_bo", 1, 0),
           rf = CASE({a('event')} == "deal_routing_failed", 1, 0)
         | STATS fo = SUM(fo), bo = SUM(bo), routing_failed = SUM(rf), last_step = MAX({a('stage.order')}), validated_at = MIN(@timestamp),
           last_seen = MAX(@timestamp) BY deal_id = {a('deal.id')}, desk = {a('desk')}, product_type = {a('product_type')},
           instrument = {a('instrument')}
         | WHERE fo > 0 AND bo == 0
         | EVAL pending_min = DATE_DIFF("minute", validated_at, TO_DATETIME(?end)),
           state = CASE(pending_min >= {k['lost_age_min']}, "lost", "in_flight"),
           last_system = CASE(last_step == 1, "Fast", last_step <= 4, "Murex FO", last_step == 5, "Service Queue", "FOBO"),
           last_event = CASE(routing_failed > 0, "deal_routing_failed (dead letter queue)", last_step == 1, "deal_validated_fo", last_step == 2, "deal_received_mo", last_step == 3,
             "deal_validated_mo", last_step == 4, "deal_sent_bo", last_step == 5, "deal_dequeued", "deal_routed")"""
    tool("lost_deals_summary", f"""Lost deals. Deals validated by a trader in the time range that never reached the back
         office, grouped by desk, product, the last system and last step they reached, and state ("lost" when pending
         for {k['lost_age_min']} min or more at the END of the range, "in_flight" otherwise), with first and last
         validation time. Critical rule: {k['lost_critical_count']} deals lost for more than {k['lost_age_min']} min.
         Set end at least one hour after the period you look at, or use the whole day.""",
         f"""{lost_core} | STATS deals = COUNT(*), first_validated = MIN(validated_at), last_validated = MAX(validated_at)
         BY state, desk, product_type, last_system, last_event | SORT deals DESC | LIMIT 100""", layer="lost")
    tool("lost_deals_list", """Lost deals, recovery list. One row per deal validated in the time range that never reached
         the back office: deal id, desk, product, instrument, validation time, minutes pending at the end of the range,
         last system and step reached. Use it to hand the list of deals to replay, then follow_deal on one of them.""",
         f"""{lost_core} | KEEP deal_id, desk, product_type, instrument, validated_at, pending_min, state, last_system,
         last_event | SORT validated_at | LIMIT 300""", layer="lost")
    tool("queue_status", """Service Queue (Kafka). Consumer lag of topic deals.validated per 5-minute bucket over a time range:
         max messages waiting, max age of the oldest message in seconds, and the Service Queue version running. A
         growing oldest-message age means the consumer cannot keep up.""",
         f"""FROM {app} | WHERE {RANGE} AND {a('log.pattern')} == "consumer_lag"
         | STATS max_lag_messages = MAX({a('queue.lag_messages')}), max_oldest_message_s = MAX({a('queue.oldest_message_age_s')})
           BY bucket = BUCKET(@timestamp, 5 minutes), version = resource.attributes.service.version
         | SORT bucket | LIMIT 300""", layer="root_cause")
    tool("system_versions", """Deployments. Versions seen per system over a time range, with first and last time each
         version was seen and deployment log lines. Use it to detect a deployment, a patch or a rollback and to match it
         with the start and end of a problem.""",
         f"""FROM {tr} | WHERE {RANGE} | STATS spans = COUNT(*), first_seen = MIN(@timestamp), last_seen = MAX(@timestamp)
         BY system = resource.attributes.service.name, version = resource.attributes.service.version
         | SORT system, first_seen | LIMIT 100""", layer="root_cause")
    tool("deployments", """Deployments. Deployment, patch and rollback log lines of every system over a time range, with the
         deployment id and the change.""",
         f"""FROM {app} | WHERE {RANGE} AND {a('log.pattern')} == "deployment"
         | KEEP @timestamp, resource.attributes.service.name, resource.attributes.service.version, body.text
         | SORT @timestamp | LIMIT 50""", layer="root_cause")
    tool("log_patterns", """Technical logs. WARN and ERROR log lines per system, version, pattern, exception type and desk
         over a time range, with first and last occurrence. Use it to see what the systems complain about and when.
         background_warning lines happen every day and are not a cause by themselves.""",
         f"""FROM {app} | WHERE {RANGE} AND severity_text IN ("WARN", "ERROR")
         | STATS occurrences = COUNT(*), first_seen = MIN(@timestamp), last_seen = MAX(@timestamp)
           BY system = resource.attributes.service.name, version = resource.attributes.service.version,
              severity = severity_text, pattern = {a('log.pattern')}, exception = attributes.exception.type, desk = {a('desk')}
         | SORT occurrences DESC | LIMIT 100""", layer="root_cause")
    tool("log_samples", """Technical logs. Latest 20 WARN and ERROR lines of ONE system over a time range, with the full
         message. Use it after log_patterns to read the exact wording of a problem.""",
         f"""FROM {app} | WHERE {RANGE} AND severity_text IN ("WARN", "ERROR") AND resource.attributes.service.name == ?system
         | KEEP @timestamp, severity_text, resource.attributes.service.version, {a('log.pattern')}, {a('deal.id')}, body.text
         | SORT @timestamp DESC | LIMIT 20""",
         {"system": {"type": "string", "description": "Exact system name: " + ", ".join(s["name"] for s in scn["services"])}},
         layer="root_cause")
    tool("deal_status_mismatch", """Middle Office. Deals whose persisted status differs from the status displayed on screen
         at Middle Office validation, per desk and Murex FO version, with first and last occurrence. A deal shown as
         VALIDATED but still PENDING_MO is never sent downstream.""",
         f"""FROM {deal} | WHERE {RANGE} AND {a('event')} == "deal_validated_mo" AND {a('deal.status')} != {a('deal.status_displayed')}
         | STATS deals = COUNT(*), first_seen = MIN(@timestamp), last_seen = MAX(@timestamp)
           BY desk = {a('desk')}, status = {a('deal.status')}, displayed = {a('deal.status_displayed')},
              version = resource.attributes.service.version | SORT deals DESC | LIMIT 50""", layer="root_cause")
    tool("batch_jobs", """Batch. Start, progress and end of the scheduled batch jobs of every system over a time range, with
         planned start time. A batch running in its night window is normal.""",
         f"""FROM {app} | WHERE {RANGE} AND {a('log.pattern')} IN ("batch_started", "batch_finished")
         | KEEP @timestamp, resource.attributes.service.name, {a('job.name')}, {a('log.pattern')}, {a('job.planned_start')}, body.text
         | SORT @timestamp | LIMIT 50""", layer="root_cause")
    tool("screen_activity", """Users. Screen usage per system, screen and desk over a time range (List Deal, Deal Status,
         Reconciliation...). A rise of Deal Status checks for one desk shows users looking for deals that do not arrive.""",
         f"""FROM {tr} | WHERE {RANGE} AND {a('layer')} == "ui" AND {a('deal.id')} IS NULL
         | STATS views = COUNT(*) BY system = resource.attributes.service.name, screen = {a('screen')}, desk = {a('desk')}
         | SORT views DESC | LIMIT 60""", layer="users")
    tool("slowest_deals", f"""Correlation. The 20 deals with the longest descent time arrived in the back office in a time
         range, with trace_id, desk, product and target system. Use it to pick one deal, then follow_deal or
         trace_details. {rule}""",
         f"""{arr} | KEEP @timestamp, {a('deal.id')}, trace_id, {a('desk')}, {a('product_type')}, {a('target_system')},
         {a('descent_time_min')} | SORT {a('descent_time_min')} DESC | LIMIT 20""", layer="correlation")
    tool("follow_deal", f"""Correlation. Every span and log line of ONE deal id across all systems, in time order: front
         office, middle office, queue, bus, back office, broker or OTC workflow, with status, waits and messages. Shows
         where the deal is and where it stopped.""",
         f"""FROM traces-*-{ns}, logs-*-{ns} | WHERE {a('deal.id')} == ?value
         | EVAL duration_ms = ROUND(duration / 1000000.0)
         | KEEP @timestamp, resource.attributes.service.name, resource.attributes.service.version, name, duration_ms,
           {a('event')}, {a('deal.status')}, {a('stage.wait_s')}, severity_text, body.text, trace_id
         | SORT @timestamp | LIMIT 200""",
         {"value": {"type": "string", "description": "Exact deal id, e.g. F2B-04812345"}}, time=False, layer="correlation")
    tool("trace_details", """Correlation. Every span and log line sharing one trace_id, in time order. The trace_id travels
         end to end, from Fast through Kafka and TIBCO to the back office.""",
         f"""FROM traces-*-{ns}, logs-*-{ns} | WHERE trace_id == ?trace_id | EVAL duration_ms = ROUND(duration / 1000000.0)
         | KEEP @timestamp, resource.attributes.service.name, resource.attributes.service.version, name, duration_ms,
           {a('event')}, severity_text, body.text | SORT @timestamp | LIMIT 200""",
         {"trace_id": {"type": "string", "description": "32-character hexadecimal trace id"}}, time=False, layer="correlation")

    chain = " → ".join(s["name"] for s in scn["services"][:4]) + " → Calypso / Murex Back (→ OTC WKF) / HF Trader"
    desks = ", ".join(scn["business_dimension"]["values"])
    instructions = f"""Tu es l'analyste de production de {c['name']} pour la chaîne {c['system']}. Tu réponds en français,
à un public mixte IT et métier : phrases claires, chiffres précis, noms des systèmes et des desks.

Chaîne suivie : {chain}. Un deal validé par un trader dans Fast est validé par le Middle Office dans Murex FO, publié
sur le topic Kafka deals.validated, consommé par Service Queue, routé par FOBO (TIBCO) vers Calypso (dérivés listés),
Murex Back (OTC, puis workflow OTC WKF) ou HF Trader (haute fréquence), puis envoyé au broker.
Desks : {desks}.

Données disponibles : {truth['window']['start']} à {truth['window']['end']} (fuseau {truth['window']['timezone']}). Sans date
précisée, travaille sur cette période. Passe toujours start et end au format ISO 8601 avec le décalage horaire.

Règles de {c['name']} :
- Temps de descente d'un deal = de la validation trader dans Fast à la réception en Back Office.
  Jusqu'à {k['descent_ok_min']} min : OK. De {k['descent_ok_min']} min à {k['descent_critical_min']} min : chaîne dégradée. Au-delà de {k['descent_critical_min']} min : incident.
- Deal perdu = validé par le trader mais jamais reçu en Back Office depuis plus de {k['lost_age_min']} min.
  {k['lost_critical_count']} deals perdus depuis plus de {k['lost_age_min']} min : situation critique.
Ne parle pas d'Apdex.

Méthode, dans cet ordre :
1. Indicateur : descent_time_timeline sur la journée pour repérer quand la descente se dégrade, et
   lost_deals_summary sur la journée pour les deals perdus.
2. Périmètre : descent_time_by_desk et descent_time_by_product. Un seul desk touché oriente vers une règle ou
   une configuration propre à ce desk ; tous les desks touchés orientent vers un composant commun.
3. Maillon : stage_waits pour savoir à quelle étape les deals attendent (compare avec une période saine de même
   durée), et pour les deals perdus la dernière étape atteinte (lost_deals_summary).
4. Cause : dans le système en cause, versions et déploiements (system_versions, deployments), logs
   (log_patterns, log_samples), file Kafka (queue_status), écart entre statut affiché et statut réel
   (deal_status_mismatch).
5. Récupération : pour des deals perdus, donne la liste à rejouer (lost_deals_list) et le système où ils sont bloqués.

Pour suivre un deal précis : slowest_deals ou lost_deals_list pour le choisir, puis follow_deal. Le trace_id et le
deal id voyagent de bout en bout, à travers Kafka et TIBCO.

Pièges connus : les batchs de nuit (batch_jobs) tournent dans leur fenêtre et ne sont pas une cause ; les pics
d'ouverture des marchés européens (09:00) et américains (15:30) augmentent le volume sans dégrader la descente ;
les lignes background_warning existent tous les jours ; un déploiement n'est une cause que si son heure coïncide
avec le début du problème et que le système concerné est le maillon qui attend ou qui perd les deals. Quelques
deals isolés perdus ailleurs ne font pas un incident : vérifie le desk, le système et le nombre.
N'invente aucun chiffre : chaque affirmation vient d'un résultat d'outil.

Format de réponse : 1) le constat chiffré (période, temps de descente ou nombre de deals perdus, desks touchés),
2) le maillon de la chaîne en cause, 3) la cause racine avec ses preuves, 4) la remédiation et, s'il y a des deals
perdus, les deals à récupérer. Heures en heure locale."""
    agent = {"id": f"{ns}-f2b-analyst", "name": f"{c['system']} – Analyste de production",
             "description": f"Suit la descente des deals de {c['name']} du Front au Back Office, explique les ralentissements et retrouve les deals perdus.",
             "labels": [ns, "demo"], "avatar_color": "#BFDBFF", "avatar_symbol": "FB",
             "configuration": {"instructions": instructions, "tools": [{"tool_ids": [t["id"] for t in tools] + BUILTIN}]}}
    (out / "agent.json").write_text(json.dumps({"namespace": ns, "window": truth["window"], "tools": tools, "agent": agent},
                                               ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Wrote {out / 'agent.json'}: {len(tools)} ES|QL tools, agent id {agent['id']}")


def run(raw: dict, out: Path, end=None, total=None) -> None:
    g = DealFlow(raw, out, end, total)
    info = g.run()
    truth, summary = g.truth(info)
    (out / "ground_truth.json").write_text(json.dumps(truth, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "scenario.json").write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
    build_agent(out)
    print(f"Window   : {truth['window']['start']} -> {truth['window']['end']}")
    print(f"Events   : {summary['total_events']} (requested {summary['requested_events']}), {info['deals']} deals, "
          f"{info['padding']} navigation spans as padding")
    for k2, v in summary["events_by_data_stream"].items():
        print(f"  {k2:<42} {v:>8}")
    b = truth["descent"]["baseline"]
    print(f"Descent  : baseline avg {b['avg_min']} min, p95 {b['p95_min']} min, {b['over_ok']} deals over "
          f"{raw['kpi']['descent_ok_min']} min; lost deals (over {raw['kpi']['lost_age_min']} min) {truth['lost_total']}")
    warn = []
    if b["p95_min"] and b["p95_min"] > raw["kpi"]["descent_ok_min"]:
        warn.append("baseline p95 descent above the OK threshold: shorten MO validation times")
    for i in truth["incidents"]:
        if i["type"] == "queue_slowdown":
            print(f"  {i['id']} {i['start_local']}-{i['end_local']} queue_slowdown: avg descent {i['descent']['avg_min']} min, "
                  f"p95 {i['descent']['p95_min']}, {i['descent']['over_critical']} deals over 60 min, peak lag {i['peak_lag_messages']}")
            if (i["descent"]["avg_min"] or 0) <= raw["kpi"]["descent_ok_min"]:
                warn.append(f"{i['id']} does not push the average descent above the OK threshold")
        else:
            print(f"  {i['id']} {i['start_local']}-{i['end_local']} status_not_persisted: {i['lost_deals']} lost deals of "
                  f"{i['desk']}, critical from {i['critical_from_local']}")
            if i["lost_deals"] < raw["kpi"]["lost_critical_count"]:
                warn.append(f"{i['id']} loses fewer deals than the critical count")
    for w in warn:
        print(f"WARNING: {w}")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("scenario", nargs="?")
    ap.add_argument("--out", default="out")
    ap.add_argument("--end")
    ap.add_argument("--total-events", type=int)
    ap.add_argument("--build-agent", metavar="OUT")
    args = ap.parse_args()
    if args.build_agent:
        return build_agent(Path(args.build_agent))
    raw = json.loads(Path(args.scenario).read_text(encoding="utf-8"))
    run(raw, Path(args.out), args.end, args.total_events)


if __name__ == "__main__":
    main()
