#!/usr/bin/env python3
"""Discovery phase: the note-taking sheet, and what comes back filled.

    python3 discovery.py init [--lang fr]                        blank sheet: context and technical topics to fill in
    python3 discovery.py init --name "Customer" --sector "Retail" --system "Orion" --tech "SAP, Java"   pre-filled context
    python3 discovery.py render discovery.json --format md       writes discovery-<slug>.md
    python3 discovery.py render discovery.json --format pptx     writes discovery-<slug>.pptx (needs python-pptx)
    python3 discovery.py ingest filled.md|filled.pptx [--fiche discovery.json]
    python3 discovery.py answer discovery.json SYS-2 "Four Java services: ..."
    python3 discovery.py status [--fiche discovery.json] [--dir .]

The sheet is a set of topics the pre-sales engineer fills in during or after the discovery meeting. By default it
is blank: the customer, the sector and the system are topics of the first theme, to be filled in like the rest.
`discovery.json` (the fiche) is the state: topics, notes, what is still open. A filled sheet is enough to rebuild
it in a new conversation: `ingest` creates it when it does not exist.
Topic ids look like [SYS-2]. Never remove them from a document: they are how notes are matched.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from datetime import date
from pathlib import Path

THEMES = {
    "fr": {"CTX": "Contexte", "SYS": "Systèmes et technologies", "INV": "Parcours d’investigation actuel",
           "KPI": "Indicateur et axe métier", "DAT": "Données et attributs", "COR": "Corrélation entre systèmes",
           "INC": "Incidents vécus", "DEM": "Cadre de la démonstration"},
    "en": {"CTX": "Context", "SYS": "Systems and technologies", "INV": "Current investigation path",
           "KPI": "Indicator and business axis", "DAT": "Data and attributes", "COR": "Correlation between systems",
           "INC": "Incidents they have lived", "DEM": "Demo framing"},
}

# (id, maps_to, fr topic, fr hint, en topic, en hint)
BANK = [
    ("CTX-1", "customer.name", "Client", "Nom de l’entreprise ou de l’entité.", "Customer", "Name of the company or entity."),
    ("CTX-2", "customer.sector", "Secteur d’activité", "Distribution, banque, assurance, télécom, énergie, industrie…",
     "Sector", "Retail, banking, insurance, telecom, energy, manufacturing…"),
    ("CTX-3", "customer.system", "Système principal", "Son nom, et ce qu’il fait pour le métier.",
     "Main system", "Its name, and what it does for the business."),
    ("CTX-4", "technology", "Type de système", "Progiciel (SAP…), développement spécifique, mainframe, mixte.",
     "Type of system", "Packaged product (SAP…), custom development, mainframe, mixed."),
    ("CTX-5", "customer.context", "Utilisateurs", "Qui l’utilise, combien, où.", "Users", "Who uses it, how many, where."),
    ("CTX-6", "customer.context", "Interlocuteurs rencontrés", "Rôles et équipes, sans données personnelles inutiles.",
     "People met", "Roles and teams, no unnecessary personal data."),
    ("CTX-7", "customer.context", "Problème prioritaire à résoudre avec l’IA", "Temps de diagnostic, incidents répétés, dépendance à quelques experts.",
     "Priority problem to solve with AI", "Time to diagnose, repeated incidents, reliance on a few experts."),
    ("CTX-8", "customer.context", "Ce que la démonstration doit prouver, et devant qui", "Critère de succès, public présent.",
     "What the demo must prove, and for whom", "Success criterion, audience."),
    ("SYS-1", "frontend", "Application côté utilisateur", "Nom et technologie : portail web Node.js, client lourd, application mobile…",
     "User-facing application", "Name and technology: Node.js web portal, desktop client, mobile app…"),
    ("SYS-2", "services", "Services ou applications intermédiaires", "Nom, rôle et langage (Java, .NET…). Trois à six suffisent.",
     "Intermediate services or applications", "Name, role and language (Java, .NET…). Three to six are enough."),
    ("SYS-3", "sap, databases", "Système central et bases de données", "SAP, mainframe, Oracle, PostgreSQL… avec leur nom.",
     "Core system and databases", "SAP, mainframe, Oracle, PostgreSQL… with their names."),
    ("SYS-4", "externals", "Partenaires et API externes", "Paiement, transport, scoring, référentiels…",
     "Partners and external APIs", "Payment, shipping, scoring, reference data…"),
    ("SYS-5", "screens", "Écrans ou transactions les plus utilisés", "Cinq ou six noms, tels que les utilisateurs les appellent.",
     "Most used screens or transactions", "Five or six names, as users call them."),
    ("INV-1", "customer.investigation_path", "Étapes suivies lors d’un ralentissement", "Dans l’ordre, de l’interface jusqu’à la cause.",
     "Steps followed during a slowdown", "In order, from the UI down to the cause."),
    ("INV-2", "customer.investigation_path", "Outil ou source de données à chaque étape", "APM, logs, transactions d’analyse du progiciel…",
     "Tool or data source in each step", "APM, logs, analysis transactions of the packaged product…"),
    ("INV-3", "customer.context", "Étape la plus longue, et pourquoi", "", "Longest step, and why", ""),
    ("INV-4", "customer.context", "Équipes impliquées", "Qui intervient à chaque étape, niveaux de support.",
     "Teams involved", "Who steps in at each stage, support levels."),
    ("INV-5", "customer.context", "Durée et effort d’un diagnostic aujourd’hui", "Ordre de grandeur : temps passé, nombre de personnes.",
     "Duration and effort of a diagnosis today", "Order of magnitude: time spent, number of people."),
    ("KPI-1", "apdex", "Indicateur suivi", "Apdex, temps de réponse, disponibilité. « Aucun » s’il n’y en a pas.",
     "Indicator tracked", "Apdex, response time, availability. “None” if there is none."),
    ("KPI-2", "apdex", "Mode de calcul et seuils", "Par exemple satisfait sous 4 s, toléré jusqu’à 16 s.",
     "How it is computed, thresholds", "For instance satisfied under 4 s, tolerated up to 16 s."),
    ("KPI-3", "apdex", "Objectif, et à qui il est présenté", "", "Target, and who it is reported to", ""),
    ("KPI-4", "business_dimension", "Axe d’analyse métier", "{axis}", "Business axis of analysis", "{axis}"),
    ("DAT-1", "context", "Données déjà dans Elasticsearch, données prévues", "Logs, métriques, traces, données fonctionnelles.",
     "Data already in Elasticsearch, data planned", "Logs, metrics, traces, business data."),
    ("DAT-2", "attributes", "Attributs clés par système", "Les champs lus ou recherchés dans les messages : {attrs}",
     "Key attributes per system", "Fields read or searched in the messages: {attrs}"),
    ("DAT-3", "attributes", "Exemple de log ou de message", "Avec des valeurs fictives. Aucune donnée réelle ni personnelle.",
     "Sample log line or message", "With made-up values. No real or personal data."),
    ("DAT-4", "load_profile, dataset", "Volume de trafic et heures de charge", "Ordre de grandeur sur une journée.",
     "Traffic volume and busy hours", "Order of magnitude over a day."),
    ("COR-1", "correlation", "Identifiant de trace : jusqu’où va-t-il", "De l’interface aux services ? Jusqu’au système central ? Aucun ?",
     "Trace identifier: how far it goes", "From the UI to the services? Down to the core system? None?"),
    ("COR-2", "correlation", "Identifiant de trace dans les logs applicatifs", "Présent ou absent.",
     "Trace identifier in application logs", "Present or absent."),
    ("COR-3", "attributes (propagate)", "Clé métier commune à plusieurs systèmes", "Numéro de commande, de dossier, identifiant de corrélation, et dans quels systèmes.",
     "Business key shared by several systems", "Order number, case number, correlation id, and in which systems."),
    ("COR-4", "context", "Rapprochement actuel quand rien ne relie deux systèmes", "Par l’heure, par l’utilisateur, à la main.",
     "How they match two systems when nothing ties them", "By time, by user, by hand."),
    ("INC-1", "incidents", "Incidents de performance récents et leur cause", "Deux à quatre exemples : traitement lancé au mauvais moment, partenaire lent, régression après livraison…",
     "Recent performance incidents and their cause", "Two to four examples: a batch started at the wrong time, a slow partner, a regression after a release…"),
    ("INC-2", "incidents", "Incident le plus long à diagnostiquer, et pourquoi", "", "Longest incident to diagnose, and why", ""),
    ("INC-3", "decoys", "Fausses pistes fréquentes", "Un traitement de nuit normal, un pic habituel.", "Frequent false leads", "A normal night batch, a usual peak."),
    ("INC-4", "incidents", "Cause que l’IA devrait retrouver seule", "Ce qui impressionnerait le client.",
     "Cause AI should find on its own", "What would impress the customer."),
    ("DEM-1", "elastic target", "IA Elastic montrée et type de projet", "Par défaut : un agent Agent Builder, projet Serverless Observability.",
     "Elastic AI shown and type of project", "Default: an Agent Builder agent, Serverless Observability project."),
    ("DEM-2", "dataset", "Volume et période du jeu de données", "Par défaut : 100 000 événements sur 24 heures.",
     "Dataset volume and period", "Default: 100,000 events over 24 hours."),
    ("DEM-3", "slides", "Format et langue des slides de résumé", "Google Slides, PowerPoint ou page web.",
     "Format and language of the summary slides", "Google Slides, PowerPoint or web page."),
    ("DEM-4", "dataset.end", "Date de la démonstration", "Les données seront datées du dernier jour ouvré précédent.",
     "Date of the demo", "The data will be dated on the last business day before."),
]

SAP = [
    ("SYS-6", "sap", "Version de SAP et mode d’appel", "ECC ou S/4HANA ; appels HTTP/OData, RFC, IDoc…",
     "SAP version and how it is called", "ECC or S/4HANA; HTTP/OData, RFC, IDoc calls…"),
    ("INV-6", "sap", "Transactions SAP d’analyse utilisées", "ST03, SM50, SM37, SM21…", "SAP analysis transactions used", "ST03, SM50, SM37, SM21…"),
    ("INC-5", "sap.jobs", "Jobs SAP les plus lourds et leurs horaires", "Nom, heure planifiée, durée habituelle. Deux ou trois suffisent.",
     "Heaviest SAP jobs and their schedule", "Name, planned time, usual duration. Two or three are enough."),
]

SECTORS = {    # keyword -> (fr axis, fr attributes, en axis, en attributes)
    ("retail", "distribution", "commerce", "magasin", "negoce", "agence"): (
        "Agence, magasin, canal de vente…", "numéro de commande, code agence ou magasin, canal, nombre de lignes, mode de paiement…",
        "Agency, store, sales channel…", "order number, agency or store code, channel, number of lines, payment method…"),
    ("banque", "bank", "paiement", "payment", "finance"): (
        "Canal, réseau d’agences, pays…", "schéma de paiement, identifiant commerçant, acquéreur, code réponse, devise…",
        "Channel, branch network, country…", "payment scheme, merchant id, acquirer, response code, currency…"),
    ("assurance", "insurance", "mutuelle"): (
        "Branche, réseau de distribution…", "numéro de contrat, numéro de sinistre, branche, réseau…",
        "Product line, distribution network…", "contract id, claim id, product line, network…"),
    ("telecom", "operateur"): (
        "Offre, segment d’abonnés, région…", "offre, segment, élément réseau, cellule, type de commande…",
        "Offer, subscriber segment, region…", "offer, segment, network element, cell, order type…"),
    ("energie", "energy", "utilit"): (
        "Région, type de compteur…", "point de livraison, type de compteur, région, type d’intervention…",
        "Region, meter type…", "delivery point id, meter type, region, intervention type…"),
    ("media", "jeu", "gaming", "paris"): (
        "Plateforme, marché, type d’appareil…", "plateforme, appareil, identifiant de contenu, marché, type de session…",
        "Platform, market, device type…", "platform, device, content id, market, session type…"),
    ("industrie", "manufactur", "usine", "production"): (
        "Usine, ligne, famille de produits…", "usine, ligne, ordre de fabrication, référence article, fournisseur…",
        "Plant, line, product family…", "plant, line, work order, part number, supplier…"),
}
GENERIC = ("Agence, magasin, pays, canal…", "numéro de commande ou de dossier, code de site, identifiant de session, canal…",
           "Agency, store, country, channel…", "order or case number, site code, session id, channel…")

L = {
    "fr": {"title": "Découverte de l’environnement", "blank": "Fiche de prise de notes", "date": "Fiche préparée le {d}",
           "how": "Mode d’emploi", "howto": [
               "Remplissez chaque rubrique pendant ou après l’entretien. Quelques mots suffisent.",
               "Commencez par le contexte : client, secteur, système. Tout le reste s’y rattache.",
               "Écrivez « ne sait pas » quand le client n’a pas la réponse : une hypothèse sera proposée et annoncée.",
               "Laissez vide ce qui n’a pas été abordé : ces rubriques seront reprises ensuite.",
               "Aucune donnée réelle ni personnelle. Des noms de systèmes et des valeurs fictives suffisent.",
               "Gardez les références entre crochets, comme [SYS-2] : elles servent à relire les notes."],
           "q": "Rubrique", "a": "Notes", "answer": "Notes :", "why": "Repère"},
    "en": {"title": "Environment discovery", "blank": "Note-taking sheet", "date": "Sheet prepared on {d}",
           "how": "How to use this sheet", "howto": [
               "Fill in each topic during or after the meeting. A few words are enough.",
               "Start with the context: customer, sector, system. Everything else hangs on it.",
               "Write “don’t know” when the customer has no answer: an assumption will be proposed and stated.",
               "Leave empty what was not covered: those topics will be picked up afterwards.",
               "No real or personal data. System names and made-up values are enough.",
               "Keep the references in brackets, such as [SYS-2]: they are used to read the notes back."],
           "q": "Topic", "a": "Notes", "answer": "Notes:", "why": "Hint"},
}
UNKNOWN = re.compile(r"^\W*(ne sai[st] pas|je ne sais pas|nsp|inconnu|aucune id[ée]e|don[’']?t know|do not know|unknown|no idea|\?+)\W*$", re.I)
ID = re.compile(r"\[([A-Z]{3}-\d+)\]")


def slugify(text: str) -> str:
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_") or "customer"


def die(msg: str) -> None:
    sys.exit(f"ERROR: {msg}")


def load(path: Path) -> dict:
    if not path.exists():
        die(f"{path} not found. Create it with 'discovery.py init', or rebuild it from a filled document with 'ingest'.")
    return json.loads(path.read_text(encoding="utf-8"))


def save(path: Path, fiche: dict) -> None:
    fiche["updated"] = date.today().isoformat()
    path.write_text(json.dumps(fiche, ensure_ascii=False, indent=2), encoding="utf-8")


def classify(answer: str) -> str:
    answer = (answer or "").strip()
    if not answer:
        return "open"
    return "unknown" if UNKNOWN.match(answer) else "answered"


def hints(blob: str, lang: str) -> tuple[str, str]:
    for keys, (fa, ft, ea, et) in SECTORS.items():
        if any(k in blob for k in keys):
            return (fa, ft) if lang == "fr" else (ea, et)
    return (GENERIC[0], GENERIC[1]) if lang == "fr" else (GENERIC[2], GENERIC[3])


def topics(bank, lang: str, blob: str) -> list[dict]:
    axis, attrs = hints(blob, lang)
    out = []
    for qid, maps, fq, fh, eq, eh in bank:
        text, hint = (fq, fh) if lang == "fr" else (eq, eh)
        out.append({"id": qid, "theme": qid[:3], "text": text, "hint": hint.format(axis=axis, attrs=attrs),
                    "maps_to": maps, "answer": "", "status": "open"})
    return out


def sync(fiche: dict) -> list[str]:
    """Keeps the customer block in line with the context notes, and adds technology topics once it is known."""
    lang = fiche["customer"].get("language", "fr")
    notes = {q["id"]: q.get("answer", "").strip() for q in fiche["questions"]}
    c = fiche["customer"]
    c["name"] = notes.get("CTX-1") or c.get("name", "")
    c["sector"] = notes.get("CTX-2") or c.get("sector", "")
    system = notes.get("CTX-3") or c.get("system", "")
    c["system"] = re.split(r"[,;:(\n]", system)[0].strip()
    c["technology"] = "; ".join(x for x in (notes.get("CTX-4"), notes.get("SYS-3")) if x) or c.get("technology", "")
    blob = slugify(" ".join([c["sector"], system, c["technology"]] + [v for k, v in notes.items() if k.startswith("SYS")]))
    maps = {q[0]: q[1] for q in BANK + SAP}
    for q in fiche["questions"]:                              # a fiche rebuilt from a document has lost this
        q["maps_to"] = q.get("maps_to") or maps.get(q["id"], "")
    added = []
    if re.search(r"(^|_)sap(_|$)", blob) and "SYS-6" not in notes:
        fiche["questions"] += topics(SAP, lang, blob)
        added = [q[0] for q in SAP]
    axis, attrs = hints(blob, lang)                            # sector known: sharpen the two sector-dependent hints
    base = {q[0]: q for q in BANK}
    for q in fiche["questions"]:
        if q["id"] in ("KPI-4", "DAT-2") and q["status"] == "open":
            q["hint"] = (base[q["id"]][3] if lang == "fr" else base[q["id"]][5]).format(axis=axis, attrs=attrs)
    order = list(THEMES[lang] if lang in THEMES else THEMES["en"])
    fiche["questions"].sort(key=lambda q: (order.index(q["theme"]) if q["theme"] in order else 99, int(q["id"][4:])))
    return added


# --------------------------------------------------------------------------- init
def cmd_init(a) -> None:
    lang = a.lang if a.lang in L else "en"
    fiche = {"customer": {"name": "", "sector": "", "system": "", "technology": "", "language": lang},
             "created": date.today().isoformat(), "questions": topics(BANK, lang, ""), "notes": []}
    given = {"CTX-1": a.name, "CTX-2": a.sector, "CTX-3": a.system, "CTX-4": a.tech}
    for q in fiche["questions"]:
        if given.get(q["id"]):
            q["answer"], q["status"] = given[q["id"]], "answered"
    added = sync(fiche)
    out = Path(a.out)
    if out.exists() and not a.force:
        die(f"{out} already exists. Use --force to start over, or keep working on it.")
    save(out, fiche)
    kind = "context pre-filled" if any(given.values()) else "blank sheet"
    print(f"Wrote {out}: {len(fiche['questions'])} topics in {len({q['theme'] for q in fiche['questions']})} themes, {kind}"
          f"{' (SAP topics added)' if added else ''}.")


# --------------------------------------------------------------------------- render
def by_theme(fiche: dict) -> list[tuple[str, str, list]]:
    lang = fiche["customer"].get("language", "fr")
    names = THEMES.get(lang, THEMES["en"])
    seen: dict[str, list] = {}
    for q in fiche["questions"]:
        seen.setdefault(q["theme"], []).append(q)
    return [(code, names.get(code, code), qs) for code, qs in seen.items()]


def heading(fiche: dict) -> tuple[str, str]:
    c = fiche["customer"]
    lang = c.get("language", "fr")
    t = L.get(lang, L["en"])
    sep = " : " if lang == "fr" else ": "
    who = " · ".join(x for x in (c.get("name"), c.get("system")) if x)
    return (t["title"] + (sep + who if who else ""), t["blank"])


def render_md(fiche: dict) -> str:
    c = fiche["customer"]
    t = L.get(c.get("language", "fr"), L["en"])
    sep = " : " if c.get("language", "fr") == "fr" else ": "
    title, sub = heading(fiche)
    out = [f"# {title}", "", f"{sub}. {t['date'].format(d=date.today().isoformat())}.", "", f"## {t['how']}", ""]
    out += [f"- {x}" for x in t["howto"]] + [""]
    for i, (code, name, qs) in enumerate(by_theme(fiche)):
        out += [f"## {chr(65 + i)}. {name}", ""]
        for q in qs:
            out += [f"### [{q['id']}] {q['text']}", ""]
            if q.get("hint"):
                out += [f"_{t['why']}{sep}{q['hint']}_", ""]
            out += [t["answer"], "", q.get("answer", ""), "", ""]
    return "\n".join(out)


def render_pptx(fiche: dict, dest: Path) -> None:
    try:
        from lxml import etree
        from pptx import Presentation
        from pptx.dml.color import RGBColor
        from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
        from pptx.util import Inches, Pt
    except ImportError:
        die("the slide format needs python-pptx: pip install python-pptx")
    A = "http://schemas.openxmlformats.org/drawingml/2006/main"
    INK, MUTED, PANEL, LINE = "101C3F", "55627F", "F1F4FA", "D5DCE9"
    c = fiche["customer"]
    t = L.get(c.get("language", "fr"), L["en"])
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(10), Inches(5.625)

    def font(run, size, bold=False, color=INK, italic=False):
        run.font.name, run.font.size, run.font.bold, run.font.italic = "Arial", Pt(size), bold, italic
        run.font.color.rgb = RGBColor.from_string(color)

    def title(slide, text, size=26, color=INK, top=0.3, h=0.8):
        ph = slide.shapes.title
        ph.left, ph.top, ph.width, ph.height = Inches(0.5), Inches(top), Inches(9), Inches(h)
        tf = ph.text_frame
        tf.word_wrap, tf.vertical_anchor = True, MSO_ANCHOR.TOP
        tf.text = text
        tf.paragraphs[0].alignment = PP_ALIGN.LEFT
        font(tf.paragraphs[0].runs[0], size, True, color)

    s = prs.slides.add_slide(prs.slide_layouts[0])
    s.background.fill.solid()
    s.background.fill.fore_color.rgb = RGBColor.from_string(INK)
    title(s, heading(fiche)[0], 34, "FFFFFF", 1.7, 1.4)
    sub = s.placeholders[1]
    sub.left, sub.top, sub.width, sub.height = Inches(0.5), Inches(3.2), Inches(9), Inches(1.0)
    sub.text_frame.text = t["blank"]
    sub.text_frame.paragraphs[0].alignment = PP_ALIGN.LEFT
    font(sub.text_frame.paragraphs[0].runs[0], 16, False, "C9D3E8")
    p = sub.text_frame.add_paragraph()
    p.alignment = PP_ALIGN.LEFT
    font(p.add_run(), 12, False, "C9D3E8")
    p.runs[0].text = t["date"].format(d=date.today().isoformat())

    s = prs.slides.add_slide(prs.slide_layouts[5])
    title(s, t["how"])
    tb = s.shapes.add_textbox(Inches(0.5), Inches(1.3), Inches(9), Inches(3.8))
    tb.text_frame.word_wrap = True
    for i, line in enumerate(t["howto"]):
        p = tb.text_frame.paragraphs[0] if i == 0 else tb.text_frame.add_paragraph()
        p.space_after = Pt(12)
        pPr = p._p.get_or_add_pPr()
        pPr.set("marL", str(int(Inches(0.25))))
        pPr.set("indent", str(-int(Inches(0.25))))
        etree.SubElement(pPr, f"{{{A}}}buChar").set("char", "•")
        font(p.add_run(), 16)
        p.runs[0].text = line

    for i, (code, name, qs) in enumerate(by_theme(fiche)):
        pages = -(-len(qs) // 4)
        size = -(-len(qs) // pages)
        for pg in range(pages):
            chunk = qs[pg * size:(pg + 1) * size]
            s = prs.slides.add_slide(prs.slide_layouts[5])
            title(s, f"{chr(65 + i)}. {name}" + (f" ({pg + 1}/{pages})" if pages > 1 else ""))
            gf = s.shapes.add_table(len(chunk) + 1, 2, Inches(0.5), Inches(1.2), Inches(9), Inches(0.4 + 0.92 * len(chunk)))
            tbl = gf.table
            tbl._tbl.tblPr.find(f"{{{A}}}tableStyleId").text = "{2D5ABB26-0587-4C30-8999-92F81FD0307C}"
            tbl.first_row, tbl.horz_banding = True, False
            tbl.columns[0].width, tbl.columns[1].width = Inches(4.3), Inches(4.7)
            tbl.rows[0].height = Inches(0.35)
            for col, head in enumerate((t["q"], t["a"])):
                cell = tbl.cell(0, col)
                font(cell.text_frame.paragraphs[0].add_run(), 11, True, MUTED)
                cell.text_frame.paragraphs[0].runs[0].text = head
            for r, q in enumerate(chunk, 1):
                tbl.rows[r].height = Inches(0.92)
                cell = tbl.cell(r, 0)
                cell.text_frame.word_wrap = True
                p = cell.text_frame.paragraphs[0]
                font(p.add_run(), 9, True, MUTED)
                p.runs[0].text = f"[{q['id']}]  "
                font(p.add_run(), 12)
                p.runs[1].text = q["text"]
                if q.get("hint"):
                    p2 = cell.text_frame.add_paragraph()
                    font(p2.add_run(), 10, False, MUTED, True)
                    p2.runs[0].text = q["hint"]
                ans = tbl.cell(r, 1)
                ans.text_frame.word_wrap = True
                ans.fill.solid()
                ans.fill.fore_color.rgb = RGBColor.from_string(PANEL)
                font(ans.text_frame.paragraphs[0].add_run(), 12)
                ans.text_frame.paragraphs[0].runs[0].text = q.get("answer", "")
            for r in range(len(chunk) + 1):
                for col in range(2):
                    cell = tbl.cell(r, col)
                    cell.margin_left = cell.margin_right = Inches(0.08)
                    cell.margin_top = cell.margin_bottom = Inches(0.06)
                    lnb = etree.SubElement(cell._tc.get_or_add_tcPr(), f"{{{A}}}lnB")
                    lnb.set("w", "9525")
                    etree.SubElement(etree.SubElement(lnb, f"{{{A}}}solidFill"), f"{{{A}}}srgbClr").set("val", LINE)
    prs.save(dest)


def cmd_render(a) -> None:
    fiche = load(Path(a.fiche))
    dest = Path(a.out or f"discovery-{slugify(fiche['customer'].get('name') or 'notes')}.{a.format}")
    if a.format == "md":
        dest.write_text(render_md(fiche), encoding="utf-8")
    else:
        render_pptx(fiche, dest)
    print(f"Wrote {dest} ({len(fiche['questions'])} topics)")


# --------------------------------------------------------------------------- ingest
def parse_md(text: str) -> tuple[str, list[dict]]:
    found = []
    lang = "fr" if re.search(r"^_Repère|^Notes :|^## Mode d", text, flags=re.M) else "en"
    blocks = re.split(r"^(#{2,3} .*)$", text, flags=re.M)
    for head, body in zip(blocks[1::2], blocks[2::2]):
        m = ID.search(head)
        if not m:
            continue
        hint = re.search(r"^_(?:Repère|Hint)\s*:\s*(.*?)_\s*$", body, flags=re.M)
        parts = re.split(r"^\s*(?:Notes|Réponse|Answer)\s*:[ \t]*", body, maxsplit=1, flags=re.M)
        answer = parts[1].strip() if len(parts) > 1 else ""
        found.append({"id": m.group(1), "theme": m.group(1)[:3], "text": head.split("]", 1)[1].strip(),
                      "hint": hint.group(1) if hint else "", "answer": answer})
    return lang, found


def parse_pptx(path: Path) -> tuple[str, list[dict]]:
    try:
        from pptx import Presentation
    except ImportError:
        die("reading a .pptx needs python-pptx: pip install python-pptx")
    prs = Presentation(str(path))
    found, lang = [], "en"
    for slide in prs.slides:
        for sh in slide.shapes:
            if not getattr(sh, "has_table", False) or not sh.has_table:
                continue
            for row in sh.table.rows:
                cells = [c.text_frame for c in row.cells]
                if len(cells) < 2:
                    continue
                if cells[0].text.strip() == "Rubrique":
                    lang = "fr"
                m = ID.search(cells[0].text)
                if not m:
                    continue
                paras = [p.text.strip() for p in cells[0].paragraphs if p.text.strip()]
                text = paras[0].split("]", 1)[1].strip() if paras else ""
                found.append({"id": m.group(1), "theme": m.group(1)[:3], "text": text,
                              "hint": paras[1] if len(paras) > 1 else "", "answer": cells[1].text.strip()})
    return lang, found


def cmd_ingest(a) -> None:
    src = Path(a.document)
    if not src.exists():
        die(f"{src} not found")
    ext = src.suffix.lower()
    if ext in (".md", ".txt", ".markdown"):
        lang, found = parse_md(src.read_text(encoding="utf-8"))
    elif ext == ".pptx":
        lang, found = parse_pptx(src)
    else:
        die(f"cannot parse {ext} files. Read the document yourself and record each answer with: "
            f"discovery.py answer <fiche> <ID> \"<answer>\" (ids are the [XXX-n] references in the document).")
    if not found:
        die("no topic id such as [SYS-2] found in this document. Was it produced by 'discovery.py render'? "
            "If the ids were removed, read the answers yourself and record them with 'discovery.py answer'.")
    path = Path(a.fiche)
    if path.exists():
        fiche = load(path)
    else:
        fiche = {"customer": {"name": "", "sector": "", "system": "", "technology": "", "language": lang},
                 "created": date.today().isoformat(), "questions": [], "notes": [f"Fiche rebuilt from {src.name}"]}
        print(f"{path} did not exist: rebuilt from the document.")
    known = {q["id"]: q for q in fiche["questions"]}
    changed = 0
    for f in found:
        q = known.get(f["id"])
        if q is None:
            q = {"id": f["id"], "theme": f["theme"], "text": f["text"], "hint": f["hint"], "maps_to": "", "answer": "", "status": "open"}
            fiche["questions"].append(q)
            known[q["id"]] = q
        if f["answer"] and f["answer"] != q.get("answer"):
            q["answer"], changed = f["answer"], changed + 1
        q["status"] = classify(q.get("answer", ""))
    missing = [i for i in known if i not in {f["id"] for f in found}]
    added = sync(fiche)
    save(path, fiche)
    print(f"Read {len(found)} topics from {src.name}: {changed} new or changed notes.")
    if added:
        print(f"SAP appears in the notes: topics {', '.join(added)} were added and are open.")
    if missing:
        print(f"Topics of the fiche absent from the document: {', '.join(missing)}")
    report(fiche)


def cmd_answer(a) -> None:
    path = Path(a.fiche)
    fiche = load(path)
    q = next((q for q in fiche["questions"] if q["id"] == a.id), None)
    if q is None:
        die(f"no question {a.id} in {path}. Ids: {', '.join(x['id'] for x in fiche['questions'])}")
    q["answer"] = a.text
    q["status"] = classify(a.text)
    added = sync(fiche)
    save(path, fiche)
    print(f"{a.id}: {q['status']}" + (f". SAP appears in the notes: topics {', '.join(added)} were added and are open." if added else ""))


# --------------------------------------------------------------------------- status
def report(fiche: dict) -> None:
    c = fiche["customer"]
    qs = fiche["questions"]
    n = {s: sum(1 for q in qs if q["status"] == s) for s in ("answered", "unknown", "open")}
    print(f"\nDiscovery: {c.get('name') or '?'} / {c.get('system') or '?'} ({c.get('sector') or '?'})")
    print(f"  {n['answered']} answered, {n['unknown']} 'do not know' (use a default and say so), {n['open']} open, out of {len(qs)}")
    for code, name, items in by_theme(fiche):
        done = sum(1 for q in items if q["status"] == "answered")
        print(f"  {name:<46} {done}/{len(items)}")
    for label, status in (("Open, to ask or fill in", "open"), ("Unknown, to settle with a stated default", "unknown")):
        left = [q for q in qs if q["status"] == status]
        if left:
            print(f"\n{label}:")
            for q in left:
                print(f"  [{q['id']}] {q['text']}")


def cmd_status(a) -> None:
    base = Path(a.dir)
    fiche_path = Path(a.fiche) if a.fiche else base / "discovery.json"
    if fiche_path.exists():
        report(load(fiche_path))
    else:
        print("Discovery: no fiche yet (discovery.json). Start with 'Préparer la découverte' or ingest a filled document.")
    out = base / a.out
    steps = [("Scenario written", (base / "scenario.json").exists() or (out / "scenario.json").exists(), "write the scenario from the discovery answers"),
             ("Dataset generated", (out / "summary.json").exists(), "generate the dataset"),
             ("Agent defined", (out / "agent.json").exists(), "build the agent definition"),
             ("Demo questions written", (out / "questions.json").exists(), "write the demo questions"),
             ("Summary slides built", (out / "summary-deck.html").exists() or (out / "summary-deck.pptx").exists(), "build the summary slides"),
             ("Loaded into Elastic", (out / ".ingested").exists(), "load the dataset into the Elastic project, or build the local kit"),
             ("Rehearsed with the agent", (out / "rehearsal.md").exists(), "rehearse the questions with the agent")]
    print("\nDemo build:")
    for label, ok, _ in steps:
        print(f"  [{'x' if ok else ' '}] {label}")
    if (out / "summary.json").exists():
        s = json.loads((out / "summary.json").read_text(encoding="utf-8"))
        print(f"  Dataset: {s['total_events']} events, {s['window']['start']} -> {s['window']['end']}, namespace {s['namespace']}")
    if (out / ".ingested").exists():
        print(f"  Last load: {(out / '.ingested').read_text().strip()[:120]}")
    nxt = next((todo for _, ok, todo in steps if not ok), None)
    if fiche_path.exists() and not steps[0][1]:
        left = sum(1 for q in load(fiche_path)["questions"] if q["status"] == "open")
        if left:
            nxt = f"close the {left} open discovery questions (ask them, or get the filled document back), then write the scenario"
    print(f"\nNext step: {nxt or 'everything is done; refresh the dates and rehearse again before the demo day'}")
    print("Note: only files of this working directory are visible. In a new conversation, upload the fiche or the filled document again.")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init")
    p.add_argument("--name", help="optional: pre-fills the Customer topic")
    p.add_argument("--sector", help="optional: pre-fills the Sector topic and sharpens the hints")
    p.add_argument("--system", help="optional: pre-fills the Main system topic")
    p.add_argument("--tech", help="optional: pre-fills the Type of system topic; SAP adds SAP topics")
    p.add_argument("--lang", default="fr")
    p.add_argument("--out", default="discovery.json")
    p.add_argument("--force", action="store_true")
    p.set_defaults(fn=cmd_init)
    p = sub.add_parser("render")
    p.add_argument("fiche")
    p.add_argument("--format", choices=("md", "pptx"), required=True)
    p.add_argument("--out")
    p.set_defaults(fn=cmd_render)
    p = sub.add_parser("ingest")
    p.add_argument("document")
    p.add_argument("--fiche", default="discovery.json")
    p.set_defaults(fn=cmd_ingest)
    p = sub.add_parser("answer")
    p.add_argument("fiche")
    p.add_argument("id")
    p.add_argument("text")
    p.set_defaults(fn=cmd_answer)
    p = sub.add_parser("status")
    p.add_argument("--fiche")
    p.add_argument("--dir", default=".")
    p.add_argument("--out", default="out")
    p.set_defaults(fn=cmd_status)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
