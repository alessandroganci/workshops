"""Shared helpers: configuration from environment / env file, and a small HTTP client.

Standard library only, so the scripts run anywhere Python 3.9+ is installed.

Configuration keys (environment variables, or KEY=VALUE lines in --env-file):
    ELASTIC_OTLP_ENDPOINT   Managed OTLP endpoint of the project, e.g. https://xxx.ingest.eu-west-1.aws.elastic.cloud:443
    ELASTICSEARCH_URL       Elasticsearch endpoint of the project
    KIBANA_URL              Kibana endpoint of the project
    ELASTIC_API_KEY         Encoded API key (used for the three endpoints unless overridden below)
    ELASTIC_OTLP_API_KEY    Optional: a different key for the OTLP endpoint
    KIBANA_SPACE            Optional: Kibana space id (default space when empty)
"""
from __future__ import annotations

import json
import os
import ssl
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path


def die(msg: str) -> None:
    sys.exit(f"ERROR: {msg}")


def load_env(env_file: str | None) -> dict:
    cfg = dict(os.environ)
    if env_file:
        path = Path(env_file)
        if not path.exists():
            die(f"env file not found: {env_file}")
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                cfg[k.strip()] = v.strip().strip('"').strip("'")
    return cfg


def need(cfg: dict, key: str) -> str:
    val = cfg.get(key, "").strip()
    if not val:
        die(f"{key} is not set. Export it or put it in the env file (see scripts/common.py for the list of keys).")
    return val.rstrip("/")


def api_key_header(cfg: dict, key: str = "ELASTIC_API_KEY") -> dict:
    val = cfg.get(key) or cfg.get("ELASTIC_API_KEY") or ""
    if not val.strip():
        return {}                                             # local unsecured cluster
    val = val.strip()
    return {"Authorization": val if val.lower().startswith(("apikey ", "bearer ")) else f"ApiKey {val}"}


def http(method: str, url: str, headers: dict | None = None, body=None, timeout: int = 60,
         retries: int = 4) -> tuple[int, bytes]:
    """Returns (status, body). Retries on 429 and 5xx with backoff. Never raises on HTTP errors."""
    data = None
    headers = dict(headers or {})
    if body is not None:
        if isinstance(body, (bytes, bytearray)):
            data = bytes(body)
        else:
            data = json.dumps(body).encode("utf-8")
            headers.setdefault("Content-Type", "application/json")
    ctx = ssl.create_default_context()
    last: tuple[int, bytes] = (0, b"")
    for attempt in range(retries + 1):
        req = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as e:
            last = (e.code, e.read())
            if e.code not in (429, 500, 502, 503, 504):
                return last
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            last = (0, str(e).encode())
        if attempt < retries:
            time.sleep(min(2 ** attempt, 20))
    return last


def as_json(raw: bytes):
    try:
        return json.loads(raw.decode("utf-8"))
    except Exception:
        return {"raw": raw.decode("utf-8", "replace")[:2000]}


def esql(cfg: dict, query: str, params: list | None = None) -> list[dict]:
    """Run an ES|QL query and return rows as dicts. Exits with the server message on failure."""
    url = need(cfg, "ELASTICSEARCH_URL") + "/_query"
    body: dict = {"query": query}
    if params:
        body["params"] = params
    status, raw = http("POST", url, api_key_header(cfg), body)
    if status != 200:
        die(f"ES|QL failed ({status}): {raw.decode('utf-8', 'replace')[:800]}\nQuery: {query}")
    res = as_json(raw)
    cols = [c["name"] for c in res.get("columns", [])]
    return [dict(zip(cols, row)) for row in res.get("values", [])]
