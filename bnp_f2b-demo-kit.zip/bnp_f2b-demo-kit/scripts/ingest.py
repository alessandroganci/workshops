#!/usr/bin/env python3
"""Send a generated dataset to Elastic through OTLP/HTTP.

Target: the Elastic Cloud Managed OTLP Endpoint of a Serverless project (ELASTIC_OTLP_ENDPOINT).
A self-managed cluster works too: set ELASTIC_OTLP_ENDPOINT to https://<es-host>:9200/_otlp.

Usage:
    python3 ingest.py --check [--env-file demo.env]          connectivity and authentication test, sends nothing
    python3 ingest.py out/ [--env-file demo.env]             send traces, logs and metrics
    python3 ingest.py out/ --signals logs,traces --force     resend part of the dataset

Encoding: protobuf when the 'opentelemetry-proto' package is importable (most widely supported),
otherwise OTLP/JSON with the standard library only. Force one with --encoding.
"""
from __future__ import annotations

import argparse
import base64
import gzip
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import api_key_header, as_json, die, http, load_env, need  # noqa: E402

SIGNALS = ("logs", "traces", "metrics")
ROOT_KEY = {"traces": "resourceSpans", "logs": "resourceLogs", "metrics": "resourceMetrics"}


def proto_classes():
    try:
        from google.protobuf import json_format
        from opentelemetry.proto.collector.logs.v1 import logs_service_pb2 as lg
        from opentelemetry.proto.collector.metrics.v1 import metrics_service_pb2 as mt
        from opentelemetry.proto.collector.trace.v1 import trace_service_pb2 as tr
    except ImportError:
        return None
    return {"json_format": json_format,
            "traces": (tr.ExportTraceServiceRequest, tr.ExportTraceServiceResponse),
            "logs": (lg.ExportLogsServiceRequest, lg.ExportLogsServiceResponse),
            "metrics": (mt.ExportMetricsServiceRequest, mt.ExportMetricsServiceResponse)}


def hex_ids_to_b64(node):
    """OTLP/JSON carries trace and span ids as hex; protobuf's JSON mapping expects base64 bytes."""
    if isinstance(node, dict):
        for k, v in node.items():
            if k in ("traceId", "spanId", "parentSpanId") and isinstance(v, str):
                node[k] = base64.b64encode(bytes.fromhex(v)).decode()
            else:
                hex_ids_to_b64(v)
    elif isinstance(node, list):
        for item in node:
            hex_ids_to_b64(item)


def count_records(signal: str, payload: dict) -> int:
    n = 0
    for res in payload.get(ROOT_KEY[signal], []):
        for scope in res.get("scopeSpans", []) + res.get("scopeLogs", []) + res.get("scopeMetrics", []):
            n += len(scope.get("spans", [])) + len(scope.get("logRecords", [])) + len(scope.get("metrics", []))
    return n


def encode(signal: str, payload: dict, proto) -> tuple[bytes, str]:
    if proto:
        hex_ids_to_b64(payload)
        msg = proto[signal][0]()
        proto["json_format"].ParseDict(payload, msg)
        return msg.SerializeToString(), "application/x-protobuf"
    return json.dumps(payload, separators=(",", ":")).encode("utf-8"), "application/json"


def rejected(signal: str, raw: bytes, proto) -> tuple[int, str]:
    """Reads the OTLP partial-success part of a 200 response."""
    if not raw:
        return 0, ""
    try:
        if proto and not raw.lstrip().startswith(b"{"):
            msg = proto[signal][1]()
            msg.ParseFromString(raw)
            ps = msg.partial_success
            n = getattr(ps, "rejected_spans", 0) or getattr(ps, "rejected_log_records", 0) or getattr(ps, "rejected_data_points", 0)
            return int(n), ps.error_message
        ps = as_json(raw).get("partialSuccess", {})
        n = ps.get("rejectedSpans") or ps.get("rejectedLogRecords") or ps.get("rejectedDataPoints") or 0
        return int(n), ps.get("errorMessage", "")
    except Exception:
        return 0, ""


def check(cfg: dict, proto) -> bool:
    ok = True
    endpoint = need(cfg, "ELASTIC_OTLP_ENDPOINT")
    body, ctype = encode("logs", {"resourceLogs": []}, proto)
    status, raw = http("POST", f"{endpoint}/v1/logs", {**api_key_header(cfg, "ELASTIC_OTLP_API_KEY"), "Content-Type": ctype},
                       body, timeout=20, retries=1)
    print(f"OTLP endpoint   {endpoint}/v1/logs -> {status or 'unreachable'} {'' if status == 200 else raw[:300].decode('utf-8', 'replace')}")
    ok &= status == 200
    for key, path in (("ELASTICSEARCH_URL", "/"), ("KIBANA_URL", "/api/status")):
        if not cfg.get(key):
            print(f"{key:<15} not set (needed later by verify.py / agent.py)")
            continue
        status, raw = http("GET", cfg[key].rstrip("/") + path, api_key_header(cfg), timeout=20, retries=1)
        note = "" if status == 200 else raw[:200].decode("utf-8", "replace")
        good = status == 200
        if good and key == "ELASTICSEARCH_URL":
            # the ingest host also answers 200 on "/": make sure this really is Elasticsearch, with a usable key
            status2, raw2 = http("POST", cfg[key].rstrip("/") + "/_query", api_key_header(cfg), {"query": "ROW ok = 1"},
                                 timeout=20, retries=1)
            if status2 == 404:
                good, note = False, "this is not an Elasticsearch endpoint (expected https://<project>.es.<region>.<provider>.elastic.cloud)"
            elif status2 in (401, 403):
                good, note = False, ("the API key cannot query Elasticsearch: it must be created in this project's Kibana, "
                                     "without restricted privileges. " + raw2[:160].decode("utf-8", "replace"))
            elif status2 != 200:
                good, note = False, raw2[:200].decode("utf-8", "replace")
        print(f"{key:<15} {cfg[key]} -> {status or 'unreachable'} {'ok' if good else 'PROBLEM: ' + note}")
        ok &= good
    if not ok:
        print("\nA status of 'unreachable' means this machine cannot open the connection (network allowlist, proxy, DNS).\n"
              "401/403 means the API key is wrong, belongs to another project or lacks privileges. See references/elastic-setup.md.")
    return ok


def prepare_metrics(cfg: dict) -> None:
    """Time series data streams refuse points older than index.look_back_time (2 hours by default).
    Best effort: widen it to 7 days through the metrics-otel@custom component template, before the
    metrics data stream is created by the first write."""
    es = cfg.get("ELASTICSEARCH_URL", "").rstrip("/")
    if not es:
        print("metrics: ELASTICSEARCH_URL not set, cannot widen the accepted time range. Points older than about "
              "2 hours will probably be dropped.")
        return
    auth = api_key_header(cfg)
    name = "metrics-otel@custom"
    status, raw = http("GET", f"{es}/_component_template/{name}", auth, retries=1)
    if status == 200:
        mine = "elastic-ai-demo-builder" in raw.decode("utf-8", "replace")
        print(f"metrics: component template {name} already exists ({'ours' if mine else 'not created by this skill, left untouched'}).")
        return
    body = {"template": {"settings": {"index.look_back_time": "7d"}},
            "_meta": {"created_by": "elastic-ai-demo-builder", "purpose": "accept backfilled demo metrics"}}
    status, raw = http("PUT", f"{es}/_component_template/{name}", auth, body, retries=1)
    if status == 200:
        print(f"metrics: created component template {name} (index.look_back_time=7d) so that backfilled points are accepted.")
    else:
        print(f"metrics: could not widen the accepted time range ({status}: {raw[:200].decode('utf-8', 'replace')}). "
              "Points older than about 2 hours will probably be dropped. Logs and traces are not affected.")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("out", nargs="?", help="output directory of generate.py")
    ap.add_argument("--env-file")
    ap.add_argument("--check", action="store_true", help="test connectivity and authentication only")
    ap.add_argument("--signals", default=",".join(SIGNALS))
    ap.add_argument("--encoding", choices=("auto", "protobuf", "json"), default="auto")
    ap.add_argument("--force", action="store_true", help="send again even if this dataset was already ingested")
    args = ap.parse_args()
    cfg = load_env(args.env_file)

    proto = None if args.encoding == "json" else proto_classes()
    if args.encoding == "protobuf" and not proto:
        die("protobuf encoding requested but 'opentelemetry-proto' is not installed: pip install opentelemetry-proto")
    print(f"Encoding: {'protobuf' if proto else 'json'}")

    if args.check:
        sys.exit(0 if check(cfg, proto) else 1)
    if not args.out:
        die("give the output directory of generate.py, or use --check")
    out = Path(args.out)
    marker = out / ".ingested"
    endpoint = need(cfg, "ELASTIC_OTLP_ENDPOINT")
    if marker.exists() and endpoint not in marker.read_text() and not args.force:
        print(f"Note: this dataset was sent before, to another endpoint ({marker.read_text().strip()}). Sending to {endpoint}.")
    elif marker.exists() and not args.force:
        die(f"this dataset was already sent ({marker.read_text().strip()}). Sending it again duplicates every log and span. "
            f"Run cleanup.py first, or pass --force if you know the data streams are empty.")

    auth = api_key_header(cfg, "ELASTIC_OTLP_API_KEY")
    sent: dict[str, int] = {}
    refused: dict[str, int] = {}
    started = time.time()
    for signal in [s.strip() for s in args.signals.split(",") if s.strip()]:
        if signal not in SIGNALS:
            die(f"unknown signal {signal!r}")
        path = out / "otlp" / f"{signal}.ndjson.gz"
        if not path.exists():
            die(f"missing {path}: run generate.py first")
        sent[signal] = refused[signal] = 0
        if signal == "metrics":
            prepare_metrics(cfg)
        with gzip.open(path, "rt", encoding="utf-8") as fh:
            for i, line in enumerate(fh, 1):
                payload = json.loads(line)
                n = count_records(signal, payload)
                body, ctype = encode(signal, payload, proto)
                status, raw = http("POST", f"{endpoint}/v1/{signal}",
                                   {**auth, "Content-Type": ctype, "Content-Encoding": "gzip"}, gzip.compress(body), timeout=90)
                if status != 200:
                    hint = ""
                    if status in (406, 415) and not proto:
                        hint = "\nThis endpoint refuses OTLP/JSON: pip install opentelemetry-proto, then rerun."
                    die(f"{signal} batch {i} refused with status {status or 'unreachable'}: "
                        f"{raw[:500].decode('utf-8', 'replace')}{hint}\n"
                        f"{sent[signal]} {signal} records were already accepted: run cleanup.py before retrying.")
                bad, why = rejected(signal, raw, proto)
                sent[signal] += n - bad
                refused[signal] += bad
                if bad:
                    print(f"  {signal} batch {i}: {bad} records rejected: {why[:200]}")
                if i % 10 == 0:
                    print(f"  {signal}: {sent[signal]} records sent")
        print(f"{signal}: {sent[signal]} accepted, {refused[signal]} rejected")
    marker.write_text(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {endpoint} {json.dumps(sent)}\n")
    print(f"Done in {time.time() - started:.0f} s. 'Accepted' means received by the endpoint, not yet indexed: run verify.py next.")
    if refused.get("metrics"):
        print("Note: rejected metric points are usually older than the time range the metrics data stream accepts "
              "(time series data streams refuse old timestamps). The scenario does not depend on them.")


if __name__ == "__main__":
    main()
