#!/usr/bin/env python3
"""Remove a demo from the Elastic project: data streams of the customer namespace, agent and tools.

    python3 cleanup.py out/ [--env-file demo.env]          dry run: lists what would be deleted
    python3 cleanup.py out/ [--env-file demo.env] --yes    deletes

Only data streams named logs-*-<namespace>, traces-*-<namespace> and metrics-*-<namespace> are touched, where
<namespace> is the customer slug of the scenario. The namespace 'default' is refused.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import api_key_header, as_json, die, http, load_env, need  # noqa: E402

TEMPLATE = "metrics-otel@custom"


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("out")
    ap.add_argument("--env-file")
    ap.add_argument("--yes", action="store_true", help="really delete")
    ap.add_argument("--keep-agent", action="store_true", help="delete the data only")
    args = ap.parse_args()
    cfg = load_env(args.env_file)
    out = Path(args.out)
    ns = json.loads((out / "summary.json").read_text(encoding="utf-8"))["namespace"]
    if ns in ("", "default") or "*" in ns:
        die(f"refusing to clean namespace {ns!r}")
    es, auth = need(cfg, "ELASTICSEARCH_URL"), api_key_header(cfg)

    names: list[str] = []
    for typ in ("logs", "traces", "metrics"):
        status, raw = http("GET", f"{es}/_data_stream/{typ}-*-{ns}", auth)
        if status == 200:
            names += [d["name"] for d in as_json(raw).get("data_streams", [])]
        elif status != 404:
            die(f"cannot list data streams ({status}): {raw[:300].decode('utf-8', 'replace')}")
    print(f"{len(names)} data stream(s) in namespace '{ns}':")
    for n in names:
        print(f"  {n}")
    status, raw = http("GET", f"{es}/_component_template/{TEMPLATE}", auth)
    ours = status == 200 and "elastic-ai-demo-builder" in raw.decode("utf-8", "replace")
    if ours:
        print(f"component template {TEMPLATE} (created by ingest.py)")
    has_agent = (out / "agent.json").exists() and cfg.get("KIBANA_URL") and not args.keep_agent
    if has_agent:
        print("agent and tools listed in agent.json")
    if not args.yes:
        print("\nDry run. Add --yes to delete.")
        return
    for n in names:
        status, raw = http("DELETE", f"{es}/_data_stream/{n}", auth)
        print(f"deleted {n}" if status == 200 else f"FAILED {n} ({status}): {raw[:200].decode('utf-8', 'replace')}")
    if ours:
        status, _ = http("DELETE", f"{es}/_component_template/{TEMPLATE}", auth)
        print(f"component template {TEMPLATE}: {status}")
    if has_agent:
        cmd = [sys.executable, str(Path(__file__).parent / "agent.py"), "delete", str(out)]
        subprocess.run(cmd + (["--env-file", args.env_file] if args.env_file else []), check=False)
    (out / ".ingested").unlink(missing_ok=True)
    print("Cleanup done.")


if __name__ == "__main__":
    main()
