#!/usr/bin/env python3
"""Build the summary slides as a PowerPoint file, ready to become a Google Slides deck.

    pip install python-pptx
    python3 summary_pptx.py out/            # writes out/summary-deck.pptx

Same content as summary_deck.py, as native and editable objects: text, tables, a diagram made of shapes and
connectors, a native line chart, and speaker notes carrying the expected answers and the evidence.
Uploaded to Google Drive with conversion, or opened from Drive with Google Slides, it becomes a Google Slides deck.
Arial only, 16:9 at 10 x 5.625 in (the Google Slides default page), so the conversion keeps the layout.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from summary_deck import T, edges, fmt_level, num, systems  # noqa: E402

try:
    from lxml import etree
    from pptx import Presentation
    from pptx.chart.data import CategoryChartData
    from pptx.dml.color import RGBColor
    from pptx.enum.chart import XL_CHART_TYPE, XL_MARKER_STYLE
    from pptx.enum.dml import MSO_LINE
    from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
    from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
    from pptx.util import Inches, Pt
except ImportError:
    sys.exit("ERROR: this script needs python-pptx: pip install python-pptx")

INK, MUTED, ACCENT, INCIDENT, PANEL, LINE, BG = "101C3F", "55627F", "0B64DD", "C4307A", "F1F4FA", "D5DCE9", "FFFFFF"
FILL = {"tr": ("DDF7F3", "009B90"), "lg": ("ECE8FB", "6B4FD8"), "cl": ("EEF1F6", "8792AB"), "nu": ("FFFFFF", "B9C2D4"), "hub": (PANEL, "B9C2D4")}
A = "http://schemas.openxmlformats.org/drawingml/2006/main"
C = "http://schemas.openxmlformats.org/drawingml/2006/chart"
NO_STYLE_NO_GRID = "{2D5ABB26-0587-4C30-8999-92F81FD0307C}"

G = {
    "fr": {"sub": "{day}. Données synthétiques, modélisées d’après la phase de découverte.",
           "ctx": "{name} cherche la cause d’un ralentissement sur trois couches, à la main", "ctx_plain": "Contexte client",
           "sys_ui": "{system} : l’interface et ses {n} services", "sys_dep": "Les dépendances : système central, bases et API externes",
           "client": "Client", "inferred": "Déduit", "std": "Standards OpenTelemetry", "attrs": "Attributs clés",
           "d_full": "Le trace_id relie l’interface et les services, pas le système central",
           "d_core": "Le trace_id va de l’interface jusqu’au système central",
           "d_broken": "Le trace_id s’arrête à l’interface : la corrélation passe par l’heure et les clés",
           "d_nocore": "Le trace_id relie l’interface aux services et à leurs appels",
           "green": "Traces et logs, trace_id propagé", "green_nolog": "Traces avec trace_id, logs sans",
           "purple": "Logs seuls, sans trace_id", "gray": "Vu depuis l’appelant", "dash": "Pointillé : le trace_id ne passe pas.",
           "stats": "{n} événements sur {h} heures, dans {s} data streams",
           "day_apdex": "{k} incidents font passer l’Apdex de {b} à {o} sur la période",
           "day_none": "{k} incidents portent le temps de réponse moyen de {b} à {o}",
           "win": "Fenêtre", "sc": "Scénario", "all": "tous les écrans", "others": "Les autres questions de la démonstration",
           "expected": "Réponses attendues", "path": "Parcours d’investigation actuel",
           "short": {"traces": "Traces", "app": "Logs applicatifs", "sap.icm": "Journal HTTP", "sap.st03": "Charge par type de tâche",
                     "sap.jobs": "Jobs", "sap.workprocess": "Work process", "sap.syslog": "Alertes techniques", "metrics": "CPU et mémoire"}},
    "en": {"sub": "{day}. Synthetic data, modelled on discovery.",
           "ctx": "{name} tracks the cause of a slowdown across three layers, by hand", "ctx_plain": "Customer context",
           "sys_ui": "{system}: the user interface and its {n} services", "sys_dep": "Dependencies: core system, databases and external APIs",
           "client": "Customer", "inferred": "Inferred", "std": "OpenTelemetry standard", "attrs": "Key attributes",
           "d_full": "The trace_id ties the UI and the services, not the core system",
           "d_core": "The trace_id runs from the UI down to the core system",
           "d_broken": "The trace_id stops at the UI: correlation relies on time and keys",
           "d_nocore": "The trace_id ties the UI to the services and their calls",
           "green": "Traces and logs, trace_id propagated", "green_nolog": "Traces with trace_id, logs without",
           "purple": "Logs only, no trace_id", "gray": "Seen from the caller", "dash": "Dashed: the trace_id does not travel.",
           "stats": "{n} events over {h} hours, in {s} data streams",
           "day_apdex": "{k} incidents take Apdex from {b} to {o} over the period",
           "day_none": "{k} incidents take average response time from {b} to {o}",
           "win": "Window", "sc": "Scenario", "all": "every screen", "others": "The other demo questions",
           "expected": "Expected answers", "path": "Current investigation path",
           "short": {"traces": "Traces", "app": "Application logs", "sap.icm": "HTTP log", "sap.st03": "Workload per task type",
                     "sap.jobs": "Jobs", "sap.workprocess": "Work processes", "sap.syslog": "Technical warnings", "metrics": "CPU and memory"}},
}


def rgb(h: str) -> RGBColor:
    return RGBColor.from_string(h)


def lines_needed(text: str, size: float, w: float) -> int:
    per = max(8, int((w - 0.2) / (0.5 * size / 72)))
    return sum(max(1, math.ceil(len(par) / per)) for par in text.split("\n"))


class Deck:
    def __init__(self) -> None:
        self.prs = Presentation()
        self.prs.slide_width, self.prs.slide_height = Inches(10), Inches(5.625)
        self.s = None

    # ---- slides
    def title_slide(self, title: str, sub: str) -> None:
        s = self.prs.slides.add_slide(self.prs.slide_layouts[0])
        s.background.fill.solid()
        s.background.fill.fore_color.rgb = rgb(INK)
        for ph, text, size, color, top, h in ((s.shapes.title, title, 34, "FFFFFF", 1.7, 1.5), (s.placeholders[1], sub, 16, "C9D3E8", 3.3, 0.9)):
            ph.left, ph.top, ph.width, ph.height = Inches(0.6), Inches(top), Inches(8.8), Inches(h)
            tf = ph.text_frame
            tf.word_wrap = True
            tf.text = text
            p = tf.paragraphs[0]
            p.alignment = PP_ALIGN.LEFT
            self._font(p.runs[0], size, size > 20, color)
        self.s = s

    def slide(self, title: str) -> None:
        s = self.prs.slides.add_slide(self.prs.slide_layouts[5])
        s.background.fill.solid()
        s.background.fill.fore_color.rgb = rgb(BG)
        ph = s.shapes.title
        ph.left, ph.top, ph.width, ph.height = Inches(0.5), Inches(0.3), Inches(9), Inches(0.95)
        tf = ph.text_frame
        tf.word_wrap = True
        tf.vertical_anchor = MSO_ANCHOR.TOP
        tf.text = title
        tf.paragraphs[0].alignment = PP_ALIGN.LEFT
        self._font(tf.paragraphs[0].runs[0], 26, True, INK)
        self.s = s

    @staticmethod
    def _flat(shape) -> None:
        """Drop the theme style reference: no shadow, no theme effects, only the explicit fill and line."""
        style = shape._element.find("{http://schemas.openxmlformats.org/presentationml/2006/main}style")
        if style is not None:
            shape._element.remove(style)

    @staticmethod
    def _font(run, size, bold=False, color=INK) -> None:
        run.font.name = "Arial"
        run.font.size = Pt(size)
        run.font.bold = bool(bold)
        run.font.color.rgb = rgb(color)

    # ---- elements
    def text(self, x, y, w, h, paras, size=14, color=INK, bullets=False, space=6):
        """paras: list of strings, or (string, bold) tuples."""
        tb = self.s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = tb.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = Inches(0.03)
        for i, par in enumerate(paras):
            text, bold = par if isinstance(par, tuple) else (par, False)
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.alignment = PP_ALIGN.LEFT
            p.space_after = Pt(space)
            r = p.add_run()
            r.text = text
            self._font(r, size, bold, color)
            if bullets:
                pPr = p._p.get_or_add_pPr()
                pPr.set("marL", str(int(Inches(0.22))))
                pPr.set("indent", str(-int(Inches(0.22))))
                bu = etree.SubElement(pPr, f"{{{A}}}buChar")
                bu.set("char", "•")
        return tb

    def card(self, x, y, w, h, title, sub="", klass="hub", size=12, align=PP_ALIGN.CENTER, sub_size=None):
        fill, stroke = FILL[klass]
        sh = self.s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
        sh.adjustments[0] = min(0.5, 0.07 / min(w, h))
        sh.fill.solid()
        sh.fill.fore_color.rgb = rgb(fill)
        sh.line.color.rgb = rgb(stroke)
        sh.line.width = Pt(0.75)
        self._flat(sh)
        tf = sh.text_frame
        tf.word_wrap = True
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        tf.margin_left = tf.margin_right = Inches(0.1)
        tf.margin_top = tf.margin_bottom = Inches(0.04)
        p = tf.paragraphs[0]
        p.alignment = align
        r = p.add_run()
        r.text = title
        self._font(r, size, bool(sub), INK)
        if sub:
            p2 = tf.add_paragraph()
            p2.alignment = align
            r2 = p2.add_run()
            r2.text = sub
            self._font(r2, sub_size or max(10, size - 1), False, MUTED)
        return sh

    def arrow(self, x1, y1, x2, y2, dashed=False) -> None:
        cn = self.s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
        self._flat(cn)
        cn.line.color.rgb = rgb(MUTED)
        cn.line.width = Pt(1)
        if dashed:
            cn.line.dash_style = MSO_LINE.DASH
        ln = cn.line._get_or_add_ln()
        tail = etree.SubElement(ln, f"{{{A}}}tailEnd")
        tail.set("type", "triangle")
        tail.set("w", "med")
        tail.set("len", "med")

    def table(self, x, y, rows, widths, size=14, right=()) -> None:
        gf = self.s.shapes.add_table(len(rows), len(widths), Inches(x), Inches(y), Inches(sum(widths)), Inches(0.36 * len(rows)))
        tbl = gf.table
        tbl._tbl.tblPr.find(f"{{{A}}}tableStyleId").text = NO_STYLE_NO_GRID
        tbl.first_row, tbl.horz_banding = True, False
        for i, w in enumerate(widths):
            tbl.columns[i].width = Inches(w)
        for r, row in enumerate(rows):
            for c, val in enumerate(row):
                cell = tbl.cell(r, c)
                cell.margin_left, cell.margin_right = Inches(0.06), Inches(0.1)
                cell.margin_top = cell.margin_bottom = Inches(0.05)
                tf = cell.text_frame
                tf.word_wrap = True
                p = tf.paragraphs[0]
                p.alignment = PP_ALIGN.RIGHT if c in right else PP_ALIGN.LEFT
                run = p.add_run()
                run.text = str(val)
                self._font(run, size, r == 0 or c == 0, MUTED if r == 0 else INK)
                tcPr = cell._tc.get_or_add_tcPr()
                lnb = etree.SubElement(tcPr, f"{{{A}}}lnB")
                lnb.set("w", "9525")
                fill = etree.SubElement(etree.SubElement(lnb, f"{{{A}}}solidFill"), f"{{{A}}}srgbClr")
                fill.set("val", LINE)

    def notes(self, text: str) -> None:
        self.s.notes_slide.notes_text_frame.text = text


def build(out: Path) -> Presentation:
    scn = json.loads((out / "scenario.json").read_text(encoding="utf-8"))
    summary = json.loads((out / "summary.json").read_text(encoding="utf-8"))
    truth = json.loads((out / "ground_truth.json").read_text(encoding="utf-8"))
    qpath = out / "questions.json"
    questions = json.loads(qpath.read_text(encoding="utf-8"))["conversations"] if qpath.exists() else []
    from agent import resolve
    c = scn["customer"]
    lang = c.get("language", "fr") if c.get("language", "fr") in T else "en"
    t, g = T[lang], G[lang]
    colon = " : " if lang == "fr" else ": "
    system = c.get("system", c["name"])
    dec = lambda v: str(v).replace(".", "," if lang == "fr" else ".")       # noqa: E731
    d = Deck()

    ws, we = datetime.fromisoformat(truth["window"]["start"]), datetime.fromisoformat(truth["window"]["end"])
    hours = round((we - ws).total_seconds() / 3600)
    day = resolve("{date}", truth, lang) if hours == 24 and truth["window"]["start"][11:16] == "00:00" else \
        f"{truth['window']['start'][:16].replace('T', ' ')} → {truth['window']['end'][:16].replace('T', ' ')}"
    d.title_slide(f"{c['name']}, {system}{colon}{t['deck'].lower()}", g["sub"].format(day=day))

    # ---- context: what they told us, and the path they walk today
    ctx = c.get("context") or []
    ctx = [ctx] if isinstance(ctx, str) else ctx
    path = c.get("investigation_path") or (truth["incidents"][0]["investigation_layers"] if truth["incidents"] else [])
    d.slide(g["ctx"].format(name=c["name"]) if ctx and len(path) == 3 else g["ctx_plain"])
    d.text(0.5, 1.35, 5.2, 3.8, ctx or [t["context_missing"]], 14, bullets=True, space=9)
    a = truth.get("apdex")
    dim = scn.get("business_dimension")
    d.text(6.1, 1.35, 3.4, 0.3, [(g["path"], True)], 12, MUTED)
    y = 1.7
    for i, step in enumerate(path[:4]):
        d.card(6.1, y, 3.4, 0.62, step, klass="hub", size=12, align=PP_ALIGN.LEFT)
        if i < len(path[:4]) - 1:
            d.arrow(7.8, y + 0.62, 7.8, y + 0.8)
        y += 0.8
    kpi = (f"Apdex {a['satisfied_ms'] / 1000:g} s / {a['frustrated_ms'] / 1000:g} s, {t['target']} {dec(a['target'])}" if a else t["no_kpi"])
    facts = [f"{t['kpi']}{colon}{kpi}"] + ([f"{t['dimension']}{colon}{dim.get('label', dim['attribute'])} ({len(dim['values'])})"] if dim else [])
    d.text(6.1, min(y + 0.1, 4.45), 3.4, 0.8, facts, 12, MUTED, space=3)

    # ---- systems and attributes
    sysl = systems(scn)

    def sys_rows(items):
        rows = [[t["system"], t["role"], t["tech"], g["attrs"]]]
        for s in items:
            cu = [k for k, src in s["attrs"].items() if src == "customer"]
            inf = [k for k, src in s["attrs"].items() if src != "customer"]
            parts = ([f"{g['client']}{colon}{', '.join(cu)}"] if cu else []) + ([f"{g['inferred']}{colon}{', '.join(inf)}"] if inf else [])
            rows.append([s["id"], t["roles"][s["role"]], s["tech"], ". ".join(parts) or g["std"]])
        return rows
    apps = [s for s in sysl if s["role"] in ("ui", "service")]
    deps = [s for s in sysl if s["role"] not in ("ui", "service")]
    for group, title in ((apps, g["sys_ui"].format(system=system, n=len(apps) - 1)), (deps, g["sys_dep"])):
        for start in range(0, len(group), 5):
            d.slide(title)
            d.table(0.5, 1.4, sys_rows(group[start:start + 5]), [2.45, 1.45, 2.45, 2.65], size=12)

    # ---- diagram
    co = summary.get("correlation") or {}
    f2s, logs, core = co.get("trace_frontend_to_services", True), co.get("trace_in_service_logs", True), co.get("trace_in_core_system_logs", False)
    has_core = any(s["role"] == "core" for s in sysl)
    d.slide(g["d_broken"] if not f2s else g["d_core"] if core and has_core else g["d_full"] if has_core else g["d_nocore"])
    services = [s for s in sysl if s["role"] == "service"][:6]
    e1, e2 = edges(scn)
    order = {s["id"]: i for i, s in enumerate(services)}
    deps_d = sorted(deps, key=lambda x: sum(order.get(p, 0) for p, q in e2 if q == x["id"]) / max(1, sum(1 for p, q in e2 if q == x["id"])))[:6]
    bh, pos = 0.56, {}

    def place(items, y, maxw):
        if not items:
            return
        w = min(maxw, (9.0 - 0.18 * (len(items) - 1)) / len(items))
        x = 5 - (w * len(items) + 0.18 * (len(items) - 1)) / 2
        for it in items:
            pos[it["id"]] = (x, y, w)
            x += w + 0.18
    ys = [1.3, 2.06, 2.86, 3.68, 4.42]
    front = sysl[0]
    pos["__u"], pos[front["id"]] = (3.6, ys[0], 2.8), (3.1, ys[1], 3.8)
    place(services, ys[2], 2.6)
    place(deps_d, ys[3], 3.0)
    lab = 10 if len(services) > 3 else 11
    ucount = f"{len(dim['values'])} × {dim.get('label', dim['attribute'])}, " if dim else ""
    d.card(*pos["__u"], bh, t["users"], f"{ucount}{len(scn['screens'])} {t['screens']}", "nu", 11)
    d.card(*pos[front["id"]], bh, front["id"], front["tech"], "tr", 11)
    for s in services:
        d.card(*pos[s["id"]], bh, s["id"], s["tech"], "tr", lab, sub_size=9 if len(s["tech"]) > 28 else None)
    cls = {"core": "tr" if core else "lg", "db": "cl", "ext": "cl"}
    for s in deps_d:
        d.card(*pos[s["id"]], bh, s["id"], s["tech"] or t["roles"][s["role"]], cls[s["role"]], 11)
    d.card(0.5, ys[4], 9.0, 0.4, f"{t['hub']}{colon}{t['hub_sub'].format(ns=summary['namespace'], n=num(summary['total_events'], lang))}", "", "hub", 11)
    d.arrow(5, ys[0] + bh, 5, ys[1] - 0.02)

    def fan(pairs, dashed):
        outs, ins = {}, {}
        for p, q in pairs:
            if p in pos and q in pos:
                outs.setdefault(p, []).append(q)
                ins.setdefault(q, []).append(p)
        for v in list(outs.values()) + list(ins.values()):
            v.sort(key=lambda k: pos[k][0])
        for p, qs in outs.items():
            for q in qs:
                (ax, ay, aw), (bx, by, bw) = pos[p], pos[q]
                i, n, j, m = qs.index(q), len(qs), ins[q].index(p), len(ins[q])
                d.arrow(ax + aw * (0.5 if n == 1 else 0.25 + 0.5 * i / (n - 1)), ay + bh,
                        bx + bw * (0.5 if m == 1 else 0.25 + 0.5 * j / (m - 1)), by - 0.02, dashed)
    fan(e1, not f2s)
    fan(e2, False)
    legend = [("tr", g["green"] if logs else g["green_nolog"])]
    if has_core and not core:
        legend.append(("lg", g["purple"]))
    if any(s["role"] in ("db", "ext") for s in sysl):
        legend.append(("cl", g["gray"]))
    x = 0.5
    for klass, label in legend:
        sw = d.s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(4.99), Inches(0.14), Inches(0.14))
        sw.fill.solid()
        sw.fill.fore_color.rgb = rgb(FILL[klass][0])
        sw.line.color.rgb = rgb(FILL[klass][1])
        d._flat(sw)
        d.text(x + 0.2, 4.93, 2.6, 0.26, [label], 10, MUTED)
        x += 0.35 + len(label) * 0.068
    extra = [g["dash"]] if not f2s else []
    keys = co.get("propagated_keys", [])
    if keys:
        names = {"services": t["to_services"], "core": t["to_core"]}
        extra.append(t["keys"] + colon + ", ".join(
            f"{k['attribute']} → {' + '.join(names[r] for r in ('services', 'core') if r in k['reaches'])}" for k in keys) + ".")
    if extra:
        d.text(0.5, 5.18, 9, 0.26, [" ".join(extra)], 10, MUTED)

    # ---- statistics
    d.slide(g["stats"].format(n=num(summary["total_events"], lang), h=hours, s=len(summary["events_by_data_stream"])))
    stats = [(num(summary["total_events"], lang), t["events"]), (num(summary["user_requests"], lang), t["requests"]),
             (str(len({i.get("group") or i["id"] for i in truth["incidents"]})), "scénarios de panne" if lang == "fr" else "fault scenarios")]
    for i, (big, label) in enumerate(stats):
        d.text(0.5, 1.4 + i * 1.2, 2.6, 0.62, [(big, True)], 34, ACCENT)
        d.text(0.5, 1.98 + i * 1.2, 2.6, 0.3, [label], 12, MUTED)

    def kind(stream):
        typ, rest = stream.split("-", 1)
        ds = rest.rsplit(".otel-", 1)[0]
        return g["short"].get(typ) or g["short"].get(ds) or (g["short"]["app"] if ds.endswith(".app") else ds)
    rows = [[t["stream"], t["content"], t["count"]]] + [[k, kind(k), num(v, lang)] for k, v in summary["events_by_data_stream"].items()]
    d.table(3.3, 1.4, rows[:10], [3.1, 1.95, 1.15], size=11, right=(2,))

    # ---- the period: native chart and incident list
    rt = truth["response_time"]
    lvl = lambda o: fmt_level(o, summary, lang).replace(t["apdex"] + " ", "").replace(t["avg"] + " ", "")      # noqa: E731
    groups: dict[str, list] = {}
    for inc in truth["incidents"]:
        groups.setdefault(inc.get("group") or inc["id"], []).append(inc)
    b, o = ({"apdex": a["baseline"]}, {"apdex": a["overall"]}) if a else ({"avg_ms": rt["baseline"]["avg_ms"]}, {"avg_ms": rt["overall"]["avg_ms"]})
    d.slide((g["day_apdex"] if a else g["day_none"]).format(k=len(groups), b=lvl(b), o=lvl(o)))
    pts = summary["timeline_15min"]
    busy = max(p["requests"] for p in pts)
    data = CategoryChartData()
    # a label every three hours only: blank categories keep the axis readable in every renderer
    data.categories = [p["t"][11:16] if p["t"][14:16] == "00" and int(p["t"][11:13]) % 3 == 0 else "" for p in pts]
    data.add_series(t["apdex"] if a else t["avg"],
                    [((p["apdex"] if a else p["avg_ms"] / 1000) if p["requests"] >= max(10, 0.03 * busy) else None) for p in pts])
    gf = d.s.shapes.add_chart(XL_CHART_TYPE.LINE, Inches(0.4), Inches(1.35), Inches(5.5), Inches(3.6), data)
    ch = gf.chart
    ch.has_legend, ch.has_title = False, False
    ch.font.size, ch.font.name = Pt(10), "Arial"
    ch.font.color.rgb = rgb(MUTED)
    ser = ch.plots[0].series[0]
    ser.smooth = False
    ser.format.line.color.rgb = rgb(ACCENT)
    ser.format.line.width = Pt(2)
    ser.marker.style = XL_MARKER_STYLE.NONE
    va = ch.value_axis
    va.has_major_gridlines = True
    va.major_gridlines.format.line.color.rgb = rgb(LINE)
    va.format.line.fill.background()
    va.tick_labels.number_format, va.tick_labels.number_format_is_linked = ("0.00" if a else '0.0" s"'), False
    if a:
        known = [p["apdex"] for p in pts if p["apdex"] is not None and p["requests"] >= max(10, 0.03 * busy)]
        va.minimum_scale, va.maximum_scale = math.floor(min(known + [0.6]) * 10) / 10, 1.0
    ca = ch.category_axis
    ca.format.line.color.rgb = rgb(LINE)
    cat = ca._element
    for tag in ("tickLblSkip", "tickMarkSkip"):
        el = etree.Element(f"{{{C}}}{tag}")
        el.set("val", "1")
        anchor = cat.find(f"{{{C}}}noMultiLvlLbl")
        (anchor.addprevious(el) if anchor is not None else cat.append(el))
    nscreens = len(scn["screens"])
    worst = (lambda incs: min(incs, key=lambda i: i["apdex"])) if a else (lambda incs: max(incs, key=lambda i: i["avg_ms"]))
    rows = [[g["win"], g["sc"], t["apdex"] if a else "s"]]
    for incs in list(groups.values())[:6]:
        rows.append([f"{min(i['start_local'] for i in incs)} – {max(i['end_local'] for i in incs)}",
                     " + ".join(dict.fromkeys(t["types"].get(i["type"], i["type"]) for i in incs)),
                     lvl(worst(incs)).replace(" s", "")])
    d.table(6.05, 1.4, rows, [1.05, 1.85, 0.6], size=10, right=(2,))

    # ---- one slide per fault scenario
    used = set()
    for gid, incs in groups.items():
        ids = {i["id"] for i in incs}
        convs = [q for q in questions if ids & set(q.get("incidents", []))]
        used.update(q["id"] for q in convs)
        window = f"{min(i['start_local'] for i in incs)} – {max(i['end_local'] for i in incs)}"
        title = " + ".join(dict.fromkeys(t["types"].get(i["type"], i["type"]) for i in incs))
        low = title[0].lower() + title[1:] if len(title) > 1 and title[1].islower() else title
        d.slide(f"{window}{colon}{low}")
        sc_hit = sorted({s for i in incs for s in i["impacted_screens"]})
        hit = g["all"] if len(sc_hit) == nscreens else ", ".join(sc_hit)
        d.text(0.5, 1.3, 9, 0.32, [(f"{fmt_level(worst(incs), summary, lang)}. {t['screens_hit']}{colon}{hit}.", True)], 13, INCIDENT)
        clean = lambda s: s.split(" Attention : ")[0].split(" Note: ")[0]       # noqa: E731
        left = [(t["cause"], True)] + [clean(i["root_cause"]) for i in incs]
        fixes = [i["remediation"] for i in incs]
        if lines_needed("\n".join(x if isinstance(x, str) else x[0] for x in left) + "\n" + "\n".join(fixes), 12, 4.3) <= 15:
            left += [(t["remedy"], True)] + fixes
        d.text(0.5, 1.75, 4.3, 3.6, left, 12, space=5)
        turns = [tn for q in convs for tn in q["turns"][:2 if len(convs) > 1 else 3]][:4]
        d.text(5.1, 1.75, 4.4, 0.3, [(t["asked"], True)], 12)
        y = 2.08
        for tn in turns:
            prompt = resolve(tn["prompt"], truth, lang)
            h = 0.2 + 0.19 * lines_needed(prompt, 11, 4.2)
            if y + h > 5.33:
                break
            d.card(5.1, y, 4.4, h, prompt, klass="hub", size=11, align=PP_ALIGN.LEFT)
            y += h + 0.08
        proofs = [f"{'traces' if ev['stream'].startswith('traces-') else ev['stream'].split('-', 1)[1].rsplit('.otel-', 1)[0]}{colon}{ev['fact']}"
                  for k in range(5) for i in incs for ev in i["evidence"][k:k + 1]]      # one per incident first
        shown = []
        for pr in proofs[:3]:                                   # evidence on the slide when room is left under the questions
            if y + 0.45 + 0.17 * lines_needed("\n".join(shown + [pr]), 11, 4.2) + 0.08 * (len(shown) + 1) > 5.35:
                break
            shown.append(pr)
        if shown:
            d.text(5.1, y + 0.1, 4.4, 0.3, [(t["proof"], True)], 12)
            d.text(5.1, y + 0.42, 4.4, 5.35 - y - 0.42, shown, 11, bullets=True, space=4)
        notes = []
        exp = [f"- {resolve(tn['expected'], truth, lang)}" for q in convs for tn in q["turns"] if tn.get("expected")]
        if exp:
            notes += [g["expected"] + colon.rstrip()] + exp + [""]
        notes += [t["proof"] + colon.rstrip()] + [f"- {pr}" for pr in proofs]
        d.notes("\n".join(notes))

    # ---- remaining questions
    rest = [tn for q in questions if q["id"] not in used for tn in q["turns"]]
    for start in range(0, len(rest), 6):
        d.slide(g["others"])
        chunk = rest[start:start + 6]
        for i, tn in enumerate(chunk):
            d.card(0.5 + (i % 2) * 4.6, 1.4 + (i // 2) * 1.25, 4.4, 1.1, resolve(tn["prompt"], truth, lang), klass="hub", size=12, align=PP_ALIGN.LEFT)
        exp = [f"- {resolve(tn['expected'], truth, lang)}" for tn in chunk if tn.get("expected")]
        if exp:
            d.notes("\n".join([g["expected"] + colon.rstrip()] + exp))
    return d.prs


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("out")
    args = ap.parse_args()
    if json.loads((Path(args.out) / "summary.json").read_text(encoding="utf-8")).get("model") == "deal_flow":
        import deal_summary
        print("Wrote", deal_summary.build_pptx(Path(args.out)))
        return
    out = Path(args.out)
    if not (out / "summary.json").exists():
        sys.exit(f"ERROR: {out} is not an output directory of generate.py")
    prs = build(out)
    dest = out / "summary-deck.pptx"
    prs.save(dest)
    print(f"Wrote {dest} ({len(prs.slides)} slides, {dest.stat().st_size / 1000:.0f} kB)")


if __name__ == "__main__":
    main()
