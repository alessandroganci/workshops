#!/usr/bin/env python3
"""Build the summary slides of a generated demo, and the ecosystem diagram.

    python3 summary_deck.py out/

Reads out/scenario.json, out/summary.json, out/ground_truth.json and, when present, out/questions.json.
Writes out/summary-deck.html (self-contained, arrow keys to navigate, prints one slide per page)
and    out/diagram.svg       (the ecosystem diagram alone).

Slides: customer context, systems and their attributes, ecosystem diagram, dataset statistics, the day,
one slide per fault scenario with the questions asked, then the remaining questions.
Standard library only.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from html import escape as e
from pathlib import Path

W, H = 1280, 720

T = {
    "fr": {
        "deck": "Jeu de données de démonstration", "synthetic": "Données synthétiques, modélisées d’après la phase de découverte. Aucune donnée réelle.",
        "context": "Contexte client", "context_missing": "Contexte à compléter dans customer.context du scénario.",
        "sector": "Secteur", "system": "Système", "kpi": "Indicateur", "no_kpi": "Aucun indicateur formalisé : temps de réponse et taux d’erreur",
        "dimension": "Axe métier", "path": "Parcours d’investigation", "systems": "Systèmes et attributs",
        "role": "Rôle", "tech": "Technologie", "attrs": "Attributs clés dans ses messages", "std": "Attributs standards OpenTelemetry",
        "src_customer": "donné par le client", "src_literature": "déduit de systèmes comparables", "src_unspecified": "origine non précisée",
        "roles": {"ui": "Interface utilisateur", "service": "Service", "core": "Système central", "db": "Base de données", "ext": "API externe"},
        "diagram": "Écosystème et corrélation", "users": "Utilisateurs", "screens": "écrans", "hub": "Elasticsearch", "hub_sub": "Hub OpenTelemetry, namespace {ns}, {n} événements",
        "lg_traced": "Traces et logs, trace_id propagé", "lg_traced_nolog": "Traces avec trace_id, logs sans", "lg_logs": "Logs seuls, sans trace_id",
        "lg_logs_trace": "Logs avec trace_id", "lg_caller": "Vu depuis l’appelant", "lg_broken": "Trait pointillé : le trace_id ne passe pas",
        "keys": "Clés métier propagées", "to_services": "services", "to_core": "système central", "none": "aucune",
        "stats": "Statistiques du jeu de données", "events": "événements", "requests": "requêtes utilisateur", "hours": "heures couvertes",
        "streams": "data streams", "stream": "Data stream", "content": "Contenu", "count": "Événements",
        "day": "La période et ses incidents", "baseline": "Niveau normal", "overall": "Sur la période", "target": "objectif",
        "apdex": "Apdex", "avg": "temps de réponse moyen", "scenario": "Scénario de panne", "window": "Fenêtre", "seen": "Ce que voient les utilisateurs",
        "cause": "Cause racine", "proof": "Preuves dans les données", "asked": "Questions posées à l’agent", "expected": "Attendu",
        "no_questions": "Aucune question n’est encore rattachée à ce scénario.", "other": "Autres questions de la démonstration",
        "screens_hit": "Écrans touchés", "level": "Niveau pendant l’incident", "remedy": "Remédiation",
        "kinds": {"traces": "Traces : requêtes de l’interface, des services et de leurs appels", "app": "Logs applicatifs des services",
                  "sap.icm": "Journal HTTP du système central", "sap.st03": "Statistiques de charge par type de tâche",
                  "sap.jobs": "Démarrages et fins de jobs", "sap.workprocess": "Occupation des work process",
                  "sap.syslog": "Alertes techniques", "metrics": "CPU et mémoire des hôtes"},
        "types": {"sap_batch_contention": "Job qui sature le système central", "external_slow": "API externe dégradée",
                  "database_slow": "Base de données lente", "deploy_regression": "Régression après déploiement",
                  "sap_http_slow": "Couche HTTP du système central saturée", "error_burst": "Rafale d’erreurs"},
    },
    "en": {
        "deck": "Demo dataset", "synthetic": "Synthetic data, modelled on discovery. No real data.",
        "context": "Customer context", "context_missing": "Context to be written in customer.context of the scenario.",
        "sector": "Sector", "system": "System", "kpi": "Indicator", "no_kpi": "No formal indicator: response time and error rate",
        "dimension": "Business axis", "path": "Investigation path", "systems": "Systems and attributes",
        "role": "Role", "tech": "Technology", "attrs": "Key attributes in its messages", "std": "Standard OpenTelemetry attributes",
        "src_customer": "given by the customer", "src_literature": "inferred from comparable systems", "src_unspecified": "origin not stated",
        "roles": {"ui": "User interface", "service": "Service", "core": "Core system", "db": "Database", "ext": "External API"},
        "diagram": "Ecosystem and correlation", "users": "Users", "screens": "screens", "hub": "Elasticsearch", "hub_sub": "OpenTelemetry hub, namespace {ns}, {n} events",
        "lg_traced": "Traces and logs, trace_id propagated", "lg_traced_nolog": "Traces with trace_id, logs without", "lg_logs": "Logs only, no trace_id",
        "lg_logs_trace": "Logs with trace_id", "lg_caller": "Seen from the caller", "lg_broken": "Dashed line: the trace_id does not travel",
        "keys": "Propagated business keys", "to_services": "services", "to_core": "core system", "none": "none",
        "stats": "Dataset statistics", "events": "events", "requests": "user requests", "hours": "hours covered",
        "streams": "data streams", "stream": "Data stream", "content": "Content", "count": "Events",
        "day": "The period and its incidents", "baseline": "Normal level", "overall": "Over the period", "target": "target",
        "apdex": "Apdex", "avg": "average response time", "scenario": "Fault scenario", "window": "Window", "seen": "What users see",
        "cause": "Root cause", "proof": "Evidence in the data", "asked": "Questions asked to the agent", "expected": "Expected",
        "no_questions": "No question is attached to this scenario yet.", "other": "Other demo questions",
        "screens_hit": "Affected screens", "level": "Level during the incident", "remedy": "Remediation",
        "kinds": {"traces": "Traces: requests of the UI, the services and their calls", "app": "Service application logs",
                  "sap.icm": "Core system HTTP log", "sap.st03": "Workload statistics per task type",
                  "sap.jobs": "Job starts and ends", "sap.workprocess": "Work process occupation",
                  "sap.syslog": "Technical warnings", "metrics": "Host CPU and memory"},
        "types": {"sap_batch_contention": "Job saturating the core system", "external_slow": "Degraded external API",
                  "database_slow": "Slow database", "deploy_regression": "Regression after deployment",
                  "sap_http_slow": "Core system HTTP layer saturated", "error_burst": "Error burst"},
    },
}

CSS = """
:root{color-scheme:light;--bg:#FFFFFF;--panel:#F4F6FB;--ink:#101C3F;--muted:#55627F;--line:#D5DCE9;--accent:#0B64DD;
--incident:#C4307A;--incident-bg:#FCE4F0;--ok:#00857B;
--tb:#DDF7F3;--ts:#009B90;--tt:#0A4D48;--lb:#ECE8FB;--ls:#6B4FD8;--lt:#33247A;--cb:#EEF1F6;--cs:#8792AB;--ct:#2B3654}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){color-scheme:dark;--bg:#0B1628;--panel:#132238;--ink:#E8EEF9;
--muted:#9AA8C3;--line:#2A3A57;--accent:#6FAAFF;--incident:#F78BBB;--incident-bg:#4A1F37;--ok:#48EFCF;
--tb:#0F3B3A;--ts:#48EFCF;--tt:#C9FBF2;--lb:#2A2356;--ls:#A998F5;--lt:#E4DEFF;--cb:#1B2740;--cs:#7C8BAA;--ct:#D5DDEE}}
:root[data-theme="dark"]{color-scheme:dark;--bg:#0B1628;--panel:#132238;--ink:#E8EEF9;--muted:#9AA8C3;--line:#2A3A57;--accent:#6FAAFF;
--incident:#F78BBB;--incident-bg:#4A1F37;--ok:#48EFCF;--tb:#0F3B3A;--ts:#48EFCF;--tt:#C9FBF2;--lb:#2A2356;--ls:#A998F5;--lt:#E4DEFF;
--cb:#1B2740;--cs:#7C8BAA;--ct:#D5DDEE}
*{box-sizing:border-box}html,body{height:100%;margin:0}
:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}
body{background:var(--bg);color:var(--ink);font-family:Inter,"Segoe UI","Helvetica Neue",Arial,sans-serif;overflow:hidden}
.stage{position:relative;width:100%;height:100%}
.slide{position:absolute;left:50%;top:50%;width:1280px;height:720px;padding:56px 72px 64px;display:none;flex-direction:column;
transform-origin:center;background:var(--bg)}
.slide.on{display:flex}
h1{font-size:54px;line-height:1.08;font-weight:650;letter-spacing:-.02em;margin:0 0 20px;max-width:18ch}
h2{font-size:30px;line-height:1.15;font-weight:650;letter-spacing:-.01em;margin:0 0 26px}
h3{font-size:15px;font-weight:600;color:var(--muted);margin:0 0 8px}
p,li,td,th{font-size:17px;line-height:1.45}
.lead{font-size:22px;color:var(--muted);max-width:46ch;margin:0}
.note{font-size:14px;color:var(--muted)}
.cols{display:grid;grid-template-columns:1.25fr 1fr;gap:48px;flex:1;min-height:0}
ul{margin:0;padding-left:20px}li{margin-bottom:10px}
dl{margin:0;display:grid;grid-template-columns:150px 1fr;row-gap:14px;column-gap:16px}
dt{font-size:14px;color:var(--muted);padding-top:3px}dd{margin:0;font-size:17px;line-height:1.4}
table{border-collapse:collapse;width:100%}th{text-align:left;font-size:13px;font-weight:600;color:var(--muted);padding:0 12px 8px 0;border-bottom:1px solid var(--line)}
td{padding:9px 12px 9px 0;border-bottom:1px solid var(--line);vertical-align:top;font-size:15px}
td.num,th.num{text-align:right;font-variant-numeric:tabular-nums;padding-right:0}
code,.f{font-family:"SF Mono","Cascadia Code",Consolas,monospace;font-size:.88em}
.chip{display:inline-block;margin:0 6px 5px 0;padding:2px 8px;border-radius:4px;background:var(--panel);font-family:"SF Mono","Cascadia Code",Consolas,monospace;font-size:13px;white-space:nowrap}
.chip.c{box-shadow:inset 3px 0 0 var(--accent)}.chip.l{box-shadow:inset 3px 0 0 var(--cs)}
.key{display:flex;gap:22px;font-size:13px;color:var(--muted);margin-top:14px}.key i{display:inline-block;width:10px;height:10px;margin-right:6px;vertical-align:-1px}
.big{display:grid;grid-template-columns:repeat(4,1fr);gap:28px;margin-bottom:26px}
.big b{display:block;font-size:44px;font-weight:650;letter-spacing:-.02em;font-variant-numeric:tabular-nums}.big span{font-size:14px;color:var(--muted)}
.q{border-left:3px solid var(--accent);padding:2px 0 2px 16px;margin-bottom:14px}.q p{margin:0 0 4px;font-size:16px}.q .x{font-size:14px;color:var(--muted)}
.tag{align-self:flex-start;display:inline-block;font-size:13px;font-weight:600;color:var(--incident);background:var(--incident-bg);padding:3px 10px;border-radius:4px;margin-bottom:12px}
.ribbon{position:absolute;left:72px;right:72px;bottom:26px;height:18px}
.foot{position:absolute;left:72px;bottom:6px;font-size:12px;color:var(--muted);font-variant-numeric:tabular-nums}
.fill{flex:1;min-height:0;display:flex;align-items:center;justify-content:center}.fill svg{width:100%;height:100%}
.nav{position:fixed;right:14px;bottom:calc(10px + env(safe-area-inset-bottom,0px));display:flex;gap:6px;z-index:5}
.nav button{font:inherit;font-size:14px;width:36px;height:32px;border:1px solid var(--line);background:var(--bg);color:var(--ink);border-radius:6px;cursor:pointer}
.nav button:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
svg text{font-family:Inter,"Segoe UI","Helvetica Neue",Arial,sans-serif}
@media print{@page{size:1280px 720px;margin:0}body{overflow:visible}.stage{height:auto}.nav{display:none}
.slide{display:flex!important;position:relative;left:0;top:0;transform:none!important;page-break-after:always}}
"""

JS = """
const S=[...document.querySelectorAll('.slide')];let i=0;
function fit(){const k=Math.min(innerWidth/1280,(innerHeight)/720);S.forEach(s=>s.style.transform=`translate(-50%,-50%) scale(${k})`)}
function show(n,push){i=Math.max(0,Math.min(S.length-1,n));S.forEach((s,j)=>s.classList.toggle('on',j===i));if(push)location.hash='s'+(i+1)}
function fromHash(){const m=/^#s(\\d+)$/.exec(location.hash);show(m?+m[1]-1:0,false)}
addEventListener('resize',fit);addEventListener('hashchange',fromHash);
addEventListener('keydown',ev=>{if(['ArrowRight','PageDown',' '].includes(ev.key)){show(i+1,true);ev.preventDefault()}
if(['ArrowLeft','PageUp'].includes(ev.key)){show(i-1,true);ev.preventDefault()}if(ev.key==='Home')show(0,true);if(ev.key==='End')show(S.length-1,true)});
document.getElementById('prev').onclick=()=>show(i-1,true);document.getElementById('next').onclick=()=>show(i+1,true);
fit();fromHash();
"""


# --------------------------------------------------------------------------- model
def systems(scn: dict) -> list[dict]:
    """Flat list of systems with role, technology and declared attributes."""
    front = scn.get("frontend") or scn.get("ihm")
    out = []

    def attrs(*blocks):
        seen = {}
        for b in blocks:
            for k, spec in (b.get("attributes") or {}).items():
                seen.setdefault(k, spec.get("source", "unspecified") if isinstance(spec, dict) else "unspecified")
        return seen

    out.append({"id": front["service"], "role": "ui", "tech": front.get("technology") or front.get("language", ""),
                "attrs": attrs(front, *scn["screens"])})
    for s in scn["services"]:
        eps = [x for x in scn["endpoints"] if x["service"] == s["name"]]
        out.append({"id": s["name"], "role": "service", "tech": s.get("technology") or s.get("language", ""),
                    "attrs": attrs(s, *eps)})
    if scn.get("sap"):
        out.append({"id": scn["sap"]["name"], "role": "core", "tech": scn["sap"].get("technology", "SAP"),
                    "attrs": attrs(scn["sap"])})
    for d in scn.get("databases", []):
        out.append({"id": d["name"], "role": "db", "tech": d.get("technology") or d.get("system", ""), "attrs": attrs(d)})
    for x in scn.get("externals", []):
        out.append({"id": x["name"], "role": "ext", "tech": x.get("technology", ""), "attrs": attrs(x)})
    return out


def edges(scn: dict) -> tuple[list, list]:
    front = (scn.get("frontend") or scn.get("ihm"))["service"]
    a, b = [], []
    for sc in scn["screens"]:
        for c in sc["calls"]:
            if (front, c["service"]) not in a:
                a.append((front, c["service"]))
    for ep in scn["endpoints"]:
        for c in ep.get("calls", []):
            target = scn["sap"]["name"] if "sap" in c else c.get("database") or c.get("external")
            if (ep["service"], target) not in b:
                b.append((ep["service"], target))
    return a, b


def clip(text: str, width: float, px: float) -> str:
    n = max(3, int(width / px))
    return text if len(text) <= n else text[: n - 1] + "…"


# --------------------------------------------------------------------------- diagram
def diagram(scn: dict, summary: dict, lang: str, standalone: bool = False) -> str:
    t = T[lang]
    co = summary.get("correlation") or {}
    f2s, logs, core = (co.get("trace_frontend_to_services", True), co.get("trace_in_service_logs", True),
                       co.get("trace_in_core_system_logs", False))
    sysl = systems(scn)
    front = sysl[0]
    services = [s for s in sysl if s["role"] == "service"]
    deps = [s for s in sysl if s["role"] in ("core", "db", "ext")]
    e1, e2 = edges(scn)
    width, margin, gap, bh = 1200, 40, 20, 62

    def row(items, y, maxw=262):
        if not items:
            return {}
        per = min(len(items), 6)
        lines = [items[i:i + per] for i in range(0, len(items), per)]
        pos = {}
        for li, line in enumerate(lines):
            w = min(maxw, (width - 2 * margin - gap * (len(line) - 1)) / len(line))
            total = w * len(line) + gap * (len(line) - 1)
            x = (width - total) / 2
            for it in line:
                pos[it["id"]] = (x, y + li * (bh + 22), w)
                x += w + gap
        return pos

    y_users, y_front = 16, 112
    y_serv = 222
    pos = {"__users": (width / 2 - 150, y_users, 300), front["id"]: (width / 2 - 190, y_front, 380)}
    pos.update(row(services, y_serv))
    serv_rows = (len(services) - 1) // 6 + 1
    y_deps = y_serv + serv_rows * (bh + 22) + 28
    order = {s["id"]: i for i, s in enumerate(services)}
    deps.sort(key=lambda d: sum(order[a] for a, b in e2 if b == d["id"]) / max(1, sum(1 for a, b in e2 if b == d["id"])))
    pos.update(row(deps, y_deps, 340))
    dep_rows = (len(deps) - 1) // 6 + 1 if deps else 0
    y_hub = y_deps + dep_rows * (bh + 22) + 8 if deps else y_serv + serv_rows * (bh + 22) + 8
    y_leg = y_hub + bh + 30
    keys = co.get("propagated_keys", [])
    height = y_leg + (46 if keys or not f2s else 22)

    cls = {"ui": "tr", "service": "tr", "core": "lg", "db": "cl", "ext": "cl"}
    out = [f'<svg class="eco" viewBox="0 0 {width} {int(height)}" role="img" xmlns="http://www.w3.org/2000/svg">',
           f"<title>{e(t['diagram'])}</title>"]
    if standalone:
        out.append("<style>svg.eco{--bg:#fff;--ink:#101C3F;--muted:#55627F;--line:#D5DCE9;--panel:#F4F6FB;--tb:#DDF7F3;--ts:#009B90;--tt:#0A4D48;"
                   "--lb:#ECE8FB;--ls:#6B4FD8;--lt:#33247A;--cb:#EEF1F6;--cs:#8792AB;--ct:#2B3654;background:var(--bg);"
                   "font-family:Inter,'Segoe UI',Arial,sans-serif}</style>")
    out.append("<style>.eco .tr rect{fill:var(--tb);stroke:var(--ts)}.eco .tr text{fill:var(--tt)}.eco .lg rect{fill:var(--lb);stroke:var(--ls)}"
               ".eco .lg text{fill:var(--lt)}.eco .cl rect{fill:var(--cb);stroke:var(--cs)}.eco .cl text{fill:var(--ct)}"
               ".eco .nu rect{fill:none;stroke:var(--line)}.eco .nu text{fill:var(--ink)}.eco .hub rect{fill:var(--panel);stroke:var(--line)}"
               ".eco .hub text{fill:var(--ink)}.eco .ti{font-size:16px;font-weight:600}.eco .su{font-size:13px;opacity:.85}"
               ".eco .ed{stroke:var(--muted);stroke-width:1.3;fill:none}.eco .le{font-size:13px;fill:var(--muted)}</style>")
    out.append('<defs><marker id="ah" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto">'
               '<path d="M2 1L8 5L2 9" fill="none" stroke="context-stroke" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></marker></defs>')

    def box(key, klass, title, sub):
        x, y, w = pos[key]
        out.append(f'<g class="{klass}"><rect x="{x:.0f}" y="{y:.0f}" width="{w:.0f}" height="{bh}" rx="8" stroke-width="1"/>'
                   f'<text class="ti" x="{x + w / 2:.0f}" y="{y + 25:.0f}" text-anchor="middle">{e(clip(title, w - 20, 8.3))}</text>'
                   f'<text class="su" x="{x + w / 2:.0f}" y="{y + 45:.0f}" text-anchor="middle">{e(clip(sub, w - 24, 6.9))}</text></g>')

    def fan(pairs, dashed):
        outs, ins = {}, {}
        for a, b in pairs:
            outs.setdefault(a, []).append(b)
            ins.setdefault(b, []).append(a)
        for a in outs:
            outs[a].sort(key=lambda k: pos[k][0])
        for b in ins:
            ins[b].sort(key=lambda k: pos[k][0])
        for a, b in pairs:
            ax, ay, aw = pos[a]
            bx, by, bw = pos[b]
            i, n = outs[a].index(b), len(outs[a])
            j, m = ins[b].index(a), len(ins[b])
            x1 = ax + aw * (0.5 if n == 1 else 0.22 + 0.56 * i / (n - 1))
            x2 = bx + bw * (0.5 if m == 1 else 0.22 + 0.56 * j / (m - 1))
            dash = ' stroke-dasharray="6 5"' if dashed else ""
            out.append(f'<line class="ed" x1="{x1:.0f}" y1="{ay + bh:.0f}" x2="{x2:.0f}" y2="{by - 4:.0f}"{dash} marker-end="url(#ah)"/>')

    dim = scn.get("business_dimension")
    users_sub = f"{len(dim['values'])} × {dim.get('label', dim['attribute'])}, " if dim else ""
    box("__users", "nu", t["users"], f"{users_sub}{len(scn['screens'])} {t['screens']}")
    ux, uy, uw = pos["__users"]
    fx, fy, fw = pos[front["id"]]
    out.append(f'<line class="ed" x1="{ux + uw / 2:.0f}" y1="{uy + bh}" x2="{fx + fw / 2:.0f}" y2="{fy - 4}" marker-end="url(#ah)"/>')
    kpi = "Apdex" if summary.get("kpi") == "apdex" else ""
    box(front["id"], "tr", front["id"], ", ".join(x for x in (front["tech"], kpi) if x))
    for s in services:
        box(s["id"], "tr", s["id"], s["tech"])
    for d in deps:
        klass = "tr" if d["role"] == "core" and core else cls[d["role"]]
        box(d["id"], klass, d["id"], d["tech"] or t["roles"][d["role"]])
    fan(e1, not f2s)
    fan(e2, False)
    pos["__hub"] = (margin, y_hub, width - 2 * margin)
    box("__hub", "hub", t["hub"], t["hub_sub"].format(ns=summary["namespace"], n=f"{summary['total_events']:,}".replace(",", " ")))

    legend = [("tr", t["lg_traced"] if logs else t["lg_traced_nolog"])]
    if any(d["role"] == "core" for d in deps):
        legend.append(("tr" if core else "lg", t["lg_logs_trace"] if core else t["lg_logs"]))
    if any(d["role"] in ("db", "ext") for d in deps):
        legend.append(("cl", t["lg_caller"]))
    x = margin
    for klass, label in legend:
        out.append(f'<g class="{klass}"><rect x="{x}" y="{y_leg - 11}" width="13" height="13" rx="3" stroke-width="1"/></g>'
                   f'<text class="le" x="{x + 20}" y="{y_leg}">{e(label)}</text>')
        x += 34 + len(label) * 7.2
    extra = []
    if not f2s:
        extra.append(t["lg_broken"])
    if keys:
        names = {"services": t["to_services"], "core": t["to_core"]}
        extra.append(t["keys"] + (" : " if lang == "fr" else ": ") + ", ".join(f"{k['attribute']} → {' + '.join(names[r] for r in ('services', 'core') if r in k['reaches'])}" for k in keys))
    if extra:
        out.append(f'<text class="le" x="{margin}" y="{y_leg + 26}">{e(clip(". ".join(extra), width - 2 * margin, 7.0))}</text>')
    out.append("</svg>")
    if len(services) > 6 or len(deps) > 6:
        print("NOTE: more than 6 boxes in a tier: the diagram wraps on two rows and some arrows may cross boxes. Check out/diagram.svg.")
    return "".join(out)


# --------------------------------------------------------------------------- charts
def ribbon(truth: dict, highlight: set | None = None, height: int = 18) -> str:
    """The day as a strip: incident windows marked, the current scenario filled."""
    ws, we = datetime.fromisoformat(truth["window"]["start"]), datetime.fromisoformat(truth["window"]["end"])
    span = (we - ws).total_seconds()
    w = 1136
    out = [f'<svg viewBox="0 0 {w} {height}" width="100%" height="{height}" preserveAspectRatio="none" aria-hidden="true">',
           f'<rect x="0" y="{height / 2 - 1}" width="{w}" height="2" fill="var(--line)"/>']
    for inc in truth["incidents"]:
        a = (datetime.fromisoformat(inc["start"]) - ws).total_seconds() / span * w
        b = (datetime.fromisoformat(inc["end"]) - ws).total_seconds() / span * w
        on = highlight is None or inc["id"] in highlight
        out.append(f'<rect x="{a:.1f}" y="2" width="{max(b - a, 3):.1f}" height="{height - 4}" rx="2" '
                   f'fill="{"var(--incident)" if on else "var(--incident-bg)"}"/>')
    out.append("</svg>")
    return "".join(out)


def timeline(summary: dict, truth: dict, lang: str) -> str:
    t = T[lang]
    pts = summary["timeline_15min"]
    apdex = summary.get("kpi") == "apdex"
    busy = max(p["requests"] for p in pts)
    vals = [(p["apdex"] if apdex else p["avg_ms"]) if p["requests"] >= max(10, 0.03 * busy) else None for p in pts]
    known = [v for v in vals if v is not None]
    if not known:
        return ""
    lo, hi = (min(0.5, min(known)), 1.0) if apdex else (0, max(known) * 1.1)
    w, h, left, top, bottom = 1136, 300, 56, 16, 34
    px = lambda i: left + (w - left) * i / max(1, len(pts) - 1)
    py = lambda v: top + (h - top - bottom) * (1 - (v - lo) / (hi - lo))
    ws, we = datetime.fromisoformat(truth["window"]["start"]), datetime.fromisoformat(truth["window"]["end"])
    span = (we - ws).total_seconds()
    out = [f'<svg viewBox="0 0 {w} {h}" role="img"><title>{e(t["day"])}</title>']
    for inc in truth["incidents"]:
        a = left + (w - left) * (datetime.fromisoformat(inc["start"]) - ws).total_seconds() / span
        b = left + (w - left) * (datetime.fromisoformat(inc["end"]) - ws).total_seconds() / span
        out.append(f'<rect x="{a:.1f}" y="{top}" width="{max(b - a, 3):.1f}" height="{h - top - bottom}" fill="var(--incident-bg)"/>')
    ticks = [lo + (hi - lo) * k / 4 for k in range(5)]
    for v in ticks:
        label = f"{v:.2f}".replace(".", "," if lang == "fr" else ".") if apdex else f"{v / 1000:.1f} s".replace(".", "," if lang == "fr" else ".")
        out.append(f'<line x1="{left}" x2="{w}" y1="{py(v):.1f}" y2="{py(v):.1f}" stroke="var(--line)" stroke-width="1"/>'
                   f'<text x="{left - 8}" y="{py(v) + 4:.1f}" text-anchor="end" font-size="12" fill="var(--muted)">{label}</text>')
    if apdex:
        tv = truth["apdex"]["target"]
        out.append(f'<line x1="{left}" x2="{w}" y1="{py(tv):.1f}" y2="{py(tv):.1f}" stroke="var(--ok)" stroke-width="1.5" stroke-dasharray="5 4"/>'
                   f'<text x="{left + 6}" y="{py(tv) + 16:.1f}" font-size="12" fill="var(--ok)">{e(t["target"])} {str(tv).replace(".", "," if lang == "fr" else ".")}</text>')
    step = max(1, len(pts) // 8)
    for i in range(0, len(pts), step):
        out.append(f'<text x="{px(i):.1f}" y="{h - 10}" text-anchor="middle" font-size="12" fill="var(--muted)">{pts[i]["t"][11:16]}</text>')
    path, pen = [], False
    for i, v in enumerate(vals):
        if v is None:
            pen = False
            continue
        path.append(f'{"L" if pen else "M"}{px(i):.1f} {py(v):.1f}')
        pen = True
    out.append(f'<path d="{" ".join(path)}" fill="none" stroke="var(--accent)" stroke-width="2.2" stroke-linejoin="round"/></svg>')
    return "".join(out)


# --------------------------------------------------------------------------- slides
def num(n, lang: str) -> str:
    return f"{n:,}".replace(",", " " if lang == "fr" else ",")


def fmt_level(d: dict, summary: dict, lang: str) -> str:
    t = T[lang]
    if summary.get("kpi") == "apdex" and d.get("apdex") is not None:
        return f"{t['apdex']} {str(d['apdex']).replace('.', ',' if lang == 'fr' else '.')}"
    if d.get("avg_ms") is None:
        return ""
    return f"{t['avg']} {d['avg_ms'] / 1000:.1f} s".replace(".", "," if lang == "fr" else ".")


def build(out: Path) -> tuple[str, str]:
    scn = json.loads((out / "scenario.json").read_text(encoding="utf-8"))
    summary = json.loads((out / "summary.json").read_text(encoding="utf-8"))
    truth = json.loads((out / "ground_truth.json").read_text(encoding="utf-8"))
    qpath = out / "questions.json"
    questions = json.loads(qpath.read_text(encoding="utf-8"))["conversations"] if qpath.exists() else []
    c = scn["customer"]
    lang = c.get("language", "fr") if c.get("language", "fr") in T else "en"
    t = T[lang]
    sys.path.insert(0, str(Path(__file__).parent))
    try:
        from agent import resolve
    except Exception:                                          # the deck never depends on the agent module
        resolve = lambda text, truth, lang: text               # noqa: E731
    system = c.get("system", c["name"])
    slides: list[tuple[str, set | None]] = []

    # 1. title
    hrs = (datetime.fromisoformat(truth["window"]["end"]) - datetime.fromisoformat(truth["window"]["start"])).total_seconds() / 3600
    if hrs == 24 and truth["window"]["start"][11:16] == "00:00":
        day = resolve("{date}", truth, lang)
    else:
        day = f"{truth['window']['start'][:16].replace('T', ' ')} → {truth['window']['end'][:16].replace('T', ' ')}"
    slides.append((f'<div style="margin-top:auto"><h3>{e(t["deck"])}</h3><h1>{e(c["name"])}, {e(system)}</h1>'
                   f'<p class="lead">{e(day)}</p><p class="note" style="margin-top:28px">{e(t["synthetic"])}</p></div>'
                   f'<div style="margin-bottom:auto"></div>', None))

    # 2. context
    ctx = c.get("context") or []
    ctx = [ctx] if isinstance(ctx, str) else ctx
    bullets = "".join(f"<li>{e(x)}</li>" for x in ctx) or f'<li class="note">{e(t["context_missing"])}</li>'
    a = truth.get("apdex")
    if a:
        kpi = (f"Apdex : {a['satisfied_ms'] / 1000:g} s / {a['frustrated_ms'] / 1000:g} s, {t['target']} "
               f"{str(a['target']).replace('.', ',' if lang == 'fr' else '.')}")
    else:
        kpi = t["no_kpi"]
    dim = scn.get("business_dimension")
    path = c.get("investigation_path") or (truth["incidents"][0]["investigation_layers"] if truth["incidents"] else [])
    facts = [(t["sector"], c.get("sector", "")), (t["system"], system), (t["kpi"], kpi),
             (t["dimension"], f"{dim.get('label', dim['attribute'])} ({len(dim['values'])})" if dim else ""),
             (t["path"], "<br>".join(e(x) for x in path))]
    dl = "".join(f"<dt>{e(k)}</dt><dd>{v if k == t['path'] else e(v)}</dd>" for k, v in facts if v)
    slides.append((f'<h2>{e(t["context"])}</h2><div class="cols"><ul>{bullets}</ul><dl>{dl}</dl></div>', None))

    # 3. systems and attributes
    sysl = systems(scn)
    for start in range(0, len(sysl), 9):
        rows = ""
        for s in sysl[start:start + 9]:
            chips = "".join(f'<span class="chip {"c" if src == "customer" else "l"}">{e(k)}</span>' for k, src in s["attrs"].items())
            std = '<span class="note">' + e(t["std"]) + "</span>"
            rows += (f'<tr><td><span class="f">{e(s["id"])}</span></td><td>{e(t["roles"][s["role"]])}</td><td>{e(s["tech"])}</td>'
                     f'<td>{chips or std}</td></tr>')
        key = (f'<div class="key"><span><i style="background:var(--accent)"></i>{e(t["src_customer"])}</span>'
               f'<span><i style="background:var(--cs)"></i>{e(t["src_literature"])}</span></div>')
        slides.append((f'<h2>{e(t["systems"])}</h2><table><tr><th>{e(t["system"])}</th><th>{e(t["role"])}</th><th>{e(t["tech"])}</th>'
                       f'<th>{e(t["attrs"])}</th></tr>{rows}</table>{key}', None))

    # 4. diagram
    slides.append((f'<h2>{e(t["diagram"])}</h2><div class="fill">{diagram(scn, summary, lang)}</div>', None))

    # 5. statistics
    def kind(stream: str) -> str:
        typ, rest = stream.split("-", 1)
        ds = rest.rsplit(".otel-", 1)[0]
        if typ in ("traces", "metrics"):
            return t["kinds"][typ]
        return t["kinds"].get(ds, t["kinds"]["app"] if ds.endswith(".app") else ds)
    rows = "".join(f'<tr><td><span class="f">{e(k)}</span></td><td>{e(kind(k))}</td><td class="num">{num(v, lang)}</td></tr>'
                   for k, v in summary["events_by_data_stream"].items())
    hours = round((datetime.fromisoformat(truth["window"]["end"]) - datetime.fromisoformat(truth["window"]["start"])).total_seconds() / 3600)
    big = "".join(f"<div><b>{v}</b><span>{e(l)}</span></div>" for v, l in (
        (num(summary["total_events"], lang), t["events"]), (num(summary["user_requests"], lang), t["requests"]),
        (hours, t["hours"]), (len(summary["events_by_data_stream"]), t["streams"])))
    slides.append((f'<h2>{e(t["stats"])}</h2><div class="big">{big}</div><table><tr><th>{e(t["stream"])}</th><th>{e(t["content"])}</th>'
                   f'<th class="num">{e(t["count"])}</th></tr>{rows}</table>', None))

    # 6. the day
    rt = truth["response_time"]
    base = fmt_level({"apdex": (a or {}).get("baseline"), "avg_ms": rt["baseline"]["avg_ms"]}, summary, lang)
    over = fmt_level({"apdex": (a or {}).get("overall"), "avg_ms": rt["overall"]["avg_ms"]}, summary, lang)
    slides.append((f'<h2>{e(t["day"])}</h2><p class="note" style="margin:-14px 0 14px">{e(t["baseline"])} : {e(base)}. {e(t["overall"])} : {e(over)}.</p>'
                   f'<div class="fill">{timeline(summary, truth, lang)}</div>', None))

    # 7. one slide per fault scenario (overlapping incidents of a group share a slide)
    groups: dict[str, list] = {}
    for inc in truth["incidents"]:
        groups.setdefault(inc.get("group") or inc["id"], []).append(inc)
    used = set()
    for gid, incs in groups.items():
        ids = {i["id"] for i in incs}
        convs = [q for q in questions if ids & set(q.get("incidents", []))]
        used.update(q["id"] for q in convs)
        window = f"{min(i['start_local'] for i in incs)} – {max(i['end_local'] for i in incs)}"
        screens = sorted({s for i in incs for s in i["impacted_screens"]})
        causes = "".join(f"<li>{e(i['root_cause'].split(' Attention : ')[0].split(' Note: ')[0])}</li>" for i in incs)
        label = lambda st: "traces" if st.startswith("traces-") else st.split("-", 1)[1].rsplit(".otel-", 1)[0]   # noqa: E731
        proofs = "".join(f'<li><span class="f">{e(label(ev["stream"]))}</span> : {e(ev["fact"])}</li>'
                         for i in incs for ev in i["evidence"][: (3 if len(incs) == 1 else 2)])
        qs = "".join(f'<div class="q"><p>{e(resolve(tn["prompt"], truth, lang))}</p>' +
                     (f'<div class="x">{e(t["expected"])} : {e(resolve(tn["expected"], truth, lang))}</div>' if tn.get("expected") else "") + "</div>"
                     for q in convs for tn in q["turns"][:2 if len(convs) > 1 else 4])
        worst = min(incs, key=lambda i: i["apdex"]) if summary.get("kpi") == "apdex" else max(incs, key=lambda i: i["avg_ms"])
        level = fmt_level(worst, summary, lang)
        fixes = "".join(f"<li>{e(i['remediation'])}</li>" for i in incs)
        title = " + ".join(dict.fromkeys(t["types"].get(i["type"], i["type"]) for i in incs))
        left = (f'<h3>{e(t["seen"])}</h3><p style="margin:0 0 16px">{e(level)}. {e(t["screens_hit"])} : {e(", ".join(screens))}.</p>'
                f'<h3>{e(t["cause"])}</h3><ul style="margin-bottom:14px">{causes}</ul><h3>{e(t["proof"])}</h3><ul class="note" style="margin-bottom:12px">{proofs}</ul>'
                f'<h3>{e(t["remedy"])}</h3><ul class="note">{fixes}</ul>')
        none = '<p class="note">' + e(t["no_questions"]) + "</p>"
        right = f'<h3>{e(t["asked"])}</h3>{qs or none}'
        style = "<style>.sc li,.sc p{font-size:15px;line-height:1.4}.sc ul.note li{font-size:13px;margin-bottom:6px}.sc .q p{font-size:14px}.sc .q .x{font-size:13px}.sc .q{margin-bottom:10px}</style>"
        slides.append((f'{style}<span class="tag">{e(t["scenario"])} {e(gid)} · {e(window)}</span><h2 style="margin-bottom:18px">{e(title)}</h2>'
                       f'<div class="cols sc">{"<div>" + left + "</div>"}<div>{right}</div></div>', ids))

    # 8. remaining questions
    rest = [tn for q in questions if q["id"] not in used for tn in q["turns"]]
    for start in range(0, len(rest), 5):
        qs = "".join(f'<div class="q"><p>{e(resolve(tn["prompt"], truth, lang))}</p>' +
                     (f'<div class="x">{e(t["expected"])} : {e(resolve(tn["expected"], truth, lang))}</div>' if tn.get("expected") else "") +
                     "</div>" for tn in rest[start:start + 5])
        slides.append((f'<h2>{e(t["other"])}</h2><div>{qs}</div>', None))

    body = []
    for i, (html, hl) in enumerate(slides):
        rib = f'<div class="ribbon">{ribbon(truth, hl)}</div>' if truth["incidents"] and i > 0 else ""
        body.append(f'<section class="slide{" on" if i == 0 else ""}" id="s{i + 1}">{html}{rib}<div class="foot">{i + 1} / {len(slides)}</div></section>')
    title = f"{c['name']} – {t['deck']}"
    page = (f'<!doctype html><html lang="{lang}"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><title>{e(title)}</title>'
            f"<style>{CSS}</style></head><body><main class=\"stage\">{''.join(body)}</main>"
            f'<div class="nav"><button id="prev" aria-label="Previous slide">‹</button><button id="next" aria-label="Next slide">›</button></div>'
            f"<script>{JS}</script></body></html>")
    return page, diagram(scn, summary, lang, standalone=True)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("out")
    args = ap.parse_args()
    if json.loads((Path(args.out) / "summary.json").read_text(encoding="utf-8")).get("model") == "deal_flow":
        import deal_summary
        print("Wrote", deal_summary.build_html(Path(args.out)))
        return
    out = Path(args.out)
    if not (out / "summary.json").exists():
        sys.exit(f"ERROR: {out} is not an output directory of generate.py")
    page, svg = build(out)
    (out / "summary-deck.html").write_text(page, encoding="utf-8")
    (out / "diagram.svg").write_text(svg, encoding="utf-8")
    print(f"Wrote {out / 'summary-deck.html'} ({page.count('<section')} slides) and {out / 'diagram.svg'}")
    if not (out / "questions.json").exists():
        print("NOTE: no questions.json yet: scenario slides have no question. Rerun after writing it.")


if __name__ == "__main__":
    main()
