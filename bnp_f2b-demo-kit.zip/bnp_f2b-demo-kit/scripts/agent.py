#!/usr/bin/env python3
"""Build, test, deploy and rehearse the Elastic Agent Builder agent of a demo.

    python3 agent.py build out/                        write out/agent.json (ES|QL tools + agent definition)
    python3 agent.py questions out/                    render out/questions.json as out/questions.md (demo cheat sheet)
    python3 agent.py test-tools out/ [--env-file F]    run every tool query against Elasticsearch, no Kibana needed
    python3 agent.py deploy out/ [--env-file F]        create or update tools and agent through the Kibana API
    python3 agent.py rehearse out/ [--env-file F]      ask out/questions.json to the agent, write out/rehearsal.md
    python3 agent.py delete out/ [--env-file F]        remove the agent and its tools

out/ is the output directory of generate.py. out/agent.json can be edited by hand between build and deploy.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import api_key_header, as_json, die, esql, http, load_env, need  # noqa: E402

BUILTIN_WANTED = ["platform.core.search", "platform.core.list_indices", "platform.core.get_index_mapping",
                  "platform.core.generate_esql", "platform.core.execute_esql"]
TIME = {"start": {"type": "date", "description": "Start of the time range, ISO 8601 with timezone offset, e.g. 2026-01-15T09:30:00+01:00"},
        "end": {"type": "date", "description": "End of the time range (exclusive), ISO 8601 with timezone offset"}}
RANGE = "@timestamp >= ?start AND @timestamp < ?end"


# --------------------------------------------------------------------------- build
def build_tools(scn: dict, summary: dict) -> list[dict]:
    ns, p = summary["namespace"], summary["attribute_prefix"]
    system = scn["customer"].get("system", scn["customer"]["name"])
    tr = f"traces-*-{ns}"
    app = f"logs-{p}.app*-{ns}"
    sap = lambda d: f"logs-sap.{d}*-{ns}"                     # noqa: E731
    apdex_eval = ('| EVAL sat = CASE(attributes.apdex.zone == "satisfied", 1, 0), '
                  'tol = CASE(attributes.apdex.zone == "tolerating", 1, 0), '
                  'fru = CASE(attributes.apdex.zone == "frustrated", 1, 0), dur_ms = duration / 1000000.0')
    apdex_stats = ("requests = COUNT(*), satisfied = SUM(sat), tolerating = SUM(tol), frustrated = SUM(fru), "
                   "avg_ms = ROUND(AVG(dur_ms)), p95_ms = ROUND(PERCENTILE(dur_ms, 95))")
    apdex_final = "| EVAL apdex = ROUND((satisfied + tolerating / 2.0) / requests, 3)"
    tools = []

    def tool(name: str, description: str, query: str, extra: dict | None = None, layer: str = "",
             time: bool = True) -> None:
        tools.append({"id": f"{ns}.{name}", "type": "esql", "description": " ".join(description.split()),
                      "tags": [ns, "demo", layer] if layer else [ns, "demo"],
                      "configuration": {"query": " ".join(query.split()),
                                        "params": {**(TIME if time else {}), **(extra or {})}}})

    dim = scn.get("business_dimension")
    ui = f"FROM {tr} | WHERE {RANGE} AND attributes.{p}.screen IS NOT NULL"
    if summary.get("kpi", "apdex") == "apdex":
        kpi, keep = "apdex", "apdex, requests, satisfied, tolerating, frustrated, avg_ms, p95_ms"
        stats = f"{apdex_eval} | STATS {apdex_stats}"
        final, worst = apdex_final, "apdex ASC"
        what = "Apdex, request count, average and p95 response time"
        read = "An Apdex below the target means a degradation."
    else:
        kpi, keep = "response_time", "requests, avg_ms, p95_ms, errors, error_rate_pct"
        stats = ("| EVAL dur_ms = duration / 1000000.0, err = CASE(attributes.http.response.status_code >= 500, 1, 0) "
                 "| STATS requests = COUNT(*), errors = SUM(err), avg_ms = ROUND(AVG(dur_ms)), p95_ms = ROUND(PERCENTILE(dur_ms, 95))")
        final, worst = "| EVAL error_rate_pct = ROUND(100.0 * errors / requests, 1)", "avg_ms DESC"
        what = "request count, average and p95 response time, errors and error rate"
        read = ("No KPI is defined: a degradation is a response time well above the usual level of the same screen, "
                "or an error rate that rises.")
    tool(f"{kpi}_timeline", f"""Layer 1 (UI). {what} of the {system} user interface per 15-minute bucket over a time
         range. Use it first to find WHEN users were slowed down. {read} Call it on a whole day, then zoom in.""",
         f"""{ui} {stats} BY bucket = BUCKET(@timestamp, 15 minutes) {final}
         | KEEP bucket, {keep} | SORT bucket | LIMIT 300""", layer="layer1")
    tool(f"{kpi}_by_screen", f"""Layer 1 (UI). {what} per screen of the {system} user interface over a time range. Use
         it to find WHICH screens suffer during a degraded period, and compare with a healthy period of the same
         length. {read}""",
         f"""{ui} {stats} BY screen = attributes.{p}.screen {final}
         | KEEP screen, {keep} | SORT {worst} | LIMIT 100""", layer="layer1")
    if dim:
        d = dim["attribute"]
        tool(f"{kpi}_by_{d}", f"""Layer 1 (UI). {what} per {dim.get('label', d)} over a time range. Use it to tell which
             {dim.get('label', d)} values are the most affected, or to check whether a slowdown is local or global.""",
             f"""{ui} {stats} BY {d} = attributes.{p}.{d} {final}
             | KEEP {d}, {keep} | SORT {worst} | LIMIT 200""", layer="layer1")
    tool("service_endpoints", f"""Layer 2 (services, application logs). Response time per service and endpoint over a
         time range: total, time spent in downstream calls (dependencies) and own processing time, plus error
         rate. Use it to find WHICH service and endpoint is slow, and whether the time is spent inside the service
         (own_ms high) or in a dependency (downstream_ms high).""",
         f"""FROM {app} | WHERE {RANGE} AND attributes.{p}.log.pattern == "access"
         | EVAL err = CASE(attributes.http.response.status_code >= 500, 1, 0)
         | STATS requests = COUNT(*), avg_ms = ROUND(AVG(attributes.{p}.duration_ms)),
           p95_ms = ROUND(PERCENTILE(attributes.{p}.duration_ms, 95)), avg_own_ms = ROUND(AVG(attributes.{p}.own_ms)),
           avg_downstream_ms = ROUND(AVG(attributes.{p}.downstream_ms)), errors = SUM(err)
           BY service = resource.attributes.service.name, endpoint = attributes.http.route
         | EVAL error_rate_pct = ROUND(100.0 * errors / requests, 1) | SORT avg_ms DESC | LIMIT 100""", layer="layer2")
    tool("service_log_patterns", """Layer 2 (services, application logs). Count of WARN and ERROR log lines per
         service, log pattern and exception type over a time range, with first and last occurrence. Use it to see
         what the services complain about: slow dependency, timeout, deployment side effect, exception.""",
         f"""FROM {app} | WHERE {RANGE} AND severity_text IN ("WARN", "ERROR")
         | STATS occurrences = COUNT(*), first_seen = MIN(@timestamp), last_seen = MAX(@timestamp)
           BY service = resource.attributes.service.name, severity = severity_text, pattern = attributes.{p}.log.pattern,
              dependency = attributes.{p}.dependency.name, exception = attributes.exception.type
         | SORT occurrences DESC | LIMIT 100""", layer="layer2")
    tool("service_log_samples", """Layer 2 (services, application logs). Latest 20 WARN and ERROR log lines of ONE
         service over a time range, with the full message. Use it after service_log_patterns to read the exact
         wording of a problem.""",
         f"""FROM {app} | WHERE {RANGE} AND severity_text IN ("WARN", "ERROR") AND resource.attributes.service.name == ?service
         | KEEP @timestamp, severity_text, attributes.{p}.log.pattern, body.text, resource.attributes.service.version
         | SORT @timestamp DESC | LIMIT 20""",
         {"service": {"type": "string", "description": "Exact service name, e.g. " + scn["services"][0]["name"]}}, layer="layer2")
    tool("service_versions", """Layer 2 (services). Versions seen per service over a time range with first and last
         time each version handled a request, plus average response time and errors per version. Use it to detect a
         deployment or a rollback and to compare a new version with the previous one.""",
         f"""FROM {tr} | WHERE {RANGE} AND attributes.{p}.layer == "service"
         | EVAL dur_ms = duration / 1000000.0, err = CASE(attributes.http.response.status_code >= 500, 1, 0)
         | STATS requests = COUNT(*), first_seen = MIN(@timestamp), last_seen = MAX(@timestamp),
           avg_ms = ROUND(AVG(dur_ms)), errors = SUM(err)
           BY service = resource.attributes.service.name, version = resource.attributes.service.version
         | SORT service, first_seen | LIMIT 100""", layer="layer2")
    tool("dependencies", """Layer 3 (root cause: which dependency?). Calls made by the services to their dependencies
         over a time range, one row per dependency (core system, databases, external APIs), with call count, average and p95 duration and error count.
         Use it to decide whether the slowdown comes from a dependency, and which one, or from none of them.""",
         f"""FROM {tr} | WHERE {RANGE} AND attributes.{p}.dependency.type IS NOT NULL
         | EVAL dur_ms = duration / 1000000.0,
           err = CASE(attributes.http.response.status_code >= 500 OR status.code == "Error", 1, 0)
         | STATS calls = COUNT(*), avg_ms = ROUND(AVG(dur_ms)), p95_ms = ROUND(PERCENTILE(dur_ms, 95)), errors = SUM(err)
           BY dependency_type = attributes.{p}.dependency.type, dependency = attributes.{p}.dependency.name,
              caller = resource.attributes.service.name
         | SORT avg_ms DESC | LIMIT 100""", layer="layer3")
    co = summary.get("correlation") or {}
    keys = co.get("propagated_keys", [])
    key_cols = "".join(f", attributes.{k['attribute']}" for k in keys)
    dim_col = f", attributes.{p}.{dim['attribute']}" if dim else ""
    chain = ("KEEP @timestamp, data_stream.dataset, resource.attributes.service.name, name, kind, duration_ms, "
             "attributes.http.response.status_code, severity_text, body.text")
    tool("slowest_requests", f"""Correlation. The 20 slowest user requests of a time range, each with its trace_id, screen,
         duration, status{' and business keys' if keys else ''}. Use it to pick ONE concrete request, then follow it
         through the chain with trace_details{' or a follow_* tool' if keys else ''}.""",
         f"""FROM {tr} | WHERE {RANGE} AND attributes.{p}.screen IS NOT NULL
         | EVAL duration_ms = ROUND(duration / 1000000.0)
         | KEEP @timestamp, trace_id, attributes.{p}.screen, duration_ms, attributes.http.response.status_code{dim_col}{key_cols}
         | SORT duration_ms DESC | LIMIT 20""", layer="correlation")
    tool("trace_details", """Correlation. Every span and log line that shares one trace_id, in time order, with the
         system that produced it, the operation, its duration and the log message. Use it to see where the time of
         one request was spent. Systems that do not carry the trace_id do not appear: the agent instructions say
         which ones.""",
         f"""FROM traces-*-{ns}, logs-*-{ns} | WHERE trace_id == ?trace_id
         | EVAL duration_ms = ROUND(duration / 1000000.0) | {chain} | SORT @timestamp | LIMIT 200""",
         {"trace_id": {"type": "string", "description": "32-character hexadecimal trace id, as returned by slowest_requests"}},
         layer="correlation", time=False)
    for k in keys:
        if not k.get("identifier"):
            continue
        safe = "".join(ch if ch.isalnum() else "_" for ch in k["attribute"])
        tool(f"follow_{safe}", f"""Correlation. Every span and log line carrying one value of the business key
             {k['attribute']}, in time order, across all the systems the key reaches. Use it to follow one business
             object through the chain, including systems that do not share the trace_id.""",
             f"""FROM traces-*-{ns}, logs-*-{ns} | WHERE attributes.{k['attribute']} == ?value
             | EVAL duration_ms = ROUND(duration / 1000000.0) | {chain}, trace_id | SORT @timestamp | LIMIT 200""",
             {"value": {"type": "string", "description": f"Exact value of {k['attribute']}"}}, layer="correlation", time=False)
    if scn.get("sap"):
        tool("sap_st03_workload", """Layer 3 (SAP). SAP workload statistics (transaction ST03) per task type over a time
             range: DIALOG, HTTP, BACKGROUND, RFC, UPDATE, with dialog steps and step-weighted average response, wait,
             CPU and database times in ms. High wait time means requests queue for a free work process. Response time
             here is SAP internal processing: it does NOT include waiting in the ICM HTTP queue.""",
             f"""FROM {sap('st03')} | WHERE {RANGE}
             | EVAL w = attributes.sap.st03.steps
             | STATS steps = SUM(w), resp = SUM(attributes.sap.st03.avg_response_time_ms * w),
               wait = SUM(attributes.sap.st03.avg_wait_time_ms * w), cpu = SUM(attributes.sap.st03.avg_cpu_time_ms * w),
               db = SUM(attributes.sap.st03.avg_db_time_ms * w) BY task_type = attributes.sap.st03.task_type
             | WHERE steps > 0
             | EVAL avg_response_ms = ROUND(resp / steps), avg_wait_ms = ROUND(wait / steps),
               avg_cpu_ms = ROUND(cpu / steps), avg_db_ms = ROUND(db / steps)
             | KEEP task_type, steps, avg_response_ms, avg_wait_ms, avg_cpu_ms, avg_db_ms | SORT task_type | LIMIT 20""", layer="layer3")
        tool("sap_http_icm", """Layer 3 (SAP). HTTP/HTTPS requests received by SAP (ICM access log) per URL path over a time
             range: request count, average and p95 response time, average time waiting in the ICM queue, average SAP
             processing time and 5xx errors. Queue time high with normal processing time means the HTTP front of SAP
             is saturated, not SAP itself.""",
             f"""FROM {sap('icm')} | WHERE {RANGE}
             | EVAL err = CASE(attributes.http.response.status_code >= 500, 1, 0)
             | STATS requests = COUNT(*), avg_response_ms = ROUND(AVG(attributes.sap.icm.response_time_ms)),
               p95_response_ms = ROUND(PERCENTILE(attributes.sap.icm.response_time_ms, 95)),
               avg_queue_ms = ROUND(AVG(attributes.sap.icm.queue_time_ms)),
               avg_processing_ms = ROUND(AVG(attributes.sap.icm.processing_time_ms)), errors_5xx = SUM(err)
               BY path = attributes.url.path
             | SORT avg_response_ms DESC | LIMIT 50""", layer="layer3")
        tool("sap_jobs", """Layer 3 (SAP). SAP background job events (SM37) over a time range: job started or finished,
             job name, report, user, trigger (scheduled or manual), planned start time, duration and number of work
             processes used. A job started manually outside its planned window during business hours is suspect.
             Widen the range by two hours before the incident to catch jobs that started earlier.""",
             f"""FROM {sap('jobs')} | WHERE {RANGE}
             | KEEP @timestamp, attributes.sap.event, attributes.sap.job.name, attributes.sap.job.report,
               attributes.sap.job.user, attributes.sap.job.trigger, attributes.sap.job.planned_start,
               attributes.sap.job.duration_s, attributes.sap.job.work_processes
             | SORT @timestamp | LIMIT 100""", layer="layer3")
        tool("sap_work_processes", """Layer 3 (SAP). SAP work process occupation (SM50/SM66) per 5-minute bucket over a time
             range: percentage of busy dialog work processes, dialog queue length, busy background work processes and
             CPU. Dialog work processes above 90 % with a queue mean SAP is saturated.""",
             f"""FROM {sap('workprocess')} | WHERE {RANGE}
             | STATS dialog_busy_pct = ROUND(AVG(attributes.sap.wp.dialog.busy_pct), 1),
               max_dialog_queue = MAX(attributes.sap.wp.dialog.queue_length),
               background_busy = MAX(attributes.sap.wp.background.busy),
               cpu_pct = ROUND(AVG(attributes.sap.cpu.utilization_pct), 1) BY bucket = BUCKET(@timestamp, 5 minutes)
             | SORT bucket | LIMIT 300""", layer="layer3")
        tool("sap_syslog", """Layer 3 (SAP). SAP technical log warnings and errors (SM21 system log, ICM) over a time range,
             counted per event type with first and last occurrence. Typical events: dialog_wp_saturation,
             icm_thread_exhaustion.""",
             f"""FROM {sap('syslog')} | WHERE {RANGE} AND severity_text IN ("WARN", "ERROR")
             | STATS occurrences = COUNT(*), first_seen = MIN(@timestamp), last_seen = MAX(@timestamp)
               BY event = attributes.sap.event | SORT occurrences DESC | LIMIT 50""", layer="layer3")
    return tools


INSTRUCTIONS = {
    "fr": """Tu es l'analyste performance de {customer} pour le système {system}. Tu réponds en français.

Données disponibles : {start} à {end} (fuseau {tz}). Si l'utilisateur ne donne pas de date, travaille sur cette
période. Passe toujours les paramètres start et end au format ISO 8601 avec le décalage horaire.

{kpi_rule}

Méthode d'investigation, toujours dans cet ordre :
{step1}
2. Couche services : identifie le service et l'endpoint lents (service_endpoints). Regarde si le temps est
   passé dans le service lui-même (avg_own_ms) ou dans ses dépendances (avg_downstream_ms). Consulte les logs
   (service_log_patterns, service_log_samples) et les versions déployées (service_versions).
{step3}

Compare toujours la période dégradée à une période saine de même durée, par exemple l'heure précédente.
Plusieurs causes peuvent se superposer : vérifie chaque dépendance avant de conclure.
{decoy}N'invente aucun chiffre : chaque affirmation doit venir d'un résultat d'outil.

{correlation}{attributes}Format de réponse : 1) le constat chiffré et les écrans touchés, 2) le service et l'endpoint, 3) la cause
racine avec les preuves chiffrées, 4) la remédiation proposée. Donne les heures en heure locale.""",
    "en": """You are the performance analyst of {customer} for the {system} system.

Available data: {start} to {end} (timezone {tz}). When the user gives no date, work on this period. Always pass
the start and end parameters as ISO 8601 with the timezone offset.

{kpi_rule}

Investigation method, always in this order:
{step1}
2. Services layer: find the slow service and endpoint (service_endpoints). Check whether time is spent in the
   service itself (avg_own_ms) or in its dependencies (avg_downstream_ms). Read the logs (service_log_patterns,
   service_log_samples) and the deployed versions (service_versions).
{step3}

Always compare the degraded period with a healthy period of the same length, for instance the hour before.
Several causes can overlap: check every dependency before concluding.
{decoy}Never invent a figure: every statement must come from a tool result.

{correlation}{attributes}Answer format: 1) the finding with figures and the affected screens, 2) the service and endpoint, 3) the root cause with
figures as evidence, 4) the proposed remediation. Give times in local time.""",
}


STEP3 = {
    ("fr", True): ("""3. Cause racine : tranche entre SAP et externe avec dependencies. Si SAP est en cause, distingue la saturation
   des work process (sap_work_processes, sap_st03_workload, sap_jobs, sap_syslog) de la saturation de la couche
   HTTP/HTTPS (sap_http_icm : temps en file d'attente élevé alors que le traitement SAP reste normal).""",
                   "Un job SAP qui tourne la nuit dans sa fenêtre planifiée est normal et n'est pas une cause.\n"),
    ("fr", False): ("""3. Cause racine : identifie avec dependencies quelle dépendance externe est lente ou en erreur. Si aucune
   ne l'est, la cause est dans le service lui-même (version déployée, logs).""", ""),
    ("en", True): ("""3. Root cause: decide between SAP and external with dependencies. If SAP is involved, tell work process saturation
   (sap_work_processes, sap_st03_workload, sap_jobs, sap_syslog) from HTTP/HTTPS layer saturation (sap_http_icm:
   high queue time while SAP processing stays normal).""",
                   "A SAP job running at night inside its planned window is normal and is not a cause.\n"),
    ("en", False): ("""3. Root cause: use dependencies to find which external dependency is slow or failing. If none is, the cause
   is inside the service itself (deployed version, logs).""", ""),
}
KPI_TEXT = {
    ("fr", "apdex"): ("""Règle Apdex de {customer} : une requête est « satisfied » si elle répond sans erreur en moins de {t} s,
« tolerating » entre {t} s et {f} s, « frustrated » au-delà ou en cas d'erreur.
Apdex = (satisfied + tolerating / 2) / total. Objectif : {target}.""",
                      """1. Couche interface utilisateur : repère quand l'Apdex passe sous l'objectif (apdex_timeline), puis quels
   écrans{dim_txt} sont touchés (apdex_by_screen{dim_tool})."""),
    ("fr", "none"): ("""{customer} n'a pas d'indicateur de performance formalisé. Une dégradation se lit sur le temps de réponse
(moyenne et p95) et le taux d'erreur, comparés au niveau habituel du même écran. Ne parle pas d'Apdex ni d'objectif.""",
                     """1. Couche interface utilisateur : repère quand le temps de réponse ou le taux d'erreur s'écartent du niveau
   habituel (response_time_timeline), puis quels écrans{dim_txt} sont touchés (response_time_by_screen{dim_tool})."""),
    ("en", "apdex"): ("""{customer} Apdex rule: a request is "satisfied" when it answers without error in under {t} s, "tolerating"
between {t} s and {f} s, "frustrated" beyond that or on error.
Apdex = (satisfied + tolerating / 2) / total. Target: {target}.""",
                      """1. UI layer: find when Apdex drops below the target (apdex_timeline), then which screens{dim_txt} are
   affected (apdex_by_screen{dim_tool})."""),
    ("en", "none"): ("""{customer} has no formal performance indicator. A degradation shows in response time (average and p95)
and error rate, compared with the usual level of the same screen. Do not mention Apdex or a target.""",
                     """1. UI layer: find when response time or error rate leave their usual level (response_time_timeline),
   then which screens{dim_txt} are affected (response_time_by_screen{dim_tool})."""),
}


def correlation_section(summary: dict, scn: dict, lang: str) -> str:
    """Tells the agent what ties the layers together: trace_id, business keys, or time only."""
    co = summary.get("correlation") or {}
    fr = lang == "fr"
    f2s, logs, core = (co.get("trace_frontend_to_services", True), co.get("trace_in_service_logs", True),
                       co.get("trace_in_core_system_logs", False))
    out = ["Corrélation entre les couches :" if fr else "Correlation between layers:"]
    if f2s:
        out.append("- Le trace_id relie une requête de l'interface aux services et à leurs appels sortants."
                   if fr else "- The trace_id ties a UI request to the services and their outgoing calls.")
    else:
        out.append("- Le trace_id ne passe pas de l'interface aux services : chaque service ouvre sa propre trace. "
                   "Relie les deux côtés par l'heure et l'endpoint appelé, ou par une clé métier."
                   if fr else "- The trace_id does not travel from the UI to the services: each service starts its own "
                   "trace. Tie both sides by time and called endpoint, or by a business key.")
    out.append(("- Les logs des services portent le trace_id." if logs else
                "- Les logs des services ne portent pas de trace_id : rattache-les par le service, l'endpoint et l'heure.")
               if fr else
               ("- Service logs carry the trace_id." if logs else
                "- Service logs carry no trace_id: tie them by service, endpoint and time."))
    if scn.get("sap"):
        out.append(("- Les logs HTTP de SAP portent aussi le trace_id." if core else
                    "- Les logs SAP n'ont pas de trace_id : rattache-les par l'heure et le chemin d'URL appelé.")
                   if fr else
                   ("- SAP HTTP logs carry the trace_id too." if core else
                    "- SAP logs carry no trace_id: tie them by time and called URL path."))
    for k in co.get("propagated_keys", []):
        to = {"services": "les services" if fr else "the services", "core": "les logs SAP" if fr else "SAP logs"}
        where = (" et " if fr else " and ").join(to[r] for r in ("services", "core") if r in k["reaches"])
        safe = "".join(ch if ch.isalnum() else "_" for ch in k["attribute"])
        hint = f" (outil follow_{safe})" if fr and k.get("identifier") else f" (tool follow_{safe})" if k.get("identifier") else ""
        out.append(f"- Clé métier attributes.{k['attribute']} : portée par l'interface, puis par {where}{hint}."
                   if fr else f"- Business key attributes.{k['attribute']}: carried by the UI, then by {where}{hint}.")
    out.append("- Pour suivre une requête précise : slowest_requests pour la choisir, puis trace_details."
               if fr else "- To follow one request: slowest_requests to pick it, then trace_details.")
    return "\n".join(out) + "\n\n"


def attribute_section(summary: dict, lang: str) -> str:
    """Tells the agent which customer-specific attributes exist, so it can use them with the generic ES|QL tools."""
    seen, lines = set(), []
    for c in summary.get("custom_attributes", []):
        if c["attribute"] in seen:
            continue
        seen.add(c["attribute"])
        desc = f" : {c['description']}" if c["description"] else ""
        lines.append(f"- attributes.{c['attribute']} ({c['system']}, {c['found_in']}){desc}")
    if not lines:
        return ""
    head = ("Attributs propres au client présents dans les données, utilisables pour filtrer ou regrouper avec les "
            "outils ES|QL génériques :" if lang == "fr" else
            "Customer-specific attributes present in the data, usable to filter or group with the generic ES|QL tools:")
    return head + "\n" + "\n".join(lines[:40]) + "\n\n"


MONTHS_FR = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre",
             "novembre", "décembre"]


def fmt_date(iso: str, lang: str) -> str:
    d = datetime.fromisoformat(iso)
    if lang == "fr":
        return f"{d.day}{'er' if d.day == 1 else ''} {MONTHS_FR[d.month - 1]} {d.year}"
    return d.strftime("%B %-d, %Y") if sys.platform != "win32" else d.strftime("%B %d, %Y")


def resolve(text: str, truth: dict, lang: str) -> str:
    """Replaces {date} (first day of the dataset window) and {date:INCIDENT_ID} in a prompt."""
    text = text.replace("{date}", fmt_date(truth["window"]["start"], lang))
    for inc in truth["incidents"]:
        text = text.replace("{date:%s}" % inc["id"], fmt_date(inc["start"], lang))
    return text


def load_questions(out: Path) -> tuple[dict, dict, str]:
    qpath = out / "questions.json"
    if not qpath.exists():
        die(f"missing {qpath}: write it first (format in references/questions-and-agent.md)")
    truth = json.loads((out / "ground_truth.json").read_text(encoding="utf-8"))
    scn = json.loads((out / "scenario.json").read_text(encoding="utf-8"))
    return json.loads(qpath.read_text(encoding="utf-8")), truth, scn["customer"].get("language", "fr")


def cmd_questions(out: Path) -> None:
    """Renders out/questions.md: the cheat sheet used during the demo."""
    questions, truth, lang = load_questions(out)
    fr = lang == "fr"
    by_id = {i["id"]: i for i in truth["incidents"]}
    lines = [f"# {'Questions de démonstration' if fr else 'Demo questions'} – {truth['customer']}", "",
             f"{'Données du' if fr else 'Data from'} {truth['window']['start']} {'au' if fr else 'to'} {truth['window']['end']}.", ""]
    for conv in questions["conversations"]:
        lines += [f"## {conv['id']} – {conv.get('title', '')}", ""]
        if conv.get("goal"):
            lines += [conv["goal"], ""]
        for n, turn in enumerate(conv["turns"], 1):
            lines += [f"**{'Question' if fr else 'Prompt'} {n}**", "", "> " + resolve(turn["prompt"], truth, lang), ""]
            if turn.get("expected"):
                lines += [f"{'Attendu' if fr else 'Expected'} : {resolve(turn['expected'], truth, lang)}", ""]
        for iid in conv.get("incidents", []):
            inc = by_id.get(iid)
            if inc:
                lines += [f"**{'Vérité terrain' if fr else 'Ground truth'} {iid}** ({inc['start_local']}–{inc['end_local']}) : {inc['root_cause']}", "",
                          f"**{'Remédiation' if fr else 'Remediation'}** : {inc['remediation']}", ""]
    (out / "questions.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {out / 'questions.md'}")


def cmd_build(out: Path) -> None:
    scn = json.loads((out / "scenario.json").read_text(encoding="utf-8"))
    summary = json.loads((out / "summary.json").read_text(encoding="utf-8"))
    truth = json.loads((out / "ground_truth.json").read_text(encoding="utf-8"))
    c, ns = scn["customer"], summary["namespace"]
    lang = c.get("language", "fr") if c.get("language", "fr") in INSTRUCTIONS else "en"
    dim = scn.get("business_dimension")
    kpi = summary.get("kpi", "apdex")
    a = truth.get("apdex") or {"satisfied_ms": 0, "frustrated_ms": 0, "target": 0}
    tools = build_tools(scn, summary)
    dim_txt = ((f" et quelles valeurs de {dim.get('label', dim['attribute'])}" if lang == "fr"
                else f" and which {dim.get('label', dim['attribute'])} values") if dim else "")
    kpi_rule, step1 = (x.format(customer=c["name"], t=f"{a['satisfied_ms'] / 1000:g}", f=f"{a['frustrated_ms'] / 1000:g}",
                                target=a["target"], dim_txt=dim_txt,
                                dim_tool=f", {'apdex' if kpi == 'apdex' else 'response_time'}_by_{dim['attribute']}" if dim else "")
                       for x in KPI_TEXT[(lang, kpi)])
    step3, decoy = STEP3[(lang, bool(scn.get("sap")))]
    instructions = INSTRUCTIONS[lang].format(
        step3=step3, decoy=decoy,
        customer=c["name"], system=c.get("system", c["name"]), start=truth["window"]["start"], end=truth["window"]["end"],
        tz=truth["window"]["timezone"], kpi_rule=kpi_rule, step1=step1, attributes=attribute_section(summary, lang),
        correlation=correlation_section(summary, scn, lang))
    system = c.get("system", c["name"])
    agent = {
        "id": f"{ns}-performance-analyst",
        "name": f"{system} – Analyste performance" if lang == "fr" else f"{system} – Performance analyst",
        "description": (f"Analyse les ralentissements de {system} sur trois couches : interface utilisateur, services, cause racine dans les dépendances."
                        if lang == "fr" else
                        f"Investigates {system} slowdowns across three layers: UI, services, root cause in the dependencies."),
        "labels": [ns, "demo"],
        "avatar_color": "#BFDBFF",
        "avatar_symbol": system[:2].upper(),
        "configuration": {"instructions": instructions,
                          "tools": [{"tool_ids": [t["id"] for t in tools] + BUILTIN_WANTED}]},
    }
    (out / "agent.json").write_text(json.dumps({"namespace": ns, "window": truth["window"], "tools": tools, "agent": agent},
                                               ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Wrote {out / 'agent.json'}: {len(tools)} ES|QL tools, agent id {agent['id']}")


# --------------------------------------------------------------------------- test-tools
def cmd_test_tools(out: Path, cfg: dict) -> None:
    spec = json.loads((out / "agent.json").read_text(encoding="utf-8"))
    scn = json.loads((out / "scenario.json").read_text(encoding="utf-8"))
    failures = 0
    for tool in spec["tools"]:
        params = [{"start": spec["window"]["start"]}, {"end": spec["window"]["end"]}]
        for name in tool["configuration"]["params"]:
            if name in ("service", "system"):
                params.append({name: scn["services"][0]["name"]})
            if name in ("trace_id", "value"):
                field = "trace_id" if name == "trace_id" else tool["configuration"]["query"].split("WHERE ")[1].split(" ==")[0]
                rows = esql(cfg, f"FROM traces-*-{spec['namespace']} | WHERE {field} IS NOT NULL | KEEP {field} | LIMIT 1")
                params.append({name: rows[0][field] if rows else "none"})
        url = need(cfg, "ELASTICSEARCH_URL") + "/_query"
        status, raw = http("POST", url, api_key_header(cfg), {"query": tool["configuration"]["query"], "params": params})
        if status != 200:
            failures += 1
            print(f"FAIL {tool['id']}: {raw.decode('utf-8', 'replace')[:400]}")
            continue
        rows = len(as_json(raw).get("values", []))
        flag = "ok  " if rows else "EMPTY"
        failures += 0 if rows else 1
        print(f"{flag} {tool['id']:<40} {rows} rows")
    if failures:
        die(f"{failures} tool(s) failed or returned nothing over the whole dataset window. Fix before deploying.")
    print("All tool queries run and return data.")


# --------------------------------------------------------------------------- deploy / delete
def kibana(cfg: dict, method: str, path: str, body=None, timeout: int = 60, retries: int = 2):
    base = need(cfg, "KIBANA_URL")
    space = cfg.get("KIBANA_SPACE", "").strip()
    url = f"{base}/s/{space}{path}" if space else f"{base}{path}"
    status, raw = http(method, url, {**api_key_header(cfg), "kbn-xsrf": "true", "Content-Type": "application/json"},
                       body, timeout=timeout, retries=retries)
    return status, as_json(raw)


def existing_tool_ids(cfg: dict) -> set[str]:
    status, res = kibana(cfg, "GET", "/api/agent_builder/tools")
    if status != 200:
        die(f"cannot list Agent Builder tools ({status}): {json.dumps(res)[:500]}\n"
            "Check KIBANA_URL, the API key privileges and that Agent Builder is enabled in the project.")
    items = res.get("results", res) if isinstance(res, dict) else res
    return {t["id"] for t in items if isinstance(t, dict) and "id" in t}


def upsert(cfg: dict, kind: str, obj: dict, exists: bool) -> None:
    path = f"/api/agent_builder/{kind}"
    if exists:
        body = {k: v for k, v in obj.items() if k not in ("id", "type")}
        status, res = kibana(cfg, "PUT", f"{path}/{obj['id']}", body)
        if status == 200:
            print(f"updated {kind[:-1]} {obj['id']}")
            return
        kibana(cfg, "DELETE", f"{path}/{obj['id']}")
    status, res = kibana(cfg, "POST", path, obj)
    if status not in (200, 201):
        die(f"cannot create {kind[:-1]} {obj['id']} ({status}): {json.dumps(res, ensure_ascii=False)[:800]}")
    print(f"created {kind[:-1]} {obj['id']}")


def cmd_deploy(out: Path, cfg: dict) -> None:
    spec = json.loads((out / "agent.json").read_text(encoding="utf-8"))
    present = existing_tool_ids(cfg)
    for tool in spec["tools"]:
        upsert(cfg, "tools", tool, tool["id"] in present)
    agent = json.loads(json.dumps(spec["agent"]))
    ids = agent["configuration"]["tools"][0]["tool_ids"]
    own = {t["id"] for t in spec["tools"]}
    kept = [i for i in ids if i in own or i in present]
    dropped = [i for i in ids if i not in kept]
    if dropped:
        print(f"built-in tools not available in this project, left out: {', '.join(dropped)}")
    agent["configuration"]["tools"][0]["tool_ids"] = kept
    status, _ = kibana(cfg, "GET", f"/api/agent_builder/agents/{agent['id']}")
    upsert(cfg, "agents", agent, status == 200)
    print(f"Agent ready: open Kibana > Agents and pick '{agent['name']}'.")


def cmd_delete(out: Path, cfg: dict) -> None:
    spec = json.loads((out / "agent.json").read_text(encoding="utf-8"))
    status, _ = kibana(cfg, "DELETE", f"/api/agent_builder/agents/{spec['agent']['id']}")
    print(f"agent {spec['agent']['id']}: {status}")
    for tool in spec["tools"]:
        status, _ = kibana(cfg, "DELETE", f"/api/agent_builder/tools/{tool['id']}")
        print(f"tool {tool['id']}: {status}")


# --------------------------------------------------------------------------- rehearse
def tool_calls(res: dict) -> list[str]:
    used = []
    for step in res.get("steps", []) or []:
        if isinstance(step, dict):
            tid = step.get("tool_id") or (step.get("tool_call") or {}).get("tool_id")
            if tid:
                used.append(tid)
    return used


def cmd_rehearse(out: Path, cfg: dict, only: str | None) -> None:
    spec = json.loads((out / "agent.json").read_text(encoding="utf-8"))
    questions, truth, lang = load_questions(out)
    lines = [f"# Rehearsal {datetime.now().strftime('%Y-%m-%d %H:%M')}", "",
             f"Agent `{spec['agent']['id']}`", ""]
    total = passed = 0
    for conv in questions["conversations"]:
        if only and conv["id"] != only:
            continue
        lines += [f"## {conv['id']} {conv.get('title', '')}", ""]
        conv_id = None
        for n, turn in enumerate(conv["turns"], 1):
            prompt = resolve(turn["prompt"], truth, lang)
            body = {"input": prompt, "agent_id": spec["agent"]["id"]}
            if conv_id:
                body["conversation_id"] = conv_id
            t0 = time.time()
            status, res = kibana(cfg, "POST", "/api/agent_builder/converse", body, timeout=600, retries=0)
            took = time.time() - t0
            if status != 200:
                die(f"converse failed ({status}) on {conv['id']} turn {n}: {json.dumps(res, ensure_ascii=False)[:800]}")
            conv_id = res.get("conversation_id", conv_id)
            answer = (res.get("response") or {}).get("message", "") or json.dumps(res, ensure_ascii=False)[:2000]
            low = answer.lower()
            missing = [k for k in turn.get("expect_all", []) if k.lower() not in low]
            any_of = turn.get("expect_any", [])
            ok = not missing and (not any_of or any(k.lower() in low for k in any_of))
            total += 1
            passed += ok
            print(f"{'PASS' if ok else 'FAIL'} {conv['id']} turn {n} ({took:.0f} s)")
            lines += [f"### Turn {n}: {'PASS' if ok else 'FAIL'} ({took:.0f} s)", "", f"**Prompt:** {prompt}", ""]
            used = tool_calls(res)
            if used:
                lines += [f"**Tools called:** {', '.join(used)}", ""]
            if missing:
                lines += [f"**Missing expected terms:** {', '.join(missing)}", ""]
            if any_of and not any(k.lower() in low for k in any_of):
                lines += [f"**None of the expected terms found:** {', '.join(any_of)}", ""]
            lines += ["**Answer:**", "", answer, ""]
    lines.insert(3, f"Result: {passed}/{total} turns contain the expected terms.")
    (out / "rehearsal.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"{passed}/{total} turns passed. Read {out / 'rehearsal.md'}: keyword checks do not replace reading the answers.")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=("build", "questions", "test-tools", "deploy", "rehearse", "delete"))
    ap.add_argument("out")
    ap.add_argument("--env-file")
    ap.add_argument("--only", help="rehearse a single conversation id")
    args = ap.parse_args()
    out = Path(args.out)
    if not (out / "summary.json").exists():
        die(f"{out} is not an output directory of generate.py")
    if args.command == "build":
        if json.loads((out / "summary.json").read_text(encoding="utf-8")).get("model") == "deal_flow":
            import deal_flow
            return deal_flow.build_agent(out)
        return cmd_build(out)
    if args.command == "questions":
        return cmd_questions(out)
    if not (out / "agent.json").exists():
        die("run 'agent.py build' first")
    cfg = load_env(args.env_file)
    {"test-tools": lambda: cmd_test_tools(out, cfg), "deploy": lambda: cmd_deploy(out, cfg),
     "delete": lambda: cmd_delete(out, cfg), "rehearse": lambda: cmd_rehearse(out, cfg, args.only)}[args.command]()


if __name__ == "__main__":
    main()
