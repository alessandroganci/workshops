#!/usr/bin/env python3
"""Summary slides for a deal lifecycle demo ("model": "deal_flow"), as PowerPoint and as a web page.

    python3 deal_summary.py out/        writes out/summary-deck.pptx (needs python-pptx) and out/summary-deck.html

Reached through summary_deck.py and summary_pptx.py when the scenario is a deal_flow one. Content: context,
systems and attributes, the chain diagram with its correlation, the dataset, the day (descent time and lost deals),
one slide per incident with its questions and expected answers, the decoys and the remaining questions.
The .pptx uses Arial at 10 x 5.625 in so a Google Slides conversion keeps the layout; expected answers and evidence
are in the speaker notes. The data is synthetic and the slides say so.
"""
from __future__ import annotations

import html
import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from agent import resolve  # noqa: E402

INK, MUTED, ACCENT, INCIDENT, OK = "101C3F", "55627F", "0B64DD", "C4307A", "009B90"


def load(out: Path):
    j = lambda n: json.loads((out / n).read_text(encoding="utf-8"))       # noqa: E731
    q = j("questions.json")["conversations"] if (out / "questions.json").exists() else []
    return j("scenario.json"), j("summary.json"), j("ground_truth.json"), q


def num(n) -> str:
    return f"{n:,}".replace(",", "\u202f")


def dec(v) -> str:
    return str(v).replace(".", ",")


def content(out: Path) -> dict:
    """Everything both renderings need, computed once."""
    scn, summary, truth, qs = load(out)
    c, k = scn["customer"], scn["kpi"]
    day = resolve("{date}", truth, "fr")
    weekday = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"][datetime.fromisoformat(truth["window"]["start"]).weekday()]
    attrs = {a["attribute"]: a for a in summary["custom_attributes"]}
    p = summary["attribute_prefix"]
    key_attrs = {
        "Fast": [f"{p}.deal.id", f"{p}.desk", f"{p}.product_type", f"{p}.user"],
        "Murex FO": [f"{p}.deal.id", f"{p}.desk", f"{p}.deal.status", f"{p}.deal.status_displayed"],
        "Service Queue": [f"{p}.deal.id", f"{p}.queue.wait_s", f"{p}.queue.lag_messages"],
        "FOBO": [f"{p}.deal.id", f"{p}.target_system"],
        "Calypso": [f"{p}.deal.id", f"{p}.broker", f"{p}.descent_time_min"],
        "Murex Back": [f"{p}.deal.id", f"{p}.descent_time_min"],
        "HF Trader": [f"{p}.deal.id", f"{p}.broker", f"{p}.descent_time_min"],
        "OTC WKF": [f"{p}.deal.id", f"{p}.deal.status"],
    }
    systems = []
    for s in scn["services"]:
        ks = key_attrs.get(s["name"], [f"{p}.deal.id"])
        cu = [x.split(".", 1)[1] for x in ks if attrs.get(x, {}).get("source") == "customer"]
        inf = [x.split(".", 1)[1] for x in ks if attrs.get(x, {}).get("source") != "customer"]
        systems.append({"name": s["name"], "layer": s["layer"], "tech": s["technology"], "version": s["version"],
                        "customer": cu, "inferred": inf})
    inc = {i["id"]: i for i in truth["incidents"]}
    i1 = next(i for i in truth["incidents"] if i["type"] == "queue_slowdown")
    i2 = next(i for i in truth["incidents"] if i["type"] == "status_not_persisted")

    def conv(cid):
        cv = next((x for x in qs if x["id"] == cid), None)
        if not cv:
            return None
        return {"id": cv["id"], "title": cv["title"], "goal": cv.get("goal", ""),
                "turns": [(resolve(t["prompt"], truth, "fr"), resolve(t.get("expected", ""), truth, "fr")) for t in cv["turns"]]}
    tl = [r for r in summary["timeline_15min"] if "06:00" <= r["t"][11:] <= "22:45"]
    b = truth["descent"]["baseline"]
    return {
        "c": c, "k": k, "day": f"{weekday} {day}", "systems": systems, "i1": i1, "i2": i2, "truth": truth, "summary": summary,
        "timeline": tl, "baseline": b, "desks": scn["business_dimension"]["values"],
        "q": {cv["id"]: conv(cv["id"]) for cv in qs},
        "inc_convs": {iid: [cv["id"] for cv in qs if iid in cv.get("incidents", []) and len(cv["incidents"]) == 1] for iid in inc},
        "streams": [(n, v) for n, v in summary["events_by_data_stream"].items()],
        "lost_isolated": [d for d in truth["decoys"] if "FOBO" in d],
        "decoys": [d for d in truth["decoys"] if "FOBO" not in d],
    }


TITLE_I1 = "Fin de matinée, tous les desks descendent en plus de 30 min : Service Queue {v} ne suit plus"
TITLE_I2 = "L’après-midi, {n} deals de {desk} disparaissent après la validation Middle Office"
STREAM_LABEL = {"traces": "Traces de bout en bout (un trace_id par deal)", "deal": "Cycle de vie des deals (une ligne par étape)",
                "app": "Logs techniques (déploiements, file Kafka, erreurs)", "metrics": "Métriques (lag Kafka, CPU)"}


def stream_label(name: str) -> str:
    for key, lab in STREAM_LABEL.items():
        if f".{key}." in name or name.startswith(key) or f"{key}.otel" in name:
            return lab
    return name


# ------------------------------------------------------------------------------------------------ PowerPoint
def build_pptx(out: Path) -> Path:
    from summary_pptx import Deck, rgb
    from pptx.chart.data import CategoryChartData
    from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_MARKER_STYLE
    from pptx.enum.text import PP_ALIGN
    from pptx.util import Inches, Pt

    x = content(out)
    c, k, i1, i2, b = x["c"], x["k"], x["i1"], x["i2"], x["baseline"]
    d = Deck()
    d.title_slide(f"{c['name']}, {c['system']} : démonstration Elastic AI",
                  f"{x['day']}. Données synthétiques, modélisées d’après la phase de découverte.")
    d.notes("Toutes les données sont synthétiques : noms de systèmes réels, valeurs générées. Aucune donnée client.")

    # context
    d.slide("Un deal doit descendre du Front au Back Office en moins de 30 minutes")
    d.text(0.5, 1.3, 5.3, 3.9, c["context"][:4], 12, bullets=True, space=7)
    d.text(6.1, 1.3, 3.4, 0.3, [("Parcours d’investigation de l’agent", True)], 11, MUTED)
    y = 1.62
    for i, step in enumerate(c["investigation_path"][:5]):
        d.card(6.1, y, 3.4, 0.5, step, klass="hub", size=10, align=PP_ALIGN.LEFT)
        if i < 4:
            d.arrow(7.8, y + 0.5, 7.8, y + 0.62)
        y += 0.62
    d.text(6.1, y + 0.05, 3.4, 0.6, [f"Règle : ≤ {k['descent_ok_min']} min OK, {k['descent_ok_min']}–{k['descent_critical_min']} min dégradé, "
                                     f"> {k['descent_critical_min']} min incident ; {k['lost_critical_count']} deals perdus depuis plus "
                                     f"d’{k['lost_age_min'] // 60} h = critique"], 10, MUTED)
    d.notes(c["context"][-1])

    # systems
    for title, rows in (("Front Office, Middle Office et middleware : quatre systèmes hétérogènes", x["systems"][:4]),
                        ("Back Office : trois branches selon le produit, plus le workflow OTC", x["systems"][4:])):
        d.slide(title)
        tab = [["Système", "Couche", "Technologie", "Attributs clés"]]
        for s in rows:
            parts = ([f"Client : {', '.join(s['customer'])}"] if s["customer"] else []) + \
                    ([f"Déduit : {', '.join(s['inferred'])}"] if s["inferred"] else [])
            tab.append([s["name"], s["layer"], s["tech"], ". ".join(parts)])
        d.table(0.5, 1.35, tab, [1.55, 1.35, 2.65, 3.45], size=11)
        d.notes("« Client » : attribut cité pendant la découverte (deal id interne, desk, type de produit, broker). "
                "« Déduit » : attribut posé par analogie avec des chaînes comparables, à confirmer avec le client.")

    # diagram
    d.slide("Le trace_id et le deal id traversent toute la chaîne, Kafka et TIBCO compris")
    bw, bh = 1.55, 0.62
    chain = [("Fast", "Front Office"), ("Murex FO", "Middle Office"), ("Service Queue", "Kafka deals.validated"), ("FOBO", "TIBCO, routage")]
    for n, (name, sub) in enumerate(chain):
        xx = 0.45 + n * 1.95
        d.card(xx, 2.3, bw, bh, name, sub, klass="tr", size=11, sub_size=9)
        if n:
            d.arrow(xx - 0.4, 2.3 + bh / 2, xx, 2.3 + bh / 2)
    bo = [("Calypso", "Dérivés listés", "Brokers"), ("Murex Back", "OTC", "OTC WKF"), ("HF Trader", "Haute fréquence", "Brokers")]
    fx = 0.45 + 3 * 1.95 + bw
    for n, (name, sub, nxt) in enumerate(bo):
        yy = 1.3 + n * 1.05
        d.card(8.0, yy, 1.55, bh, name, sub, klass="tr", size=11, sub_size=9)
        d.arrow(fx, 2.3 + bh / 2, 8.0, yy + bh / 2)
        d.text(8.0, yy + bh + 0.02, 1.55, 0.25, [f"→ {nxt}"], 9, MUTED)
    d.text(0.45, 3.55, 7.2, 1.6, [
        ("Ce qui relie les systèmes", True),
        "trace_id OpenTelemetry propagé de Fast jusqu’au Back Office, à travers Kafka et TIBCO.",
        f"Clé métier {x['summary']['attribute_prefix']}.deal.id (identifiant deal interne) sur chaque span et chaque log.",
        "Une ligne de cycle de vie par étape : statut, attente depuis l’étape précédente, temps de descente à l’arrivée."],
        11, space=4)
    d.notes("Corrélation confirmée par le client : le trace_id survit à Kafka et à TIBCO. Le deal id permet en plus de "
            "suivre un deal qui s’arrête en route : ses lignes s’arrêtent au dernier système atteint.")

    # dataset
    s = x["summary"]
    d.slide(f"{num(s['total_events'])} événements synthétiques, {num(s['deals'])} deals sur 24 heures")
    rows = [["Data stream", "Contenu", "Événements"]] + [[n, stream_label(n), num(v)] for n, v in x["streams"]]
    d.table(0.5, 1.35, rows, [3.6, 3.9, 1.5], size=11, right=(2,))
    d.text(0.5, 3.45, 9, 1.4, [
        f"Temps de descente en temps normal : {dec(b['avg_min'])} min en moyenne, p95 {dec(b['p95_min'])} min.",
        f"Desks : {', '.join(x['desks'])}.",
        f"Navigation des utilisateurs (List Deal, Deal Status…) en complément, pour un total exact de {num(s['total_events'])} événements."],
        11, MUTED, space=4)
    d.notes(f"Fenêtre : {x['truth']['window']['start']} → {x['truth']['window']['end']}. Namespace {s['namespace']}.")

    # the day
    d.slide("Deux incidents : une descente lente le matin, des deals perdus l’après-midi")
    hours = {}
    for r in x["timeline"]:
        hh = r["t"][11:13]
        h = hours.setdefault(hh, {"n": 0, "sum": 0.0, "lost": 0})
        if r["avg_min"] is not None:
            h["n"] += r["deals"]
            h["sum"] += r["avg_min"] * r["deals"]
        h["lost"] += r["lost"]
    cats = [f"{int(hh)}h" for hh in hours]
    cd = CategoryChartData()
    cd.categories = cats
    cd.add_series("Temps de descente moyen par heure (min)", [round(h["sum"] / h["n"], 1) if h["n"] else 0 for h in hours.values()])
    cd.add_series(f"Seuil {k['descent_ok_min']} min", [k["descent_ok_min"]] * len(cats))
    gf = d.s.shapes.add_chart(XL_CHART_TYPE.LINE, Inches(0.4), Inches(1.25), Inches(9.2), Inches(2.25), cd)
    ch = gf.chart
    ch.has_title = False
    ch.has_legend, ch.legend.position, ch.legend.include_in_layout = True, XL_LEGEND_POSITION.TOP, False
    ch.legend.font.size, ch.legend.font.name = Pt(9), "Arial"
    for ser, col, w in zip(ch.plots[0].series, (ACCENT, INCIDENT), (2.25, 1)):
        ser.smooth = False
        ser.format.line.color.rgb = rgb(col)
        ser.format.line.width = Pt(w)
        ser.marker.style = XL_MARKER_STYLE.NONE
    for ax in (ch.category_axis, ch.value_axis):
        ax.tick_labels.font.size, ax.tick_labels.font.name = Pt(8), "Arial"
        ax.tick_labels.font.color.rgb = rgb(MUTED)
    ch.value_axis.major_gridlines.format.line.color.rgb = rgb("E3E8F1")
    cd2 = CategoryChartData()
    cd2.categories = cats
    cd2.add_series("Deals perdus (par heure de validation)", [h["lost"] for h in hours.values()])
    gf2 = d.s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(0.4), Inches(3.55), Inches(9.2), Inches(1.85), cd2)
    ch2 = gf2.chart
    ch2.has_title = False
    ch2.has_legend, ch2.legend.position, ch2.legend.include_in_layout = True, XL_LEGEND_POSITION.TOP, False
    ch2.legend.font.size, ch2.legend.font.name = Pt(9), "Arial"
    ch2.plots[0].series[0].format.fill.solid()
    ch2.plots[0].series[0].format.fill.fore_color.rgb = rgb(INCIDENT)
    ch2.plots[0].gap_width = 40
    for ax in (ch2.category_axis, ch2.value_axis):
        ax.tick_labels.font.size, ax.tick_labels.font.name = Pt(8), "Arial"
        ax.tick_labels.font.color.rgb = rgb(MUTED)
    ch2.value_axis.major_gridlines.format.line.color.rgb = rgb("E3E8F1")
    from lxml import etree
    for chx in (ch, ch2):
        cat = chx.category_axis._element
        ns = "http://schemas.openxmlformats.org/drawingml/2006/chart"
        anchor = cat.find(f"{{{ns}}}noMultiLvlLbl")
        for tag, val in (("tickLblSkip", "1"), ("tickMarkSkip", "1")):
            el = etree.Element(f"{{{ns}}}{tag}")
            el.set("val", val)
            if anchor is not None:
                anchor.addprevious(el)
            else:
                cat.append(el)
        chx.category_axis.tick_labels.font.size = Pt(8)
        txpr = cat.find(f"{{{ns}}}txPr")
        if txpr is not None:
            bp = txpr.find("{http://schemas.openxmlformats.org/drawingml/2006/main}bodyPr")
            if bp is not None:
                bp.set("rot", "0")
    d.notes(f"{i1['id']} {i1['start_local']}–{i1['end_local']} : descente moyenne {dec(i1['descent']['avg_min'])} min. "
            f"{i2['id']} {i2['start_local']}–{i2['end_local']} : {i2['lost_deals']} deals perdus, critique à partir de "
            f"{i2['critical_from_local']}. Courbe par heure d’arrivée en Back Office, barres par heure de validation trader.")

    # incidents
    for inc, title in ((i1, TITLE_I1.format(v=i1["versions"]["new"])),
                       (i2, TITLE_I2.format(n=i2["lost_deals"], desk=i2.get("desk", "")))):
        d.slide(title)
        if inc["type"] == "queue_slowdown":
            seen = (f"{inc['start_local']}–{inc['impact_end_local']} : descente moyenne {dec(inc['descent']['avg_min'])} min "
                    f"(p95 {dec(inc['descent']['p95_min'])}, max {dec(inc['descent']['max_min'])}), "
                    f"{inc['descent']['over_critical']} deals au-delà d’une heure, tous desks.")
            cause = (f"Service Queue {inc['versions']['new']} déployé à {inc['start_local']} : cache d’enrichissement désactivé, "
                     f"2,5 à 5 s par deal au lieu de 35 ms. File jusqu’à {inc['peak_lag_messages']} messages, le plus ancien "
                     f"depuis {dec(round(inc['peak_oldest_message_min']))} min. Rollback {inc['versions']['previous']} à {inc['end_local']}.")
        else:
            seen = (f"{inc['first_lost_local']}–{inc['last_lost_local']} : {inc['lost_deals']} deals de {inc['desk']} validés "
                    f"mais jamais reçus en Back Office ({', '.join(f'{v} {k2}' for k2, v in inc['lost_by_product'].items())}). "
                    f"Critique à partir de {inc['critical_from_local']}. Les autres desks descendent en "
                    f"{dec(inc['other_desks_descent']['avg_min'])} min.")
            cause = (f"Patch Murex FO {inc['versions']['new']} à {inc['start_local']} : pas de mapping de workflow pour le desk, "
                     f"exception interceptée, écran « VALIDATED » mais statut PENDING_MO, deal jamais envoyé. Rollback à "
                     f"{inc['end_local']} ; les deals perdus restent à rejouer.")
        d.text(0.5, 1.3, 4.3, 0.25, [("Ce que voient les utilisateurs", True)], 11, MUTED)
        d.text(0.5, 1.55, 4.3, 1.1, [seen], 11)
        d.text(0.5, 2.75, 4.3, 0.25, [("Cause racine", True)], 11, MUTED)
        d.text(0.5, 3.0, 4.3, 1.4, [cause], 11)
        d.text(0.5, 4.45, 4.3, 0.25, [("Remédiation", True)], 11, MUTED)
        rem = ""
        for sent in inc["remediation"].split(". "):
            if len(rem) + len(sent) > 200 and rem:
                break
            rem += sent.rstrip(".") + ". "
        d.text(0.5, 4.7, 4.3, 0.75, [rem.strip()], 9.5)
        d.text(5.15, 1.3, 4.35, 0.25, [("Questions posées à l’agent", True)], 11, MUTED)
        yy, notes = 1.58, []
        for cid in x["inc_convs"].get(inc["id"], []):
            cv = x["q"][cid]
            for n, (prompt, exp) in enumerate(cv["turns"], 1):
                h = 0.26 + 0.17 * (len(prompt) // 62)
                if yy + h > 5.35:
                    break
                d.text(5.15, yy, 4.35, h, [f"{cid}.{n}  {prompt}"], 9.5)
                yy += h + 0.06
                notes.append(f"{cid}.{n} {prompt}\nAttendu : {exp}")
        d.notes("\n\n".join(notes) + "\n\nVérité terrain : " + inc["root_cause"] + "\n\nPreuves :\n" +
                "\n".join(f"- {e['stream']} : {e['fact']}" for e in inc["evidence"]) + "\n\nRemédiation : " + inc["remediation"])

    # decoys
    d.slide("Les fausses pistes que l’agent doit écarter")
    d.text(0.5, 1.3, 9, 2.6, x["decoys"], 12, bullets=True, space=8)
    d.text(0.5, 3.95, 9, 0.3, [("Deux pertes isolées, sous le seuil critique", True)], 11, MUTED)
    d.text(0.5, 4.25, 9, 1.2, x["lost_isolated"], 10, bullets=True, space=4)
    d.notes("Leurres demandés pendant la découverte : un traitement de nuit normal et un pic habituel. "
            "Le pic de l’ouverture américaine tombe pendant les pertes de l’après-midi : c’est le cas combiné de la démo.")

    # other questions
    other = [cid for cid in x["q"] if not any(cid in v for v in x["inc_convs"].values())]
    for start in range(0, len(other), 3):
        d.slide("Les autres questions de la démonstration")
        yy, notes = 1.3, []
        for cid in other[start:start + 3]:
            cv = x["q"][cid]
            prompt, exp = cv["turns"][0]
            d.text(0.5, yy, 9, 0.28, [(f"{cid}. {cv['title']}", True)], 11)
            d.text(0.5, yy + 0.3, 9, 0.5, [prompt], 10)
            d.text(0.5, yy + 0.8, 9, 0.5, [f"Attendu : {exp}"], 9, MUTED)
            yy += 1.38
            notes.append(f"{cid} {cv['title']}\n{prompt}\nAttendu : {exp}")
        d.notes("\n\n".join(notes))
    path = out / "summary-deck.pptx"
    d.prs.save(path)
    return path


# ------------------------------------------------------------------------------------------------ web page
def svg_day(x) -> str:
    tl, k = x["timeline"], x["k"]
    W, H, L, R, T, B = 920, 300, 44, 12, 14, 52
    n = len(tl)
    xs = lambda i: L + i * (W - L - R) / max(1, n - 1)                    # noqa: E731
    ymax = int(max(75, max((r["max_min"] or 0) for r in tl) // 15 * 15 + 15))
    ys = lambda v: T + (H - T - B) * (1 - v / ymax)                        # noqa: E731
    lmax = max(1, max(r["lost"] for r in tl))
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Temps de descente et deals perdus par quart d’heure">']
    for i1 in (x["i1"], x["i2"]):
        a = next((j for j, r in enumerate(tl) if r["t"][11:16] >= i1["start_local"]), 0)
        e = next((j for j, r in enumerate(tl) if r["t"][11:16] >= i1["end_local"]), n - 1)
        parts.append(f'<rect x="{xs(a):.1f}" y="{T}" width="{xs(e) - xs(a):.1f}" height="{H - T - B}" class="band"/>')
        parts.append(f'<text x="{xs(a) + 4:.1f}" y="{T + 12}" class="lab">{html.escape(i1["id"])}</text>')
    for v in range(0, ymax + 1, 15):
        parts.append(f'<line x1="{L}" x2="{W - R}" y1="{ys(v):.1f}" y2="{ys(v):.1f}" class="grid"/>'
                     f'<text x="{L - 6}" y="{ys(v) + 4:.1f}" class="ax" text-anchor="end">{v}</text>')
    bw = (W - L - R) / n * 0.7
    for i, r in enumerate(tl):
        if r["lost"]:
            h = (H - T - B) * 0.45 * r["lost"] / lmax
            parts.append(f'<rect x="{xs(i) - bw / 2:.1f}" y="{H - B - h:.1f}" width="{bw:.1f}" height="{h:.1f}" class="lost"/>')
    parts.append(f'<line x1="{L}" x2="{W - R}" y1="{ys(k["descent_ok_min"]):.1f}" y2="{ys(k["descent_ok_min"]):.1f}" class="thr"/>')
    parts.append(f'<text x="{W - R}" y="{ys(k["descent_ok_min"]) - 4:.1f}" class="ax" text-anchor="end">seuil {k["descent_ok_min"]} min</text>')
    pts = " ".join(f"{xs(i):.1f},{ys(r['avg_min']):.1f}" for i, r in enumerate(tl) if r["avg_min"] is not None)
    parts.append(f'<polyline points="{pts}" class="avg"/>')
    for i, r in enumerate(tl):
        if r["t"][14:16] == "00" and int(r["t"][11:13]) % 2 == 0:
            parts.append(f'<text x="{xs(i):.1f}" y="{H - B + 16}" class="ax" text-anchor="middle">{r["t"][11:16]}</text>')
    parts.append(f'<g class="ax"><rect x="{L}" y="{H - 18}" width="14" height="3" class="avgk"/><text x="{L + 20}" y="{H - 13}">Temps de descente moyen (min), par heure d’arrivée</text>'
                 f'<rect x="{L + 330}" y="{H - 22}" width="10" height="10" class="lost"/><text x="{L + 346}" y="{H - 13}">Deals perdus, par heure de validation</text></g>')
    parts.append("</svg>")
    return "".join(parts)


def svg_chain() -> str:
    box = lambda x, y, t, s: (f'<g><rect x="{x}" y="{y}" width="140" height="54" rx="8" class="node"/>'      # noqa: E731
                              f'<text x="{x + 70}" y="{y + 23}" class="nt" text-anchor="middle">{t}</text>'
                              f'<text x="{x + 70}" y="{y + 41}" class="ns" text-anchor="middle">{s}</text></g>')
    arrow = lambda x1, y1, x2, y2: f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" class="edge" marker-end="url(#ah)"/>'   # noqa: E731
    p = ['<svg viewBox="0 0 900 250" role="img" aria-label="Chaîne Front To Back"><defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" '
         'markerWidth="7" markerHeight="7" orient="auto"><path d="M0,0 L10,5 L0,10 z" class="ahead"/></marker></defs>']
    chain = [("Fast", "Front Office"), ("Murex FO", "Middle Office"), ("Service Queue", "Kafka deals.validated"), ("FOBO", "TIBCO, routage")]
    for i, (t, s) in enumerate(chain):
        p.append(box(10 + i * 175, 98, t, s))
        if i:
            p.append(arrow(10 + i * 175 - 35, 125, 10 + i * 175 - 2, 125))
    for j, (t, s, nx) in enumerate((("Calypso", "Dérivés listés", "→ brokers"), ("Murex Back", "OTC", "→ OTC WKF"), ("HF Trader", "Haute fréquence", "→ brokers"))):
        y = 10 + j * 85
        p.append(box(745, y, t, s))
        p.append(arrow(675, 125, 743, y + 27))
        p.append(f'<text x="815" y="{y + 70}" class="ns" text-anchor="middle">{nx}</text>')
    p.append("</svg>")
    return "".join(p)


def build_html(out: Path) -> Path:
    x = content(out)
    c, k, i1, i2, b, s = x["c"], x["k"], x["i1"], x["i2"], x["baseline"], x["summary"]
    e = html.escape

    def qa(cid, only_first=False):
        cv = x["q"].get(cid)
        if not cv:
            return ""
        turns = cv["turns"][:1] if only_first else cv["turns"]
        return (f'<div class="conv"><h4>{e(cid)} · {e(cv["title"])}</h4>' +
                "".join(f'<details><summary>{e(pr)}</summary><p class="exp">Attendu : {e(ex)}</p></details>' for pr, ex in turns) +
                "</div>")

    def incident(inc, title, seen, cause):
        convs = "".join(qa(cid) for cid in x["inc_convs"].get(inc["id"], []))
        ev = "".join(f"<li><code>{e(v['stream'])}</code> {e(v['fact'])}</li>" for v in inc["evidence"])
        return (f'<section class="slide" id="{e(inc["id"].lower())}"><p class="kicker">{e(inc["id"])} · {e(inc["start_local"])}–{e(inc["end_local"])}</p>'
                f'<h2>{e(title)}</h2><div class="cols"><div><h3>Ce que voient les utilisateurs</h3><p>{e(seen)}</p>'
                f'<h3>Cause racine</h3><p>{e(cause)}</p><h3>Remédiation</h3><p>{e(inc["remediation"])}</p>'
                f'<details class="ev"><summary>Preuves dans les données</summary><ul>{ev}</ul></details></div>'
                f'<div><h3>Questions posées à l’agent</h3>{convs}</div></div></section>')

    seen1 = (f"De {i1['start_local']} à {i1['impact_end_local']}, descente moyenne {dec(i1['descent']['avg_min'])} min (p95 "
             f"{dec(i1['descent']['p95_min'])}, max {dec(i1['descent']['max_min'])}) contre {dec(b['avg_min'])} min d’habitude ; "
             f"{i1['descent']['over_critical']} deals au-delà d’une heure. Tous les desks et toutes les branches Back Office sont touchés.")
    cause1 = (f"Service Queue {i1['versions']['new']} déployé à {i1['start_local']} désactive le cache d’enrichissement : 2,5 à 5 s par "
              f"deal au lieu de 35 ms. La file deals.validated monte jusqu’à {i1['peak_lag_messages']} messages, le plus ancien depuis "
              f"{dec(round(i1['peak_oldest_message_min']))} min. Rollback en {i1['versions']['previous']} à {i1['end_local']}.")
    seen2 = (f"{i2['lost_deals']} deals de {i2['desk']} validés entre {i2['first_lost_local']} et {i2['last_lost_local']} n’arrivent "
             f"jamais en Back Office ({', '.join(f'{v} {k2}' for k2, v in i2['lost_by_product'].items())}). Seuil critique à "
             f"{i2['critical_from_local']}. Les autres desks descendent normalement ({dec(i2['other_desks_descent']['avg_min'])} min).")
    cause2 = (f"Le patch Murex FO {i2['versions']['new']} ({i2['start_local']}) n’a pas de mapping de workflow pour le desk : la "
              f"transition vers VALIDATED est rejetée par une exception interceptée, l’écran affiche « VALIDATED » mais le statut "
              f"reste PENDING_MO et le deal n’est jamais envoyé. Rollback à {i2['end_local']}.")
    other = [cid for cid in x["q"] if not any(cid in v for v in x["inc_convs"].values())]
    sysrows = "".join(f"<tr><td><b>{e(sy['name'])}</b></td><td>{e(sy['layer'])}</td><td>{e(sy['tech'])}</td><td>"
                      + (f"<span class='tag cu'>Client</span> {e(', '.join(sy['customer']))} " if sy["customer"] else "")
                      + (f"<span class='tag inf'>Déduit</span> {e(', '.join(sy['inferred']))}" if sy["inferred"] else "")
                      + "</td></tr>" for sy in x["systems"])
    streams = "".join(f"<tr><td><code>{e(n)}</code></td><td>{e(stream_label(n))}</td><td class='r'>{num(v)}</td></tr>" for n, v in x["streams"])
    path_steps = "".join(f"<li>{e(st)}</li>" for st in c["investigation_path"])
    page = f"""<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{e(c['name'])} · {e(c['system'])} · démo Elastic AI</title>
<style>
:root{{--bg:#f6f8fc;--surface:#ffffff;--ink:#101c3f;--muted:#55627f;--line:#d5dce9;--accent:#0b64dd;--inc:#c4307a;--ok:#009b90;--band:rgba(196,48,122,.08);
color-scheme:light;box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}}
@media (prefers-color-scheme:dark){{:root:not([data-theme="light"]){{--bg:#0d1326;--surface:#151d36;--ink:#e8edf8;--muted:#a3aec7;--line:#2b3656;--accent:#5b9dff;--inc:#ff6fae;--ok:#3fd1c4;--band:rgba(255,111,174,.12);color-scheme:dark}}}}
:root[data-theme="dark"]{{--bg:#0d1326;--surface:#151d36;--ink:#e8edf8;--muted:#a3aec7;--line:#2b3656;--accent:#5b9dff;--inc:#ff6fae;--ok:#3fd1c4;--band:rgba(255,111,174,.12);color-scheme:dark}}
html{{scroll-padding-top:env(safe-area-inset-top,0px)}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:16px/1.55 "IBM Plex Sans",system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}}
main{{max-width:1080px;margin:0 auto;padding:24px 20px 64px}}
.slide{{background:var(--surface);border:1px solid var(--line);border-radius:14px;padding:28px 30px;margin:0 0 20px}}
.hero{{background:var(--ink);color:var(--bg);border:none}}.hero h1{{font-size:clamp(26px,4vw,40px);line-height:1.15;margin:.2em 0 .4em}}
.hero p{{color:inherit;opacity:.8;margin:0}}
.kicker{{text-transform:uppercase;letter-spacing:.08em;font-size:12px;color:var(--muted);margin:0 0 4px;font-weight:600}}
h2{{font-size:clamp(20px,2.6vw,26px);line-height:1.25;margin:0 0 16px}}h3{{font-size:14px;color:var(--muted);text-transform:uppercase;letter-spacing:.05em;margin:18px 0 6px}}
h4{{margin:0 0 6px;font-size:15px}}p{{margin:0 0 10px}}
.cols{{display:grid;grid-template-columns:1fr 1fr;gap:28px}}@media(max-width:760px){{.cols{{grid-template-columns:1fr}}.slide{{padding:20px 16px}}}}
ul.ctx li{{margin-bottom:8px}}ol.path{{padding-left:20px}}ol.path li{{margin:6px 0;padding:6px 10px;border:1px solid var(--line);border-radius:8px;list-style-position:inside}}
.rule{{font-size:14px;color:var(--muted)}}
.tw{{overflow-x:auto}}table{{border-collapse:collapse;width:100%;font-size:14px}}th,td{{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}}
th{{color:var(--muted);font-weight:600}}td.r{{text-align:right;font-variant-numeric:tabular-nums}}
.tag{{display:inline-block;font-size:11px;font-weight:700;border-radius:4px;padding:1px 6px;margin-right:4px}}.cu{{background:var(--ok);color:var(--surface)}}.inf{{border:1px solid var(--muted);color:var(--muted)}}
code{{font-size:12.5px;background:var(--bg);padding:1px 5px;border-radius:4px;word-break:break-all}}
.chart{{overflow-x:auto}}.chart svg{{min-width:640px;width:100%;height:auto}}
.band{{fill:var(--band)}}.grid{{stroke:var(--line);stroke-width:1}}.thr{{stroke:var(--inc);stroke-dasharray:5 4;stroke-width:1.2}}
.avg{{fill:none;stroke:var(--accent);stroke-width:2.4}}.avgk{{fill:var(--accent)}}.lost{{fill:var(--inc);opacity:.75}}
.ax{{fill:var(--muted);font-size:11px}}.lab{{fill:var(--inc);font-size:11px;font-weight:700}}
.node{{fill:var(--bg);stroke:var(--ok);stroke-width:1.4}}.nt{{fill:var(--ink);font-size:14px;font-weight:700}}.ns{{fill:var(--muted);font-size:11px}}
.edge{{stroke:var(--muted);stroke-width:1.3}}.ahead{{fill:var(--muted)}}
.kpis{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:16px}}
.kpi{{border:1px solid var(--line);border-radius:10px;padding:12px}}.kpi b{{display:block;font-size:24px}}.kpi span{{font-size:13px;color:var(--muted)}}
.conv{{border:1px solid var(--line);border-radius:10px;padding:12px 14px;margin-bottom:12px}}
details{{margin:6px 0}}summary{{cursor:pointer}}.exp{{color:var(--muted);font-size:14px;margin:6px 0 0 16px}}
.ev ul{{font-size:14px;padding-left:18px}}.foot{{text-align:center;color:var(--muted);font-size:13px}}
</style></head><body><main>
<section class="slide hero"><p class="kicker" style="color:inherit;opacity:.7">Démonstration Elastic AI · Agent Builder</p>
<h1>{e(c['name'])}, {e(c['system'])} : un agent qui suit chaque deal du Front au Back Office</h1>
<p>{e(x['day'])}. Données synthétiques, modélisées d’après la phase de découverte. Aucune donnée client.</p></section>

<section class="slide"><p class="kicker">Contexte</p><h2>Un deal doit descendre en moins de 30 minutes</h2><div class="cols">
<ul class="ctx">{''.join(f'<li>{e(t)}</li>' for t in c['context'])}</ul>
<div><h3>Parcours d’investigation de l’agent</h3><ol class="path">{path_steps}</ol>
<p class="rule">≤ {k['descent_ok_min']} min OK · {k['descent_ok_min']}–{k['descent_critical_min']} min dégradé · &gt; {k['descent_critical_min']} min incident · {k['lost_critical_count']} deals perdus depuis plus d’une heure = critique</p></div></div></section>

<section class="slide"><p class="kicker">Systèmes</p><h2>Huit systèmes, quatre couches, une seule chaîne</h2>
<div class="tw"><table><thead><tr><th>Système</th><th>Couche</th><th>Technologie</th><th>Attributs clés</th></tr></thead><tbody>{sysrows}</tbody></table></div>
<p class="rule" style="margin-top:10px"><b>Client</b> : cité pendant la découverte. <b>Déduit</b> : posé par analogie, à confirmer.</p></section>

<section class="slide"><p class="kicker">Corrélation</p><h2>Le trace_id et le deal id traversent toute la chaîne, Kafka et TIBCO compris</h2>
<div class="chart">{svg_chain()}</div>
<p>Chaque deal est une trace OpenTelemetry de bout en bout, et chaque étape écrit une ligne de cycle de vie portant <code>{e(s['attribute_prefix'])}.deal.id</code>, le statut, l’attente depuis l’étape précédente et, à l’arrivée, le temps de descente.</p></section>

<section class="slide"><p class="kicker">Jeu de données</p><h2>{num(s['total_events'])} événements synthétiques, {num(s['deals'])} deals sur 24 heures</h2>
<div class="kpis"><div class="kpi"><b>{dec(b['avg_min'])} min</b><span>descente moyenne en temps normal</span></div>
<div class="kpi"><b>{dec(i1['descent']['avg_min'])} min</b><span>descente moyenne pendant {e(i1['id'])}</span></div>
<div class="kpi"><b>{i2['lost_deals']}</b><span>deals perdus pendant {e(i2['id'])}</span></div>
<div class="kpi"><b>{len(x['decoys']) + len(x['lost_isolated'])}</b><span>fausses pistes et cas isolés</span></div></div>
<div class="tw"><table><thead><tr><th>Data stream</th><th>Contenu</th><th class="r">Événements</th></tr></thead><tbody>{streams}</tbody></table></div></section>

<section class="slide"><p class="kicker">La journée</p><h2>Une descente lente le matin, des deals perdus l’après-midi</h2><div class="chart">{svg_day(x)}</div></section>
{incident(i1, TITLE_I1.format(v=i1['versions']['new']), seen1, cause1)}
{incident(i2, TITLE_I2.format(n=i2['lost_deals'], desk=i2['desk']), seen2, cause2)}
<section class="slide"><p class="kicker">Fausses pistes</p><h2>Ce que l’agent doit écarter</h2><ul class="ctx">{''.join(f'<li>{e(t)}</li>' for t in x['decoys'])}</ul>
<h3>Pertes isolées, sous le seuil critique</h3><ul class="ctx">{''.join(f'<li>{e(t)}</li>' for t in x['lost_isolated'])}</ul></section>
<section class="slide"><p class="kicker">Questions</p><h2>Les autres questions de la démonstration</h2>{''.join(qa(cid) for cid in other)}</section>
<p class="foot">Données synthétiques générées pour la démonstration. Namespace <code>{e(s['namespace'])}</code>.</p>
</main></body></html>"""
    path = out / "summary-deck.html"
    path.write_text(page, encoding="utf-8")
    return path


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("out")
    ap.add_argument("--only", choices=("html", "pptx"))
    args = ap.parse_args()
    out = Path(args.out)
    if args.only != "pptx":
        print(f"Wrote {build_html(out)}")
    if args.only != "html":
        print(f"Wrote {build_pptx(out)}")


if __name__ == "__main__":
    main()
