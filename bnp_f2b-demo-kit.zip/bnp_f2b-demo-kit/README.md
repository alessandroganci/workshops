# Kit de démo BNP Paribas CIB

Jeu de données synthétique de 100 000 événements (2026-11-16T00:00:00+01:00 → 2026-11-17T00:00:00+01:00), au format OpenTelemetry, avec 2
incidents injectés et un agent Elastic Agent Builder prêt à les retrouver. Aucune donnée réelle.

## Prérequis

- Python 3.9 ou plus, puis `pip install opentelemetry-proto`
- Un projet Elastic Serverless de type Observability ou Security, dédié à la démo
- Une clé d'API créée dans Kibana par un administrateur
- Un connecteur LLM actif pour Agent Builder dans le projet

## Chargement

```
cp demo.env.example demo.env      # puis renseigner les trois URL et la clé
python3 scripts/run_all.py out --env-file demo.env
```

Le script enchaîne : test de connexion, ingestion, vérification des volumes et des incidents, test des outils
ES|QL, création de l'agent. Il s'arrête à la première erreur. Ajouter `--rehearse` pour poser toutes les questions
à l'agent et écrire les réponses dans `out/rehearsal.md`.

## Pendant la démo

Résumé en slides : `out/summary-deck.pptx` (PowerPoint ; déposé dans Google Drive et ouvert avec Google Slides, il devient
un Google Slides modifiable) ou `out/summary-deck.html` dans un navigateur.
Ouvrir Kibana > Agents, choisir l'agent « Front To Back – Analyste de production » et suivre `out/questions.md` (questions et réponses attendues).
La vérité terrain complète est dans `out/ground_truth.json`.

## Rafraîchir les dates

Les données portent la date du 2026-11-16. Pour les ramener au dernier jour ouvré :

```
python3 scripts/cleanup.py out --env-file demo.env --yes
python3 scripts/generate.py out/scenario.json --out out
python3 scripts/agent.py build out && python3 scripts/agent.py questions out
python3 scripts/summary_deck.py out && python3 scripts/summary_pptx.py out
python3 scripts/run_all.py out --env-file demo.env
```

Même scénario, mêmes incidents, seules les dates changent. `agent.py build` réécrit `out/agent.json`.

## Nettoyage

```
python3 scripts/cleanup.py out --env-file demo.env          # liste ce qui serait supprimé
python3 scripts/cleanup.py out --env-file demo.env --yes
```

Seuls les data streams du namespace `bnp_f2b`, l'agent et ses outils sont supprimés.

## En cas de problème

- `unreachable` : le poste ne joint pas le projet (proxy, VPN, liste d'adresses autorisées du projet).
- `401` ou `403` : clé d'API invalide, créée dans un autre projet ou sans privilèges suffisants.
- Tout est `MISSING` à la vérification : les trois URL de `demo.env` ne pointent pas sur le même projet.
- `406` ou `415` à l'ingestion : installer `opentelemetry-proto`.
- Métriques non indexées : sans gravité, le scénario repose sur les logs et les traces.
- `DUPLICATES` à la vérification : les données ont été envoyées deux fois, nettoyer puis recharger.
